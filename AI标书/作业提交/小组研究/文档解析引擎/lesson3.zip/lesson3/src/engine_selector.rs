//! 任务 1：引擎选择器
//!
//! 实现 `EngineSelector` — 输入 Docling 初步解析结果 → 计算每页特征 →
//! 输出每页的 `EngineChoice`。
//!
//! 关键要求：特征计算要快（< 10ms/页），不能比解析本身还慢。

use crate::schema::Page;

/// 三引擎调度策略：根据页面特征自动选择最优引擎
///
/// ```
/// 每个 PDF 页面 → 评估页面特征：
///
/// 内嵌文本量 > 100 字符？
///   ├─ 是 → 使用 Docling 主解析
///   │       └─ 表格置信度 > 0.7？
///   │           ├─ 是 → 保留 Docling 表格
///   │           └─ 否 → MinerU 对该页表格区域重新提取 → 替换
///   └─ 否 → 该页为图片型 PDF（扫描件）
///           └─ 整体用 PaddleOCR
/// ```
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EngineChoice {
    /// 标准页面 — 只用 Docling
    Docling,
    /// 有表格但 Docling 置信度不够 — Docling + MinerU 增强
    DoclingWithMinerU,
    /// 扫描件页面 — 整体用 PaddleOCR
    PaddleOCR,
}

impl std::fmt::Display for EngineChoice {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            EngineChoice::Docling => write!(f, "Docling"),
            EngineChoice::DoclingWithMinerU => write!(f, "DoclingWithMinerU"),
            EngineChoice::PaddleOCR => write!(f, "PaddleOCR"),
        }
    }
}

/// 页面特征 — 从 Docling 初步解析结果中快速提取
#[derive(Debug, Clone)]
pub struct PageFeatures {
    /// 页码（1-based）
    pub page_num: usize,
    /// 内嵌文本字符数（判断是否为扫描件的关键特征）
    pub embedded_text_len: usize,
    /// 图片区域占页面面积的比例 [0.0, 1.0]
    pub image_area_ratio: f64,
    /// Docling 初步解析是否检测到表格
    pub has_tables: bool,
    /// Docling 对第一个表格的置信度（如有）
    pub docling_table_confidence: Option<f64>,
}

/// 引擎选择器
///
/// 使用纯数值特征计算，不涉及 I/O 或复杂算法，保证 < 10ms/页。
pub struct EngineSelector {
    /// 扫描件判定的内嵌文本量阈值（< 此值判定为扫描件）
    pub text_len_threshold: usize,
    /// 表格置信度阈值（< 此值触发 MinerU 增强）
    pub table_confidence_threshold: f64,
    /// 记录每页的选择结果
    pub choices: Vec<(usize, EngineChoice)>,
}

impl EngineSelector {
    /// 创建默认阈值的引擎选择器
    pub fn new() -> Self {
        Self {
            // 默认阈值 50 字符（与文档中的决策树一致）
            text_len_threshold: 50,
            // 表格置信度 0.7 — 低于此值触发 MinerU
            table_confidence_threshold: 0.7,
            choices: Vec::new(),
        }
    }

    /// 自定义阈值
    pub fn with_thresholds(text_len: usize, table_conf: f64) -> Self {
        Self {
            text_len_threshold: text_len,
            table_confidence_threshold: table_conf,
            choices: Vec::new(),
        }
    }

    /// 从 Docling 的 Page 中间结果中提取页面特征
    ///
    /// 时间复杂度：O(n) 其中 n 为页面文本内容大小。
    /// 对于典型 A4 页面（~2000 字符），耗时远小于 1ms。
    pub fn extract_features(&self, page: &Page) -> PageFeatures {
        let has_tables = !page.tables.is_empty();
        let docling_table_confidence = page
            .tables
            .first()
            .map(|t| t.confidence);

        // 图片面积比例 — 从表格区域的 bbox 估算（简化版本）
        // 实际项目中可用 PDF 渲染引擎提取图片对象
        let image_area_ratio = if has_tables {
            page.tables
                .iter()
                .map(|t| (t.bbox.w * t.bbox.h) / (595.0 * 842.0)) // A4 尺寸
                .sum::<f64>()
                .min(1.0)
        } else {
            0.0
        };

        PageFeatures {
            page_num: page.page_num,
            embedded_text_len: page.embedded_text_len,
            image_area_ratio,
            has_tables,
            docling_table_confidence,
        }
    }

    /// 核心决策函数：根据页面特征选择引擎
    ///
    /// 决策树：
    /// 1. 内嵌文本 < 50 字符 → PaddleOCR（扫描件）
    /// 2. 有表格 且 表格置信度 < 0.7 → DoclingWithMinerU（表格增强）
    /// 3. 否则 → Docling（标准页面）
    pub fn select_engine(&self, features: &PageFeatures) -> EngineChoice {
        // 分支 1：内嵌文本极少 → 图片型 PDF（扫描件）
        if features.embedded_text_len < self.text_len_threshold {
            return EngineChoice::PaddleOCR;
        }

        // 分支 2：Docling 检测到表格但置信度不够 → MinerU 增强
        if features.has_tables
            && features.docling_table_confidence.unwrap_or(1.0) < self.table_confidence_threshold
        {
            return EngineChoice::DoclingWithMinerU;
        }

        // 分支 3：标准页面 → Docling 独立完成
        EngineChoice::Docling
    }

    /// 批量处理多个页面，返回每页的引擎选择
    pub fn select_all(&mut self, pages: &[Page]) -> Vec<(usize, EngineChoice)> {
        self.choices.clear();

        for page in pages {
            let features = self.extract_features(page);
            let choice = self.select_engine(&features);
            self.choices.push((page.page_num, choice));
        }

        self.choices.clone()
    }

    /// 按引擎类型分组返回页面列表
    pub fn group_by_engine(&self) -> std::collections::HashMap<String, Vec<usize>> {
        let mut groups = std::collections::HashMap::new();
        for (page_num, choice) in &self.choices {
            groups
                .entry(choice.to_string())
                .or_insert_with(Vec::new)
                .push(*page_num);
        }
        groups
    }

    /// 输出可读的调度摘要
    pub fn summary(&self) -> String {
        let groups = self.group_by_engine();
        let mut lines = vec![format!(
            "=== 引擎调度摘要 (共 {} 页) ===",
            self.choices.len()
        )];

        for (engine, pages) in &groups {
            lines.push(format!("  {}: {} 页 → {:?}", engine, pages.len(), pages));
        }

        // 成本估算（按文档数据：Docling 2s/页，MinerU 5s/表格，PaddleOCR 10s/页）
        let mut estimated_seconds = 0.0;
        for (_page_num, choice) in &self.choices {
            match choice {
                EngineChoice::Docling => estimated_seconds += 2.0,
                EngineChoice::DoclingWithMinerU => estimated_seconds += 7.0, // 2+5
                EngineChoice::PaddleOCR => estimated_seconds += 10.0,
            }
        }
        lines.push(format!(
            "  预估总耗时: {:.0}s ≈ {:.1}min（三引擎全跑对比: {}s）",
            estimated_seconds,
            estimated_seconds / 60.0,
            self.choices.len() as f64 * 17.0 // 2+5+10 = 17s per page if all three
        ));

        lines.join("\n")
    }
}

impl Default for EngineSelector {
    fn default() -> Self {
        Self::new()
    }
}

// ============================================================================
// 单元测试
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::schema::{BBox, Table};

    fn make_page(
        page_num: usize,
        text_len: usize,
        has_table: bool,
        table_conf: Option<f64>,
    ) -> Page {
        let tables = if has_table {
            vec![Table {
                id: format!("tbl_{}", page_num),
                caption: Some("测试表格".into()),
                page: page_num,
                header: vec!["列1".into(), "列2".into()],
                rows: vec![vec!["a".into(), "b".into()]],
                bbox: BBox {
                    x: 50.0,
                    y: 400.0,
                    w: 495.0,
                    h: 200.0,
                },
                source: "docling".into(),
                confidence: table_conf.unwrap_or(0.9),
            }]
        } else {
            vec![]
        };

        Page {
            page_num,
            tables,
            embedded_text_len: text_len,
            paragraphs: vec!["测试段落。".repeat(text_len / 5)],
        }
    }

    #[test]
    fn test_standard_page_uses_docling() {
        let selector = EngineSelector::new();
        let page = make_page(1, 2000, false, None);
        let features = selector.extract_features(&page);
        let choice = selector.select_engine(&features);
        assert_eq!(choice, EngineChoice::Docling);
    }

    #[test]
    fn test_scanned_page_uses_paddleocr() {
        let selector = EngineSelector::new();
        // 内嵌文本极少（< 50 字符）→ 扫描件
        let page = make_page(2, 30, false, None);
        let features = selector.extract_features(&page);
        let choice = selector.select_engine(&features);
        assert_eq!(choice, EngineChoice::PaddleOCR);
    }

    #[test]
    fn test_low_confidence_table_triggers_mineru() {
        let selector = EngineSelector::new();
        // 有表格但置信度仅 0.5（< 0.7 阈值）
        let page = make_page(3, 1500, true, Some(0.5));
        let features = selector.extract_features(&page);
        let choice = selector.select_engine(&features);
        assert_eq!(choice, EngineChoice::DoclingWithMinerU);
    }

    #[test]
    fn test_high_confidence_table_stays_docling() {
        let selector = EngineSelector::new();
        // 有表格且置信度 0.85（>= 0.7 阈值）
        let page = make_page(4, 1800, true, Some(0.85));
        let features = selector.extract_features(&page);
        let choice = selector.select_engine(&features);
        assert_eq!(choice, EngineChoice::Docling);
    }

    #[test]
    fn test_boundary_text_len_exactly_50() {
        let selector = EngineSelector::new();
        // 恰好 50 字符 → 应为标准页（不是扫描件）
        let page = make_page(5, 50, false, None);
        let features = selector.extract_features(&page);
        let choice = selector.select_engine(&features);
        assert_eq!(choice, EngineChoice::Docling);
    }

    #[test]
    fn test_boundary_text_len_49() {
        let selector = EngineSelector::new();
        // 49 字符 → 扫描件
        let page = make_page(6, 49, false, None);
        let features = selector.extract_features(&page);
        let choice = selector.select_engine(&features);
        assert_eq!(choice, EngineChoice::PaddleOCR);
    }

    #[test]
    fn test_batch_selection() {
        let mut selector = EngineSelector::new();
        let pages = vec![
            make_page(1, 2000, false, None),          // Docling
            make_page(2, 30, false, None),             // PaddleOCR
            make_page(3, 1500, true, Some(0.5)),       // DoclingWithMinerU
            make_page(4, 1800, true, Some(0.9)),       // Docling
        ];
        let choices = selector.select_all(&pages);
        assert_eq!(choices.len(), 4);
        assert_eq!(choices[0].1, EngineChoice::Docling);
        assert_eq!(choices[1].1, EngineChoice::PaddleOCR);
        assert_eq!(choices[2].1, EngineChoice::DoclingWithMinerU);
        assert_eq!(choices[3].1, EngineChoice::Docling);
    }

    #[test]
    fn test_summary_output() {
        let mut selector = EngineSelector::new();
        let pages = vec![
            make_page(1, 2000, false, None),
            make_page(2, 30, false, None),
            make_page(3, 1500, true, Some(0.5)),
        ];
        selector.select_all(&pages);
        let summary = selector.summary();
        assert!(summary.contains("Docling"));
        assert!(summary.contains("PaddleOCR"));
        assert!(summary.contains("DoclingWithMinerU"));
    }

    #[test]
    fn test_custom_thresholds() {
        // 使用更激进的阈值
        let selector = EngineSelector::with_thresholds(200, 0.5);
        let page = make_page(1, 150, false, None);
        let features = selector.extract_features(&page);
        // 150 < 200 → 扫描件
        assert_eq!(selector.select_engine(&features), EngineChoice::PaddleOCR);
    }

    #[test]
    fn test_feature_extraction_speed() {
        // 验证特征提取速度（应在亚微秒级别）
        use std::time::Instant;

        let selector = EngineSelector::new();
        let pages: Vec<Page> = (1..=100)
            .map(|i| make_page(i, 2000, i % 5 == 0, Some(0.5 + (i % 5) as f64 * 0.1)))
            .collect();

        let start = Instant::now();
        for page in &pages {
            let _features = selector.extract_features(page);
        }
        let elapsed = start.elapsed();
        let per_page_us = elapsed.as_micros() as f64 / pages.len() as f64;

        println!(
            "100 页特征提取: {:?} (平均 {:.1}μs/页)",
            elapsed, per_page_us
        );

        // 远小于 10ms（10000μs）的硬性上限
        assert!(per_page_us < 1000.0, "per-page cost should be < 1ms");
    }
}
