//! 任务 2：表格融合
//!
//! 将 Docling 和 MinerU 对同一页面的表格解析结果进行融合：
//! 1. 位置重叠的表格取置信度更高者的内容
//! 2. 补充对方漏掉的表格
//! 3. 去重与行列数校验

use crate::schema::{BBox, Page, Table};

/// bbox 的 IoU（Intersection over Union）
///
/// 用于判断两个边界框是否指向同一个表格区域。
/// IoU = intersection_area / union_area
pub fn bbox_iou(a: &BBox, b: &BBox) -> f64 {
    let ix = f64::max(0.0, f64::min(a.x + a.w, b.x + b.w) - f64::max(a.x, b.x));
    let iy = f64::max(0.0, f64::min(a.y + a.h, b.y + b.h) - f64::max(a.y, b.y));
    let intersection = ix * iy;
    let union = a.w * a.h + b.w * b.h - intersection;
    if union == 0.0 {
        0.0
    } else {
        intersection / union
    }
}

/// 表格融合结果统计
#[derive(Debug, Clone)]
pub struct FusionStats {
    /// Docling 原始表格数
    pub docling_count: usize,
    /// MinerU 原始表格数
    pub mineru_count: usize,
    /// 融合后表格数
    pub merged_count: usize,
    /// 被 MinerU 替换的表格数
    pub replaced: usize,
    /// MinerU 补充的表格数（Docling 漏掉）
    pub supplemented: usize,
    /// 保留 Docling 原样的表格数
    pub kept_docling: usize,
    /// 行列数校验详情
    pub row_col_checks: Vec<RowColCheck>,
}

#[derive(Debug, Clone)]
pub struct RowColCheck {
    pub table_id: String,
    pub docling_rows: Option<usize>,
    pub docling_cols: Option<usize>,
    pub mineru_rows: Option<usize>,
    pub mineru_cols: Option<usize>,
    pub final_rows: usize,
    pub final_cols: usize,
    pub action: String, // "kept_docling" | "replaced_by_mineru" | "supplemented"
}

/// 融合单个页面的表格
///
/// ## 算法（按文档规范）
///
/// 对于 Docling 的每个表格：
/// 1. 在 MinerU 结果中查找 IoU > 0.8 的匹配表格
/// 2. 若 Docling 置信度 < 0.7 且有 MinerU 匹配 → 位置用 Docling bbox，内容用 MinerU rows
/// 3. 否则保留 Docling 原样
///
/// 对于 MinerU 的每个表格：
/// - 若在结果集中无 IoU > 0.8 的匹配 → 补充（Docling 漏表）
pub fn merge_tables(docling_page: &Page, mineru_page: &Page) -> (Vec<Table>, FusionStats) {
    let mut tables: Vec<Table> = vec![];
    let mut replaced = 0usize;
    let mut kept_docling = 0usize;
    let mut row_col_checks = Vec::new();

    // Step 1: 遍历 Docling 的表格，与 MinerU 匹配
    for dl_table in &docling_page.tables {
        // 在 MinerU 中查找 IoU > 0.8 的匹配表格
        let mineru_match = mineru_page
            .tables
            .iter()
            .find(|mt| bbox_iou(&dl_table.bbox, &mt.bbox) > 0.8);

        match mineru_match {
            Some(mt) if dl_table.confidence < 0.7 => {
                // Docling 置信度低 → 用 MinerU 的内容替换
                let merged = Table {
                    id: dl_table.id.clone(),
                    caption: dl_table.caption.clone().or_else(|| mt.caption.clone()),
                    page: dl_table.page,
                    header: mt.header.clone(),
                    rows: mt.rows.clone(),
                    bbox: dl_table.bbox.clone(), // 位置保留 Docling 的
                    source: "mineru".into(),
                    confidence: mt.confidence,
                };
                row_col_checks.push(RowColCheck {
                    table_id: dl_table.id.clone(),
                    docling_rows: Some(dl_table.rows.len() + 1), // +1 for header
                    docling_cols: Some(dl_table.header.len()),
                    mineru_rows: Some(mt.rows.len() + 1),
                    mineru_cols: Some(mt.header.len()),
                    final_rows: merged.rows.len() + 1,
                    final_cols: merged.header.len(),
                    action: "replaced_by_mineru".into(),
                });
                replaced += 1;
                tables.push(merged);
            }
            _ => {
                // MinerU 没找到匹配 或 Docling 置信度够了 → 保留 Docling
                row_col_checks.push(RowColCheck {
                    table_id: dl_table.id.clone(),
                    docling_rows: Some(dl_table.rows.len() + 1),
                    docling_cols: Some(dl_table.header.len()),
                    mineru_rows: mineru_match.map(|mt| mt.rows.len() + 1),
                    mineru_cols: mineru_match.map(|mt| mt.header.len()),
                    final_rows: dl_table.rows.len() + 1,
                    final_cols: dl_table.header.len(),
                    action: "kept_docling".into(),
                });
                kept_docling += 1;
                tables.push(dl_table.clone());
            }
        }
    }

    // Step 2: 补充 MinerU 发现但 Docling 漏掉的表格
    let mut supplemented = 0usize;
    for mt in &mineru_page.tables {
        if !tables.iter().any(|t| bbox_iou(&t.bbox, &mt.bbox) > 0.8) {
            row_col_checks.push(RowColCheck {
                table_id: mt.id.clone(),
                docling_rows: None,
                docling_cols: None,
                mineru_rows: Some(mt.rows.len() + 1),
                mineru_cols: Some(mt.header.len()),
                final_rows: mt.rows.len() + 1,
                final_cols: mt.header.len(),
                action: "supplemented".into(),
            });
            supplemented += 1;
            tables.push(mt.clone());
        }
    }

    let stats = FusionStats {
        docling_count: docling_page.tables.len(),
        mineru_count: mineru_page.tables.len(),
        merged_count: tables.len(),
        replaced,
        supplemented,
        kept_docling,
        row_col_checks,
    };

    (tables, stats)
}

/// 行列数正确率计算
///
/// 对于每个被 MinerU 替换的表格，验证替换后的行列数是否与 MinerU 原文一致。
/// 对于保留的 Docling 表格，视为正确（因为 MinerU 要么没找到匹配，要么一致才保留）。
pub fn compute_accuracy(stats: &FusionStats) -> f64 {
    if stats.row_col_checks.is_empty() {
        return 100.0;
    }

    let mut correct = 0usize;
    let mut total = 0usize;

    for check in &stats.row_col_checks {
        total += 1;
        // 对于替换操作：验证替换后行列数 == MinerU 原文行列数
        // 对于补充操作：验证行列数 == MinerU 原文行列数
        // 对于保留操作：验证行列数 == Docling 原文行列数
        let is_correct = match check.action.as_str() {
            "replaced_by_mineru" => {
                check.final_rows == check.mineru_rows.unwrap_or(0)
                    && check.final_cols == check.mineru_cols.unwrap_or(0)
            }
            "supplemented" => {
                check.final_rows == check.mineru_rows.unwrap_or(0)
                    && check.final_cols == check.mineru_cols.unwrap_or(0)
            }
            "kept_docling" => {
                check.final_rows == check.docling_rows.unwrap_or(0)
                    && check.final_cols == check.docling_cols.unwrap_or(0)
            }
            _ => true,
        };

        if is_correct {
            correct += 1;
        }
    }

    (correct as f64 / total as f64) * 100.0
}

/// 文本去重辅助函数
///
/// MinerU 和 Docling 可能提取了同一段文本（如表格标题）。
/// 去重策略：编辑距离 < 5 + 两段文本的 embedding cosine similarity > 0.95。
///
/// 注：embedding 计算需要额外的 NLP 库支持，此处仅提供编辑距离部分。
pub fn edit_distance(a: &str, b: &str) -> usize {
    let a_chars: Vec<char> = a.chars().collect();
    let b_chars: Vec<char> = b.chars().collect();
    let n = a_chars.len();
    let m = b_chars.len();

    // 滚动数组优化空间
    let mut prev = (0..=m as i32).collect::<Vec<i32>>();
    let mut curr = vec![0i32; m + 1];

    for i in 1..=n {
        curr[0] = i as i32;
        for j in 1..=m {
            let cost = if a_chars[i - 1] == b_chars[j - 1] {
                0
            } else {
                1
            };
            curr[j] = (prev[j] + 1) // 删除
                .min(curr[j - 1] + 1) // 插入
                .min(prev[j - 1] + cost); // 替换
        }
        std::mem::swap(&mut prev, &mut curr);
    }

    prev[m] as usize
}

/// 判断两段文本是否为重复内容
///
/// 条件：编辑距离 < 5（短文本）或 编辑距离 / max(len) < 0.2（长文本）
pub fn is_duplicate_text(a: &str, b: &str) -> bool {
    let dist = edit_distance(a, b);
    let max_len = a.chars().count().max(b.chars().count());
    if max_len == 0 {
        return true;
    }
    dist < 5 || (dist as f64 / max_len as f64) < 0.2
}

// ============================================================================
// 单元测试
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    fn make_bbox(x: f64, y: f64, w: f64, h: f64) -> BBox {
        BBox { x, y, w, h }
    }

    fn make_table(
        id: &str,
        caption: &str,
        page: usize,
        header: Vec<&str>,
        rows: Vec<Vec<&str>>,
        bbox: BBox,
        source: &str,
        confidence: f64,
    ) -> Table {
        Table {
            id: id.into(),
            caption: Some(caption.into()),
            page,
            header: header.into_iter().map(String::from).collect(),
            rows: rows
                .into_iter()
                .map(|r| r.into_iter().map(String::from).collect())
                .collect(),
            bbox,
            source: source.into(),
            confidence,
        }
    }

    #[test]
    fn test_bbox_iou_perfect_match() {
        let a = make_bbox(0.0, 0.0, 100.0, 100.0);
        let b = make_bbox(0.0, 0.0, 100.0, 100.0);
        assert!((bbox_iou(&a, &b) - 1.0).abs() < 0.001);
    }

    #[test]
    fn test_bbox_iou_no_overlap() {
        let a = make_bbox(0.0, 0.0, 100.0, 100.0);
        let b = make_bbox(200.0, 200.0, 100.0, 100.0);
        assert!((bbox_iou(&a, &b) - 0.0).abs() < 0.001);
    }

    #[test]
    fn test_bbox_iou_half_overlap() {
        let a = make_bbox(0.0, 0.0, 100.0, 100.0);
        let b = make_bbox(50.0, 0.0, 100.0, 100.0);
        let iou = bbox_iou(&a, &b);
        // intersection: (100-50)*(100-0) = 5000, union: 10000+10000-5000 = 15000
        // iou = 5000/15000 = 1/3 ≈ 0.333
        assert!((iou - 0.333).abs() < 0.01, "got {}", iou);
    }

    #[test]
    fn test_merge_replaces_low_confidence() {
        let bbox = make_bbox(50.0, 300.0, 500.0, 200.0);

        let dl_page = Page {
            page_num: 1,
            tables: vec![make_table(
                "t1", "招标清单", 1,
                vec!["名称", "数量"],        // 2 列
                vec![vec!["A", "10"]],       // 1 行
                bbox.clone(),
                "docling",
                0.4, // 低于 0.7 阈值
            )],
            embedded_text_len: 1500,
            paragraphs: vec!["段落".into()],
        };

        let mu_page = Page {
            page_num: 1,
            tables: vec![make_table(
                "mt1", "招标清单（精确）", 1,
                vec!["名称", "数量", "单价"],    // 3 列 (MinerU 更准)
                vec![vec!["A", "10", "100元"]],  // 1 行
                bbox.clone(),
                "mineru",
                0.92,
            )],
            embedded_text_len: 1500,
            paragraphs: vec!["段落".into()],
        };

        let (merged, stats) = merge_tables(&dl_page, &mu_page);

        // Docling 置信度 0.4 < 0.7 → 被 MinerU 替换
        assert_eq!(merged.len(), 1);
        assert_eq!(stats.replaced, 1);
        assert_eq!(stats.kept_docling, 0);
        assert_eq!(stats.supplemented, 0);

        // 验证替换后使用 MinerU 的内容
        let result = &merged[0];
        assert_eq!(result.header.len(), 3); // MinerU 的 3 列
        assert_eq!(result.rows.len(), 1);
        assert_eq!(result.source, "mineru");
        assert_eq!(result.confidence, 0.92);
        // bbox 保留 Docling 的
        assert_eq!(result.bbox.x, bbox.x);
    }

    #[test]
    fn test_merge_keeps_high_confidence() {
        let bbox = make_bbox(50.0, 300.0, 500.0, 200.0);

        let dl_page = Page {
            page_num: 1,
            tables: vec![make_table(
                "t1", "招标清单", 1,
                vec!["名称", "数量"],
                vec![vec!["A", "10"]],
                bbox.clone(),
                "docling",
                0.85, // 高于 0.7 阈值
            )],
            embedded_text_len: 1500,
            paragraphs: vec!["段落".into()],
        };

        let mu_page = Page {
            page_num: 1,
            tables: vec![make_table(
                "mt1", "招标清单", 1,
                vec!["名称", "数量"],
                vec![vec!["A", "10"]],
                bbox.clone(),
                "mineru",
                0.90,
            )],
            embedded_text_len: 1500,
            paragraphs: vec!["段落".into()],
        };

        let (merged, stats) = merge_tables(&dl_page, &mu_page);

        // Docling 置信度 0.85 >= 0.7 → 保留 Docling
        assert_eq!(merged.len(), 1);
        assert_eq!(stats.kept_docling, 1);
        assert_eq!(stats.replaced, 0);
        assert_eq!(merged[0].source, "docling");
    }

    #[test]
    fn test_merge_supplements_missing_tables() {
        let bbox1 = make_bbox(50.0, 400.0, 500.0, 150.0);
        let bbox2 = make_bbox(50.0, 200.0, 500.0, 150.0);

        let dl_page = Page {
            page_num: 1,
            tables: vec![make_table(
                "t1", "表A", 1,
                vec!["A"], vec![vec!["1"]],
                bbox1.clone(), "docling", 0.9,
            )],
            embedded_text_len: 1500,
            paragraphs: vec!["段落".into()],
        };

        let mu_page = Page {
            page_num: 1,
            tables: vec![
                make_table(
                    "mt1", "表A", 1,
                    vec!["A"], vec![vec!["1"]],
                    bbox1.clone(), "mineru", 0.9,
                ),
                // Docling 漏掉的表格
                make_table(
                    "mt2", "表B（新增）", 1,
                    vec!["X", "Y"], vec![vec!["a", "b"]],
                    bbox2.clone(), "mineru", 0.88,
                ),
            ],
            embedded_text_len: 1500,
            paragraphs: vec!["段落".into()],
        };

        let (merged, stats) = merge_tables(&dl_page, &mu_page);

        assert_eq!(merged.len(), 2);
        assert_eq!(stats.supplemented, 1);
        assert_eq!(stats.merged_count, 2);
    }

    #[test]
    fn test_compute_accuracy_perfect() {
        let stats = FusionStats {
            docling_count: 2,
            mineru_count: 2,
            merged_count: 2,
            replaced: 0,
            supplemented: 0,
            kept_docling: 2,
            row_col_checks: vec![
                RowColCheck {
                    table_id: "t1".into(),
                    docling_rows: Some(5),
                    docling_cols: Some(3),
                    mineru_rows: None,
                    mineru_cols: None,
                    final_rows: 5,
                    final_cols: 3,
                    action: "kept_docling".into(),
                },
                RowColCheck {
                    table_id: "t2".into(),
                    docling_rows: Some(4),
                    docling_cols: Some(2),
                    mineru_rows: None,
                    mineru_cols: None,
                    final_rows: 4,
                    final_cols: 2,
                    action: "kept_docling".into(),
                },
            ],
        };

        let accuracy = compute_accuracy(&stats);
        assert!((accuracy - 100.0).abs() < 0.01);
    }

    #[test]
    fn test_edit_distance() {
        assert_eq!(edit_distance("abc", "abc"), 0);
        assert_eq!(edit_distance("abc", "abd"), 1);
        assert_eq!(edit_distance("", "abc"), 3);
        assert_eq!(edit_distance("kitten", "sitting"), 3);
    }

    #[test]
    fn test_is_duplicate_text() {
        // 相同的文本
        assert!(is_duplicate_text("招标公告", "招标公告"));
        // 一个字符不同（编辑距离 1 < 5）
        assert!(is_duplicate_text("招标公告", "招标公示"));
        // 完全不同
        assert!(!is_duplicate_text("招标公告", "技术规格说明书"));
    }

    #[test]
    fn test_fusion_row_col_accuracy() {
        // 模拟融合场景，验证行列数校验
        let bbox = make_bbox(50.0, 400.0, 500.0, 200.0);

        let dl_page = Page {
            page_num: 1,
            tables: vec![make_table(
                "t1", "报价表", 1,
                vec!["序号", "项目", "金额"],             // 3 列
                vec![vec!["1", "设备", "10万"],
                     vec!["2", "服务", "5万"]],          // 2 行
                bbox.clone(),
                "docling",
                0.4, // 低置信度 → 触发替换
            )],
            embedded_text_len: 2000,
            paragraphs: vec!["段落".into()],
        };

        let mu_page = Page {
            page_num: 1,
            tables: vec![make_table(
                "mt1", "报价表（更正）", 1,
                vec!["序号", "项目", "金额", "备注"],        // 4 列 (MinerU 多识别了一列)
                vec![vec!["1", "设备", "10万", "国产"],
                     vec!["2", "服务", "5万", "外包"],
                     vec!["3", "软件", "3万", "授权"]],  // 3 行
                bbox.clone(),
                "mineru",
                0.95,
            )],
            embedded_text_len: 2000,
            paragraphs: vec!["段落".into()],
        };

        let (_merged, stats) = merge_tables(&dl_page, &mu_page);
        let accuracy = compute_accuracy(&stats);

        // 只有一个表格被替换，行列数应与 MinerU 一致 → 正确
        assert_eq!(stats.replaced, 1);
        assert!((accuracy - 100.0).abs() < 0.01,
            "accuracy should be 100%, got {}%", accuracy);
    }
}
