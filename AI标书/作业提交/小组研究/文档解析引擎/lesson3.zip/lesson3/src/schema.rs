use serde::{Deserialize, Serialize};

/// ---------------------------------------------------------------------------
/// ParsedDocument — G1 组对下游 8 个组的接口契约
///
/// 所有字段使用 `#[serde(rename_all = "camelCase")]` 匹配 JSON 规范。
/// 坐标系统一为 PDF 坐标系（左下角原点）。
/// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ParsedDocument {
    /// SHA256(file_content)[:16]
    pub document_id: String,
    /// 原始文件名
    pub file_name: String,
    /// 总页数
    pub page_count: usize,
    /// 章节列表
    pub chapters: Vec<Chapter>,
    /// 条款列表
    pub clauses: Vec<Clause>,
    /// 表格列表
    pub tables: Vec<Table>,
    /// 图片列表
    pub images: Vec<DocumentImage>,
    /// 解析元信息
    pub parse_meta: ParseMeta,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Chapter {
    /// "ch_001"
    pub id: String,
    pub title: String,
    /// 1=章, 2=节, 3=小节
    pub level: u8,
    /// 起始页码
    pub page_start: usize,
    /// 结束页码
    pub page_end: usize,
    /// 关联的条款 ID 列表
    pub clause_ids: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Clause {
    /// "cl_001" = SHA256(doc_id + page + index)[:8]
    pub id: String,
    /// 所属章节 ID
    pub chapter_id: String,
    /// 条款文本
    pub text: String,
    /// 类型："requirement" | "definition" | "procedure"
    pub clause_type: String,
    /// 所在页码
    pub page: usize,
    /// 边界框
    pub bbox: BBox,
    /// 构成此 Clause 的原始 Block IDs
    pub block_ids: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Table {
    pub id: String,
    pub caption: Option<String>,
    /// 所在页码
    pub page: usize,
    /// 表头
    pub header: Vec<String>,
    /// 数据行
    pub rows: Vec<Vec<String>>,
    /// 边界框
    pub bbox: BBox,
    /// 来源引擎："docling" | "mineru" | "merged"
    pub source: String,
    /// 表格置信度
    pub confidence: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BBox {
    /// PDF 坐标系左下角 x
    pub x: f64,
    /// PDF 坐标系左下角 y
    pub y: f64,
    /// 宽度
    pub w: f64,
    /// 高度
    pub h: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DocumentImage {
    pub id: String,
    pub page: usize,
    pub bbox: BBox,
    /// 图片类型（如 "certificate", "seal", "diagram"）
    pub image_type: String,
    /// Base64 编码的图片数据（缩略图或占位符）
    pub base64_thumbnail: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ParseMeta {
    /// 解析耗时（毫秒）
    pub parse_time_ms: u64,
    /// 解析器版本号
    pub parser_version: String,
    /// 部分解析错误（不中断整文档）
    pub partial_errors: Vec<ParseError>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ParseError {
    pub page: usize,
    /// "docling" | "mineru" | "paddleocr"
    pub engine: String,
    pub error: String,
}

/// ---------------------------------------------------------------------------
/// Chunk — 预计算的文本分块，用于 RAG 检索
/// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Chunk {
    pub id: String,
    pub text: String,
    pub clause_id: Option<String>,
    /// Chunk 内所有 block 的聚合 bbox（预计算缓存）
    pub bbox_refs: BBox,
}

/// ---------------------------------------------------------------------------
/// Page — 单页面中间表示（用于引擎决策与融合）
/// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
pub struct Page {
    pub page_num: usize,
    /// 页面中的所有表格
    pub tables: Vec<Table>,
    /// 内嵌文本总长度
    pub embedded_text_len: usize,
    /// 页面的段落 / 文本块
    pub paragraphs: Vec<String>,
}
