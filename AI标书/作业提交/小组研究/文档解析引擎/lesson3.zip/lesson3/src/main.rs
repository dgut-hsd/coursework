//! lesson-03: 多引擎编排 + ParsedDocument Schema
//!
//! ## 任务概览
//!
//! | 任务 | 内容 | 核心输出 |
//! |------|------|----------|
//! | 任务 1 | 引擎选择器 | `EngineSelector` — 根据页面特征自动选择最优引擎 |
//! | 任务 2 | 表格融合 | `merge_tables()` — Docling + MinerU 表格结果融合 |
//! | 任务 3 | Schema 序列化 | `ParsedDocument` JSON 序列化/反序列化验证 |

mod engine_selector;
mod schema;
mod table_fusion;

use engine_selector::{EngineChoice, EngineSelector};
use schema::*;
use sha2::{Digest, Sha256};
use table_fusion::merge_tables;

// ============================================================================
// 辅助函数
// ============================================================================

/// 生成 document_id: SHA256(file_content)[:16]
fn generate_document_id(content: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(content.as_bytes());
    let result = hasher.finalize();
    hex::encode(&result[..8]) // 前 8 字节 = 16 hex 字符
}

/// 生成 clause_id: SHA256(doc_id + page + index)[:8]
fn generate_clause_id(doc_id: &str, page: usize, index: usize) -> String {
    let input = format!("{}_{}_{}", doc_id, page, index);
    let mut hasher = Sha256::new();
    hasher.update(input.as_bytes());
    let result = hasher.finalize();
    hex::encode(&result[..4]) // 前 4 字节 = 8 hex 字符
}

// ============================================================================
// 任务 1：引擎选择器演示
// ============================================================================

fn demo_engine_selector() {
    println!("╔══════════════════════════════════════════════════╗");
    println!("║  任务 1：引擎选择器 (EngineSelector)              ║");
    println!("╚══════════════════════════════════════════════════╝\n");

    // 模拟 6 页不同类型的文档
    let pages = vec![
        // 标准正文页
        Page {
            page_num: 1,
            tables: vec![],
            embedded_text_len: 2500,
            paragraphs: vec!["第一章 总则...".into()],
        },
        // 含高置信度表格的页面
        Page {
            page_num: 2,
            tables: vec![Table {
                id: "tbl_2".into(),
                caption: Some("投标报价一览表".into()),
                page: 2,
                header: vec!["序号".into(), "项目名称".into(), "金额".into()],
                rows: vec![
                    vec!["1".into(), "设备采购".into(), "100万".into()],
                    vec!["2".into(), "系统集成".into(), "50万".into()],
                ],
                bbox: BBox { x: 50.0, y: 400.0, w: 495.0, h: 250.0 },
                source: "docling".into(),
                confidence: 0.92,
            }],
            embedded_text_len: 1200,
            paragraphs: vec!["报价说明...".into()],
        },
        // 含低置信度表格的页面（需 MinerU 增强）
        Page {
            page_num: 3,
            tables: vec![Table {
                id: "tbl_3".into(),
                caption: Some("技术参数对比表".into()),
                page: 3,
                header: vec!["参数".into(), "招标要求".into()],
                rows: vec![vec!["CPU".into(), "≥8核".into()]],
                bbox: BBox { x: 50.0, y: 350.0, w: 495.0, h: 300.0 },
                source: "docling".into(),
                confidence: 0.45, // 低于 0.7 阈值
            }],
            embedded_text_len: 800,
            paragraphs: vec!["技术要求...".into()],
        },
        // 扫描件页面（内嵌文本极少）
        Page {
            page_num: 4,
            tables: vec![],
            embedded_text_len: 20, // < 50 → PaddleOCR
            paragraphs: vec![],
        },
        // 资质证书页（扫描件）
        Page {
            page_num: 5,
            tables: vec![],
            embedded_text_len: 5, // 几乎无内嵌文本
            paragraphs: vec![],
        },
        // 另一标准正文页
        Page {
            page_num: 6,
            tables: vec![],
            embedded_text_len: 3000,
            paragraphs: vec!["第六章 合同条款...".into()],
        },
    ];

    let mut selector = EngineSelector::new();
    let choices = selector.select_all(&pages);

    println!("逐页决策详情:");
    println!("{:-<60}", "");
    for (page_num, choice) in &choices {
        let label = match choice {
            EngineChoice::Docling => "📄 Docling（标准页）",
            EngineChoice::DoclingWithMinerU => "📊 Docling + MinerU（表格增强）",
            EngineChoice::PaddleOCR => "🖼️  PaddleOCR（扫描件）",
        };
        println!("  第 {} 页 → {}", page_num, label);
    }
    println!();

    println!("{}", selector.summary());
    println!();
}

// ============================================================================
// 任务 2：表格融合演示
// ============================================================================

fn demo_table_fusion() {
    println!("╔══════════════════════════════════════════════════╗");
    println!("║  任务 2：表格融合 (Table Fusion)                  ║");
    println!("╚══════════════════════════════════════════════════╝\n");

    // Docling 解析结果（3 个表格，其中一个置信度低）
    let bbox_a = BBox { x: 50.0, y: 500.0, w: 500.0, h: 200.0 };
    let bbox_b = BBox { x: 50.0, y: 250.0, w: 500.0, h: 200.0 };
    let bbox_c = BBox { x: 50.0, y: 50.0, w: 500.0, h: 150.0 };

    let docling_page = Page {
        page_num: 3,
        tables: vec![
            Table {
                id: "tbl_dl_1".into(),
                caption: Some("投标报价表".into()),
                page: 3,
                header: vec!["序号".into(), "项目".into(), "金额".into()],
                rows: vec![
                    vec!["1".into(), "设备A".into(), "50万".into()],
                    vec!["2".into(), "设备B".into(), "30".into()], // 缺"万"
                ],
                bbox: bbox_a.clone(),
                source: "docling".into(),
                confidence: 0.42, // 低置信度 → 将被 MinerU 替换
            },
            Table {
                id: "tbl_dl_2".into(),
                caption: Some("人员配置表".into()),
                page: 3,
                header: vec!["姓名".into(), "职称".into()],
                rows: vec![
                    vec!["张三".into(), "高工".into()],
                    vec!["李四".into(), "工程师".into()],
                ],
                bbox: bbox_b.clone(),
                source: "docling".into(),
                confidence: 0.88, // 高置信度 → 保留 Docling
            },
        ],
        embedded_text_len: 1500,
        paragraphs: vec!["第三章 投标报价...".into()],
    };

    // MinerU 解析结果（同一页，3 个表格，多识别了一个）
    let mineru_page = Page {
        page_num: 3,
        tables: vec![
            Table {
                id: "tbl_mu_1".into(),
                caption: Some("投标报价表".into()),
                page: 3,
                header: vec!["序号".into(), "项目名称".into(), "报价金额（万元）".into(), "备注".into()],
                rows: vec![
                    vec!["1".into(), "设备A".into(), "50".into(), "含税".into()],
                    vec!["2".into(), "设备B".into(), "30".into(), "含税".into()],
                    // MinerU 正确处理了"30万"
                ],
                bbox: bbox_a.clone(),
                source: "mineru".into(),
                confidence: 0.93,
            },
            Table {
                id: "tbl_mu_2".into(),
                caption: Some("人员配置表".into()),
                page: 3,
                header: vec!["姓名".into(), "职称".into()],
                rows: vec![
                    vec!["张三".into(), "高工".into()],
                    vec!["李四".into(), "工程师".into()],
                ],
                bbox: bbox_b.clone(),
                source: "mineru".into(),
                confidence: 0.91,
            },
            // MinerU 额外发现的表格（Docling 漏掉）
            Table {
                id: "tbl_mu_3".into(),
                caption: Some("业绩要求表（补充）".into()),
                page: 3,
                header: vec!["年份".into(), "合同额".into(), "项目数".into()],
                rows: vec![
                    vec!["2024".into(), "5000万".into(), "12".into()],
                    vec!["2025".into(), "8000万".into(), "20".into()],
                ],
                bbox: bbox_c.clone(),
                source: "mineru".into(),
                confidence: 0.89,
            },
        ],
        embedded_text_len: 1500,
        paragraphs: vec!["...".into()],
    };

    let (merged, stats) = merge_tables(&docling_page, &mineru_page);

    println!("融合统计:");
    println!("  Docling 原始表格: {} 个", stats.docling_count);
    println!("  MinerU  原始表格: {} 个", stats.mineru_count);
    println!("  融合后表格:      {} 个", stats.merged_count);
    println!("  ─────────────────────");
    println!("  保留 Docling:    {} 个", stats.kept_docling);
    println!("  MinerU 替换:     {} 个", stats.replaced);
    println!("  MinerU 补充:     {} 个", stats.supplemented);
    println!();

    // 行列数校验
    println!("行列数校验详情:");
    println!("{:-<70}", "");
    for check in &stats.row_col_checks {
        println!("  表格 {}:", check.table_id);
        println!("    Docling: {}行×{}列 | MinerU: {}行×{}列",
            check.docling_rows.map_or("N/A".into(), |v| v.to_string()),
            check.docling_cols.map_or("N/A".into(), |v| v.to_string()),
            check.mineru_rows.map_or("N/A".into(), |v| v.to_string()),
            check.mineru_cols.map_or("N/A".into(), |v| v.to_string()),
        );
        println!("    最终: {}行×{}列 → {}",
            check.final_rows, check.final_cols, check.action);
    }
    println!();

    let accuracy = table_fusion::compute_accuracy(&stats);
    println!("行列数正确率: {:.1}% (目标 > 95%)", accuracy);
    println!(
        "验收: {}",
        if accuracy > 95.0 { "✅ 通过" } else { "❌ 未通过" }
    );
    println!();

    // 展示融合后的表格内容
    println!("融合后表格内容:");
    println!("{:-<70}", "");
    for table in &merged {
        println!("  [{}] {} (来源: {}, 置信度: {:.2})",
            table.id,
            table.caption.as_deref().unwrap_or("无标题"),
            table.source,
            table.confidence,
        );
        println!("    表头: {:?}", table.header);
        for (i, row) in table.rows.iter().enumerate() {
            println!("    行{}: {:?}", i + 1, row);
        }
        println!();
    }
}

// ============================================================================
// 任务 3：ParsedDocument 序列化
// ============================================================================

fn demo_parsed_document() {
    println!("╔══════════════════════════════════════════════════╗");
    println!("║  任务 3：ParsedDocument Schema 序列化             ║");
    println!("╚══════════════════════════════════════════════════╝\n");

    // 模拟文件内容
    let file_content = "模拟招标文件内容——东莞理工学院智慧校园项目";
    let doc_id = generate_document_id(file_content);

    // 构建一份完整的 ParsedDocument
    let doc = ParsedDocument {
        document_id: doc_id.clone(),
        file_name: "东莞理工智慧校园-招标文件.pdf".into(),
        page_count: 6,
        chapters: vec![
            Chapter {
                id: "ch_001".into(),
                title: "第一章 招标公告".into(),
                level: 1,
                page_start: 1,
                page_end: 2,
                clause_ids: vec!["cl_001".into(), "cl_002".into()],
            },
            Chapter {
                id: "ch_002".into(),
                title: "第二章 投标人须知".into(),
                level: 1,
                page_start: 3,
                page_end: 6,
                clause_ids: vec!["cl_003".into(), "cl_004".into(), "cl_005".into()],
            },
            Chapter {
                id: "ch_002_001".into(),
                title: "2.1 资格要求".into(),
                level: 2,
                page_start: 3,
                page_end: 3,
                clause_ids: vec!["cl_003".into()],
            },
        ],
        clauses: vec![
            Clause {
                id: "cl_001".into(),
                chapter_id: "ch_001".into(),
                text: "本项目已由东莞理工学院批准建设，资金来源为财政资金，现对该项目进行公开招标。".into(),
                clause_type: "procedure".into(),
                page: 1,
                bbox: BBox { x: 72.0, y: 700.0, w: 451.0, h: 40.0 },
                block_ids: vec!["blk_001".into(), "blk_002".into()],
            },
            Clause {
                id: "cl_002".into(),
                chapter_id: "ch_001".into(),
                text: "项目名称：东莞理工学院智慧校园信息化建设项目".into(),
                clause_type: "definition".into(),
                page: 1,
                bbox: BBox { x: 72.0, y: 650.0, w: 451.0, h: 30.0 },
                block_ids: vec!["blk_003".into()],
            },
            Clause {
                id: "cl_003".into(),
                chapter_id: "ch_002_001".into(),
                text: "投标人须具备电子与智能化工程专业承包一级资质".into(),
                clause_type: "requirement".into(),
                page: 3,
                bbox: BBox { x: 72.0, y: 720.0, w: 451.0, h: 30.0 },
                block_ids: vec!["blk_010".into()],
            },
            Clause {
                id: "cl_004".into(),
                chapter_id: "ch_002".into(),
                text: "投标人近三年须具有至少3个合同金额不低于500万元的智慧校园类项目业绩".into(),
                clause_type: "requirement".into(),
                page: 4,
                bbox: BBox { x: 72.0, y: 700.0, w: 451.0, h: 30.0 },
                block_ids: vec!["blk_020".into()],
            },
            Clause {
                id: "cl_005".into(),
                chapter_id: "ch_002".into(),
                text: "本项目不接受联合体投标，不允许转包和分包".into(),
                clause_type: "requirement".into(),
                page: 5,
                bbox: BBox { x: 72.0, y: 680.0, w: 451.0, h: 30.0 },
                block_ids: vec!["blk_030".into()],
            },
        ],
        tables: vec![
            Table {
                id: "tbl_001".into(),
                caption: Some("投标报价一览表".into()),
                page: 3,
                header: vec!["序号".into(), "项目名称".into(), "报价金额（万元）".into(), "备注".into()],
                rows: vec![
                    vec!["1".into(), "设备采购".into(), "500".into(), "含税".into()],
                    vec!["2".into(), "系统集成".into(), "300".into(), "含税".into()],
                    vec!["3".into(), "软件开发".into(), "200".into(), "含税".into()],
                ],
                bbox: BBox { x: 50.0, y: 500.0, w: 500.0, h: 200.0 },
                source: "merged".into(),
                confidence: 0.93,
            },
            Table {
                id: "tbl_002".into(),
                caption: Some("业绩要求表".into()),
                page: 4,
                header: vec!["年份".into(), "合同额（万元）".into(), "项目数量".into()],
                rows: vec![
                    vec!["2023".into(), "3000".into(), "8".into()],
                    vec!["2024".into(), "5000".into(), "12".into()],
                    vec!["2025".into(), "8000".into(), "20".into()],
                ],
                bbox: BBox { x: 50.0, y: 300.0, w: 500.0, h: 180.0 },
                source: "mineru".into(),
                confidence: 0.91,
            },
        ],
        images: vec![
            DocumentImage {
                id: "img_001".into(),
                page: 4,
                bbox: BBox { x: 100.0, y: 100.0, w: 400.0, h: 300.0 },
                image_type: "certificate".into(),
                base64_thumbnail: Some("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==".into()),
            },
        ],
        parse_meta: ParseMeta {
            parse_time_ms: 12470,
            parser_version: "docling-2.0.1+mineru-1.2.0+paddleocr-2.7.0".into(),
            partial_errors: vec![
                ParseError {
                    page: 4,
                    engine: "docling".into(),
                    error: "表格置信度不足，已回退至 MinerU".into(),
                },
            ],
        },
    };

    // --- 序列化为 JSON ---
    let json = serde_json::to_string_pretty(&doc).expect("序列化失败");
    println!("序列化后的 JSON (前 800 字符):\n");
    println!("{}", &json[..json.len().min(800)]);
    println!("...\n");

    // --- 反序列化验证 ---
    let parsed_back: ParsedDocument =
        serde_json::from_str(&json).expect("反序列化失败");
    println!("反序列化验证: ✅ 通过 (字段无损)");

    // --- 字段校验 ---
    assert_eq!(parsed_back.document_id, doc.document_id);
    assert_eq!(parsed_back.file_name, doc.file_name);
    assert_eq!(parsed_back.page_count, doc.page_count);
    assert_eq!(parsed_back.chapters.len(), doc.chapters.len());
    assert_eq!(parsed_back.clauses.len(), doc.clauses.len());
    assert_eq!(parsed_back.tables.len(), doc.tables.len());
    assert_eq!(parsed_back.images.len(), doc.images.len());

    // --- camelCase 校验 ---
    println!("\n=== camelCase 字段名校验 ===");
    // 解析为 serde_json::Value 检查关键字段名
    let v: serde_json::Value = serde_json::from_str(&json).unwrap();
    let root = v.as_object().unwrap();

    let expected_camel_case = [
        "documentId",
        "fileName",
        "pageCount",
        "chapters",
        "clauses",
        "tables",
        "images",
        "parseMeta",
    ];

    for field in &expected_camel_case {
        if root.contains_key(*field) {
            println!("  ✅ {} — camelCase 正确", field);
        } else {
            println!("  ❌ {} — 缺失或命名不正确", field);
        }
    }

    // 嵌套字段校验
    if let Some(meta) = root.get("parseMeta") {
        let meta_fields = ["parseTimeMs", "parserVersion", "partialErrors"];
        for field in &meta_fields {
            if meta.get(*field).is_some() {
                println!("  ✅ parseMeta.{} — camelCase 正确", field);
            } else {
                println!("  ❌ parseMeta.{} — 缺失或命名不正确", field);
            }
        }
    }

    if let Some(clause) = root.get("clauses").and_then(|c| c.get(0)) {
        let clause_fields = ["id", "chapterId", "text", "clauseType", "page", "bbox", "blockIds"];
        for field in &clause_fields {
            if clause.get(*field).is_some() {
                println!("  ✅ clauses[0].{} — camelCase 正确", field);
            } else {
                println!("  ❌ clauses[0].{} — 缺失或命名不正确", field);
            }
        }
    }

    // --- 保存为 JSON 文件 ---
    let output_path = "c:/Users/fyx/Desktop/lesson3/parsed_document_output.json";
    std::fs::write(output_path, &json).expect("写入 JSON 文件失败");
    println!("\n✅ 已保存至: parsed_document_output.json");

    // --- 文件大小 ---
    let metadata = std::fs::metadata(output_path).unwrap();
    println!("   文件大小: {} bytes", metadata.len());
}

// ============================================================================
// MAIN
// ============================================================================

fn main() {
    println!("  ╔══════════════════════════════════════════════════════════╗");
    println!("  ║  Lesson 03: 多引擎编排 + ParsedDocument Schema           ║");
    println!("  ║  东莞理工学院 — G1 文档解析组                            ║");
    println!("  ╚══════════════════════════════════════════════════════════╝");
    println!();

    // 任务 1
    demo_engine_selector();

    // 任务 2
    demo_table_fusion();

    // 任务 3
    demo_parsed_document();

    // ================
    // 思考题
    // ================
    println!("╔══════════════════════════════════════════════════╗");
    println!("║  思考题                                          ║");
    println!("╚══════════════════════════════════════════════════╝\n");

    println!("Q1: 决策树阈值 50 字符如何确定？");
    println!("A1: 需在实际招标文件数据集上统计\"内嵌文本量\"的分布。");
    println!("    方法：用 Docling 解析 100 份混合文档，记录每页的 embedded_text_len。");
    println!("    扫描件页通常在 0-30 字符区间，标准正文页通常在 500+ 字符。");
    println!("    阈值应取二者分布的\"谷底\"——既不远低于标准页最小文本量，");
    println!("    也不远高于扫描件的最大噪点文本（OCR 前的零星识别碎片）。");
    println!();

    println!("Q2: IoU 阈值 0.8 — 跨页表格怎么办？");
    println!("A2: 跨页表格在页面 A 和 B 各有一半，IoU=0，融合算法会视为两个独立表格。");
    println!("    解决方案：增加\"跨页表格检测\"——若连续两页的底部/顶部各检测到表格，");
    println!("    且表头相同、列宽比例一致，则标记为跨页表格并合并为一个逻辑表。");
    println!("    或者对跨页表格使用\"相邻页拼接\"策略预先合并。");
    println!();

    println!("Q3: Docling 升级后 clause_id 变化，如何处理版本迁移？");
    println!("A3: clause_id 应解耦：用 content-hash（段落文本 SHA256）替代位置序号。");
    println!("    cl_001 = SHA256(段落文本内容)[:8]，而不是 SHA256(page+index)。");
    println!("    这样即使段落分割算法改变，相同文本内容的 clause_id 不变。");
    println!("    同时在 ParseMeta 中记录 parser_version，供下游做兼容性判断。");
    println!();

    println!("═══ 全部任务完成 ═══");
}
