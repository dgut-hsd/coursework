fn main() {
    if let Err(err) = lesson2::run_demo() {
        eprintln!("demo failed: {err}");
        std::process::exit(1);
    }
}
