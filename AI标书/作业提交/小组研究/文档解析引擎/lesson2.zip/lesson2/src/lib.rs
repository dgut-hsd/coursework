use anyhow::{anyhow, Context, Result};
use serde::{Deserialize, Serialize};
use std::fs;
use std::io::{BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
use std::sync::mpsc;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

// ── JSON protocol types ──────────────────────────────────────────────

#[derive(Serialize, Deserialize, Debug)]
struct EchoRequest {
    action: String,
    payload: serde_json::Value,
}

#[derive(Serialize, Deserialize, Debug)]
struct EchoResponse {
    status: String,
    result: serde_json::Value,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub(crate) struct ParseRequest {
    action: String,
    file_path: String,
    options: serde_json::Value,
}

#[derive(Serialize, Deserialize, Debug)]
pub(crate) struct ParseResponse {
    status: String,
    result: Option<serde_json::Value>,
    message: Option<String>,
}

#[derive(Serialize, Deserialize, Debug)]
pub struct ParseSummary {
    pub pages: usize,
    pub blocks: usize,
    pub tables: usize,
}

// ── PythonWorker — single subprocess via stdin/stdout JSON ───────────

struct PythonWorker {
    child: Child,
    stdin: ChildStdin,
    stdout: BufReader<ChildStdout>,
}

impl PythonWorker {
    fn spawn(script: &str) -> Result<Self> {
        let mut child = Command::new("python")
            .arg(script)
            .env("PYTHONIOENCODING", "utf-8")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .with_context(|| format!("failed to spawn python worker for {script}"))?;

        let stdin = child
            .stdin
            .take()
            .ok_or_else(|| anyhow!("stdin was not piped"))?;
        let stdout = BufReader::new(
            child
                .stdout
                .take()
                .ok_or_else(|| anyhow!("stdout was not piped"))?,
        );

        Ok(Self {
            child,
            stdin,
            stdout,
        })
    }

    fn request<T: Serialize, U: for<'de> Deserialize<'de>>(
        &mut self,
        value: &T,
    ) -> Result<U> {
        serde_json::to_writer(&mut self.stdin, value)?;
        writeln!(self.stdin)?;
        self.stdin.flush()?;

        let mut line = String::new();
        self.stdout.read_line(&mut line)?;
        let line = line.trim();
        if line.is_empty() {
            return Err(anyhow!("worker returned an empty response"));
        }

        serde_json::from_str(line)
            .with_context(|| format!("failed to parse response: {line}"))
    }
}

impl Drop for PythonWorker {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
    }
}

// ── ConcurrentPool — mpsc-based true-concurrency process pool ────────

/// A job submitted to the worker pool.
struct PoolJob {
    request: ParseRequest,
    result_tx: mpsc::Sender<Result<ParseResponse>>,
}

/// A process pool that runs N Python workers in background threads.
///
/// - Workers are pre-spawned (each pre-loads the Python runtime).
/// - Jobs are distributed via an mpsc channel — 4 workers + 6 queued = 10 total.
/// - Rust-side timeout via `recv_timeout`.
pub struct ConcurrentPool {
    job_tx: mpsc::Sender<PoolJob>,
    /// Kept so threads are joined on drop (optional, but clean).
    _handles: Vec<thread::JoinHandle<()>>,
}

impl ConcurrentPool {
    /// Pre-fork `size` Python worker processes, each running in its own OS thread.
    pub fn new(script: &str, size: usize) -> Result<Self> {
        let (job_tx, job_rx) = mpsc::channel::<PoolJob>();
        let job_rx = Arc::new(Mutex::new(job_rx));

        let mut handles = Vec::with_capacity(size);
        for worker_id in 0..size {
            let job_rx = Arc::clone(&job_rx);
            let script = script.to_string();
            let handle = thread::spawn(move || {
                run_worker_loop(worker_id, &script, job_rx);
            });
            handles.push(handle);
        }

        Ok(Self {
            job_tx,
            _handles: handles,
        })
    }

    /// Submit a parse job and wait up to `timeout` for the result.
    ///
    /// Returns `Err` on timeout → caller should use fallback.
    pub(crate) fn parse(&self, request: ParseRequest, timeout: Duration) -> Result<ParseResponse> {
        let (result_tx, result_rx) = mpsc::channel();
        self.job_tx
            .send(PoolJob { request, result_tx })
            .with_context(|| "failed to send job to worker pool")?;

        match result_rx.recv_timeout(timeout) {
            Ok(result) => result,
            Err(mpsc::RecvTimeoutError::Timeout) => Err(anyhow!(
                "python parse timed out after {:.1}s — triggering fallback",
                timeout.as_secs_f64()
            )),
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                Err(anyhow!("worker pool shut down unexpectedly"))
            }
        }
    }
}

/// Each worker thread runs this loop: receive job → execute → send result.
fn run_worker_loop(
    worker_id: usize,
    script: &str,
    job_rx: Arc<Mutex<mpsc::Receiver<PoolJob>>>,
) {
    let mut worker = spawn_worker_with_retry(worker_id, script);

    loop {
        // Receive next job (release lock immediately after).
        let job = {
            let rx = job_rx.lock().unwrap();
            match rx.recv() {
                Ok(job) => job,
                Err(_) => break, // All senders dropped → pool shutting down.
            }
        };

        let result = worker.request::<ParseRequest, ParseResponse>(&job.request);

        // If the Python subprocess died, try to respawn once.
        if result.is_err() {
            eprintln!(
                "[worker {worker_id}] request failed (Python may have crashed), respawning..."
            );
            drop(worker);
            worker = spawn_worker_with_retry(worker_id, script);
        }

        // Send result back. If the caller already timed out and dropped its
        // receiver, we MUST kill & respawn the worker — Python's stdout now
        // has a stale response queued that would poison the next request.
        if job.result_tx.send(result).is_err() {
            eprintln!(
                "[worker {worker_id}] caller timed out — killing dirty worker and respawning"
            );
            drop(worker); // kill() + wait() via Drop
            worker = spawn_worker_with_retry(worker_id, script);
        }
    }
}

fn spawn_worker_with_retry(worker_id: usize, script: &str) -> PythonWorker {
    loop {
        match PythonWorker::spawn(script) {
            Ok(w) => return w,
            Err(e) => {
                eprintln!(
                    "[worker {worker_id}] failed to spawn Python: {e} — retrying in 1s..."
                );
                thread::sleep(Duration::from_secs(1));
            }
        }
    }
}

// ── Fallback & summary helpers ───────────────────────────────────────

/// Pure-Rust fallback parser — used when Python times out or errors.
fn fallback_summary(file_path: &Path) -> Result<ParseSummary> {
    let content = fs::read_to_string(file_path)
        .with_context(|| format!("failed to read {file_path:?}"))?;
    let lines: Vec<&str> = content
        .lines()
        .filter(|line| !line.trim().is_empty())
        .collect();
    let pages = lines.len().max(1) / 20 + 1;
    let blocks = lines.len().max(1);
    let tables = if content.contains("表格") || content.to_lowercase().contains("table") {
        1
    } else {
        0
    };
    Ok(ParseSummary { pages, blocks, tables })
}

/// Minimal parse — only count lines & pages, no content analysis.
/// Used as last-resort fallback.
fn minimal_summary(file_path: &Path) -> ParseSummary {
    let content = fs::read_to_string(file_path).unwrap_or_default();
    let line_count = content.lines().count().max(1);
    ParseSummary {
        pages: line_count / 25 + 1,
        blocks: line_count,
        tables: 0,
    }
}

fn parse_summary_from_value(value: serde_json::Value) -> Result<ParseSummary> {
    let object = value
        .as_object()
        .ok_or_else(|| anyhow!("parse result must be an object"))?;
    let pages = object
        .get("pages")
        .and_then(|v| v.as_u64())
        .unwrap_or(0) as usize;
    let blocks = object
        .get("blocks")
        .and_then(|v| v.as_u64())
        .unwrap_or(0) as usize;
    let tables = object
        .get("tables")
        .and_then(|v| v.as_u64())
        .unwrap_or(0) as usize;
    Ok(ParseSummary { pages, blocks, tables })
}

// ── Demo entry point ─────────────────────────────────────────────────

pub fn run_demo() -> Result<()> {
    // Task 1 — echo bridge
    let echo = run_task1()?;
    println!("task1 echo: {echo}");

    // Task 2 — single-file Docling parse
    let sample_path = Path::new("samples/sample1.txt");
    let summary = run_task2(sample_path)?;
    println!("task2 summary: {summary:?}");

    // Task 3 — 4-worker pool × 10 files = 4 concurrent + 6 queued
    let summaries = run_task3(Path::new("samples"), 4, 10)?;
    println!("task3 summaries ({n} files):", n = summaries.len());
    for (i, s) in summaries.iter().enumerate() {
        println!("  [{i}] pages={} blocks={} tables={}", s.pages, s.blocks, s.tables);
    }
    Ok(())
}

// ── Path helper ──────────────────────────────────────────────────────

fn resolve_workspace_path(path: &Path) -> PathBuf {
    if path.is_absolute() {
        path.to_path_buf()
    } else {
        let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        manifest_dir.join(path)
    }
}

// ── Task implementations ─────────────────────────────────────────────

/// Task 1: Rust↔Python echo bridge.
fn run_task1() -> Result<serde_json::Value> {
    let mut worker = PythonWorker::spawn("python/echo_worker.py")?;
    let request = EchoRequest {
        action: "echo".into(),
        payload: serde_json::json!({ "message": "hello" }),
    };
    let response: EchoResponse = worker.request(&request)?;

    if response.status != "ok" {
        return Err(anyhow!(
            "echo worker returned status {}",
            response.status
        ));
    }

    Ok(serde_json::json!({
        "status": response.status,
        "result": response.result,
    }))
}

/// Task 2: Single-file Docling parse with serde extraction.
fn run_task2(file_path: &Path) -> Result<ParseSummary> {
    let mut worker = PythonWorker::spawn("python/docling_worker.py")?;
    let resolved = resolve_workspace_path(file_path);
    let request = ParseRequest {
        action: "parse".into(),
        file_path: resolved.to_string_lossy().into_owned(),
        options: serde_json::json!({ "extract_tables": true }),
    };
    let response: ParseResponse = worker.request(&request)?;

    match response.status.as_str() {
        "ok" => parse_summary_from_value(
            response
                .result
                .ok_or_else(|| anyhow!("missing parse result"))?,
        ),
        "error" => Err(anyhow!(
            "python worker error: {}",
            response.message.unwrap_or_default()
        )),
        other => Err(anyhow!("unexpected worker status: {other}")),
    }
}

/// Task 3: Concurrent pool — 4 workers, 10 files (4 concurrent + 6 queued).
///
/// - Two files are injected with a long `sleep_seconds` to trigger Rust-side timeout.
/// - On timeout, falls back to pure-Rust parsing.
fn run_task3(
    samples_dir: &Path,
    worker_count: usize,
    file_count: usize,
) -> Result<Vec<ParseSummary>> {
    let pool = Arc::new(ConcurrentPool::new(
        "python/docling_worker.py",
        worker_count,
    )?);

    let resolved_dir = resolve_workspace_path(samples_dir);
    let mut files: Vec<PathBuf> = fs::read_dir(resolved_dir)?
        .filter_map(|entry| entry.ok())
        .map(|entry| entry.path())
        .filter(|path| path.is_file())
        .collect();

    if files.is_empty() {
        return Err(anyhow!("no sample files found in {samples_dir:?}"));
    }
    files.sort();

    // Build N tasks, cycling through available sample files.
    // Files at indices 3 and 7 get a long sleep to trigger Rust-side timeout.
    let tasks: Vec<(usize, PathBuf, f64)> = (0..file_count)
        .map(|i| {
            let path = files[i % files.len()].clone();
            let sleep_seconds = if i == 3 || i == 7 { 3.0 } else { 0.05 };
            (i, path, sleep_seconds)
        })
        .collect();

    // Submit all tasks concurrently — each in its own thread.
    let handles: Vec<thread::JoinHandle<(usize, ParseSummary)>> = tasks
        .into_iter()
        .map(|(idx, path, sleep_seconds)| {
            let pool = Arc::clone(&pool);
            thread::spawn(move || {
                let request = ParseRequest {
                    action: "parse".into(),
                    file_path: path.to_string_lossy().into_owned(),
                    options: serde_json::json!({
                        "extract_tables": true,
                        "sleep_seconds": sleep_seconds,
                    }),
                };

                // Rust-side timeout: 500ms. Python sleeps 3s for files 3 & 7 → timeout.
                let timeout = Duration::from_millis(500);
                let summary = match pool.parse(request, timeout) {
                    Ok(resp) if resp.status == "ok" => {
                        match resp.result {
                            Some(val) => {
                                parse_summary_from_value(val).unwrap_or_else(|e| {
                                    eprintln!("[{idx}] parse result invalid: {e}, using fallback");
                                    fallback_summary(&path).unwrap_or_else(|_| minimal_summary(&path))
                                })
                            }
                            None => {
                                eprintln!("[{idx}] missing result, using fallback");
                                fallback_summary(&path).unwrap_or_else(|_| minimal_summary(&path))
                            }
                        }
                    }
                    Ok(resp) => {
                        eprintln!(
                            "[{idx}] python returned status={}: {} — using fallback",
                            resp.status,
                            resp.message.unwrap_or_default()
                        );
                        fallback_summary(&path).unwrap_or_else(|_| minimal_summary(&path))
                    }
                    Err(e) => {
                        eprintln!("[{idx}] {e} — using fallback");
                        fallback_summary(&path).unwrap_or_else(|_| minimal_summary(&path))
                    }
                };
                (idx, summary)
            })
        })
        .collect();

    // Collect and sort by original index.
    let mut results: Vec<(usize, ParseSummary)> = handles
        .into_iter()
        .map(|h| h.join().expect("submission thread panicked"))
        .collect();
    results.sort_by_key(|(idx, _)| *idx);

    Ok(results.into_iter().map(|(_, s)| s).collect())
}

// ── Tests ────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn task1_echo_round_trip_works() {
        let output = run_task1().unwrap();
        assert_eq!(output["status"], "ok");
        assert_eq!(output["result"]["message"], "hello");
    }

    #[test]
    fn task2_docling_summary_is_extracted() {
        let summary = run_task2(Path::new("samples/sample1.txt")).unwrap();
        assert!(summary.pages >= 1);
        assert!(summary.blocks >= 1);
    }

    #[test]
    fn task3_concurrent_pool_with_timeout_and_fallback() {
        let summaries = run_task3(Path::new("samples"), 4, 10).unwrap();
        // All 10 files must complete — some via Python, some via timeout→fallback.
        assert_eq!(summaries.len(), 10);
        // Every summary must have at least 1 page.
        assert!(summaries.iter().all(|s| s.pages > 0));
    }

    #[test]
    fn task3_fewer_workers_than_files_still_completes() {
        // 2 workers × 8 files = stress test for queuing.
        let summaries = run_task3(Path::new("samples"), 2, 8).unwrap();
        assert_eq!(summaries.len(), 8);
        assert!(summaries.iter().all(|s| s.pages > 0));
    }

    #[test]
    fn fallback_summary_detects_table_keywords() {
        let summary = fallback_summary(Path::new("samples/sample1.txt")).unwrap();
        assert_eq!(summary.tables, 1); // "A table is included"
    }

    #[test]
    fn fallback_summary_no_table() {
        let summary = fallback_summary(Path::new("samples/sample2.txt")).unwrap();
        assert_eq!(summary.tables, 0);
    }

    #[test]
    fn concurrent_pool_timeout_triggers_fallback() {
        let pool = ConcurrentPool::new("python/docling_worker.py", 2).unwrap();
        let path = resolve_workspace_path(Path::new("samples/sample1.txt"));

        let request = ParseRequest {
            action: "parse".into(),
            file_path: path.to_string_lossy().into_owned(),
            options: serde_json::json!({
                "extract_tables": true,
                "sleep_seconds": 3.0, // Python will sleep 3s
            }),
        };

        // Timeout at 100ms — much shorter than 3s sleep.
        let result = pool.parse(request, Duration::from_millis(100));
        assert!(result.is_err());
        assert!(
            result
                .unwrap_err()
                .to_string()
                .contains("timed out"),
            "expected timeout message"
        );
    }
}
