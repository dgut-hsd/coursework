import subprocess
import json

proc = subprocess.Popen(['python', 'python/docling_worker.py'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
req = json.dumps({'action':'parse','file_path':'samples/招标文件.txt','options':{'extract_tables':True}})
proc.stdin.write(req + '\n')
proc.stdin.flush()
print(proc.stdout.readline())
proc.terminate()
proc.wait(timeout=5)
print(proc.stderr.read())
