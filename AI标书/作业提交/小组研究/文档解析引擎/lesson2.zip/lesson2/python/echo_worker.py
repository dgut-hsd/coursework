import json
import sys

# Ensure UTF-8 I/O on all platforms (especially Windows with GBK codepage).
if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

for line in sys.stdin:
    payload = json.loads(line.strip())
    response = {"status": "ok", "result": payload.get("payload", {})}
    print(json.dumps(response), flush=True)
