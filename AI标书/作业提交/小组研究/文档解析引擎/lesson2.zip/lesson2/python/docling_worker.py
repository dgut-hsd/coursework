import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

# Ensure UTF-8 I/O on all platforms (especially Windows with GBK codepage).
if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def build_summary(file_path: str, options: Optional[Dict[str, Any]] = None) -> dict:
    options = options or {}
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(file_path)
    content = path.read_text(encoding="utf-8", errors="ignore")
    lines = [line.strip() for line in content.splitlines() if line.strip()]
    pages = max(1, len(lines) // 20 + 1)
    blocks = max(1, len(lines))
    tables = 1 if "表格" in content or "table" in content.lower() else 0

    sleep_seconds = float(options.get("sleep_seconds", 0.0))
    # Rust-side timeout handles slow workers — Python just sleeps and
    # lets the Rust caller decide when to give up.
    time.sleep(sleep_seconds)
    return {"pages": pages, "blocks": blocks, "tables": tables, "text_preview": content[:120]}

for line in sys.stdin:
    req = json.loads(line.strip())
    action = req.get("action")
    if action != "parse":
        print(json.dumps({"status":"error","message":"unsupported action"}), flush=True)
        continue
    try:
        result = build_summary(req["file_path"], req.get("options", {}))
        print(json.dumps({"status":"ok","result": result}), flush=True)
    except Exception as exc:
        print(json.dumps({"status":"error","message":str(exc)}), flush=True)
