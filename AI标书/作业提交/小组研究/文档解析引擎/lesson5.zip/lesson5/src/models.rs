//! Data models for the Parse Worker Simulator.
//!
//! Defines the core structures: ParsedDocument, ParseTask, PageResult, and
//! the status enums that track the lifecycle of a parse operation.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

/// Top-level status of a parse task.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum ParseStatus {
    /// All pages parsed successfully.
    Completed,
    /// Some pages parsed, some failed — degraded output available.
    PartialFailure,
    /// The entire parse timed out (guard timer exceeded).
    Timeout,
    /// Unrecoverable failure (invalid file, crash, etc.).
    Failed,
}

/// Per-page outcome.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PageResult {
    pub page_number: u32,
    pub status: PageStatus,
    /// Parsed text content (if successful).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub content: Option<String>,
    /// Error description (if failed or timed out).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
    /// Which engine handled this page.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub engine: Option<String>,
    /// Time taken for this page in milliseconds.
    pub elapsed_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum PageStatus {
    Success,
    Failed,
    Timeout,
}

/// The top-level parsed document output.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParsedDocument {
    /// Unique document ID (UUID v4).
    pub document_id: String,
    /// SHA-256 hex digest of the original file bytes.
    pub file_hash: String,
    /// Overall parse status.
    pub status: ParseStatus,
    /// Total page count detected.
    pub total_pages: u32,
    /// How many pages succeeded.
    pub successful_pages: u32,
    /// How many pages failed.
    pub failed_pages: u32,
    /// Per-page results, ordered by page number.
    pub pages: Vec<PageResult>,
    /// Strategy used: "single" or "sharded-N"
    pub strategy: String,
    /// Name of the primary engine used.
    pub engine: String,
    /// Human-readable summary for logging.
    pub summary: String,
    /// ISO-8601 timestamp of parse start.
    pub created_at: String,
    /// Total wall-clock time in milliseconds.
    pub total_elapsed_ms: u64,
}

/// A parse task as tracked by the server.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParseTask {
    pub task_id: String,
    pub file_hash: String,
    pub file_name: String,
    pub file_size_bytes: u64,
    pub status: TaskStatus,
    /// Present once parsing finishes.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub document: Option<ParsedDocument>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum TaskStatus {
    /// Task accepted, queued for processing.
    Queued,
    /// Worker is actively parsing.
    Processing,
    /// Parse completed (may still be PartialFailure).
    Completed,
    /// Parse timed out.
    Timeout,
    /// Unrecoverable error.
    Failed,
}

/// Request body for POST /api/v1/parse (JSON fallback — normally multipart).
#[derive(Debug, Deserialize)]
pub struct ParseRequest {
    /// Optional: hint whether to simulate corruption (for testing).
    #[serde(default)]
    pub simulate_corrupt: bool,
    /// Optional: hint whether to simulate a timeout (for testing).
    #[serde(default)]
    pub simulate_timeout: bool,
    /// Optional: override the page count for simulation.
    #[serde(default)]
    pub forced_page_count: Option<u32>,
}

/// Response for a newly-submitted parse task.
#[derive(Debug, Serialize)]
pub struct SubmitResponse {
    pub task_id: String,
    pub document_id: Option<String>,
    /// true if the result was served from the dedup cache.
    pub cache_hit: bool,
    pub status: TaskStatus,
    pub message: String,
}

/// Simple health-check response.
#[derive(Debug, Serialize)]
pub struct HealthResponse {
    pub status: &'static str,
    pub cache_entries: usize,
}
