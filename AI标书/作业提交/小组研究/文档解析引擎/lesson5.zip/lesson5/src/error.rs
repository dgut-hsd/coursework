//! Error types for the parse worker simulator.
//!
//! Covers the three failure boundaries the demo must exercise:
//! 1. Engine timeout (guard timer)
//! 2. Invalid / malformed output (parse engine returned garbage)
//! 3. Degraded-path fallback when a subset of pages fail.

use axum::{
    http::StatusCode,
    response::{IntoResponse, Response},
};
use std::fmt;

/// Top-level application error.
#[derive(Debug)]
pub enum AppError {
    /// File too large or unreadable.
    FileError(String),
    /// The chosen engine timed out.
    Timeout {
        engine: String,
        elapsed_ms: u64,
        limit_ms: u64,
    },
    /// Engine returned output that failed JSON schema validation.
    InvalidOutput {
        engine: String,
        reason: String,
    },
    /// One or more pages failed; a degraded document is available.
    PartialFailure {
        document_id: String,
        failed: u32,
        total: u32,
    },
    /// Task not found.
    NotFound(String),
    /// Internal / unexpected error.
    Internal(String),
}

impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::FileError(msg) => write!(f, "文件错误: {msg}"),
            Self::Timeout { engine, elapsed_ms, limit_ms } => {
                write!(f, "引擎 {engine} 超时: {elapsed_ms}ms / {limit_ms}ms")
            }
            Self::InvalidOutput { engine, reason } => {
                write!(f, "引擎 {engine} 输出非法: {reason}")
            }
            Self::PartialFailure { document_id, failed, total } => {
                write!(f, "文档 {document_id} 部分失败: {failed}/{total} 页出错")
            }
            Self::NotFound(id) => write!(f, "任务 {id} 不存在"),
            Self::Internal(msg) => write!(f, "内部错误: {msg}"),
        }
    }
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, message) = match &self {
            Self::FileError(msg) => (StatusCode::BAD_REQUEST, msg.clone()),
            Self::Timeout { .. } => (StatusCode::GATEWAY_TIMEOUT, self.to_string()),
            Self::InvalidOutput { .. } => (StatusCode::UNPROCESSABLE_ENTITY, self.to_string()),
            Self::PartialFailure { .. } => (StatusCode::OK, self.to_string()),
            Self::NotFound(_) => (StatusCode::NOT_FOUND, self.to_string()),
            Self::Internal(_) => (StatusCode::INTERNAL_SERVER_ERROR, self.to_string()),
        };

        let body = serde_json::json!({
            "error": true,
            "message": message,
        });

        (status, axum::Json(body)).into_response()
    }
}

impl From<std::io::Error> for AppError {
    fn from(e: std::io::Error) -> Self {
        Self::FileError(e.to_string())
    }
}
