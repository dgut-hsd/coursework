//! In-memory deduplication cache keyed by SHA-256 file hash.
//!
//! Mechanism 1 (required): Same file submitted twice → second request
//! returns the cached `document_id` immediately without re-parsing.

use crate::models::ParsedDocument;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;

/// Thread-safe in-memory cache mapping file_hash → ParsedDocument.
#[derive(Clone, Default)]
pub struct DedupCache {
    inner: Arc<RwLock<HashMap<String, ParsedDocument>>>,
}

impl DedupCache {
    /// Create a new empty cache.
    pub fn new() -> Self {
        Self {
            inner: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    /// Look up a hash. Returns `Some(document)` if already parsed.
    pub async fn get(&self, hash: &str) -> Option<ParsedDocument> {
        let cache = self.inner.read().await;
        cache.get(hash).cloned()
    }

    /// Store a parsed document.
    pub async fn set(&self, hash: &str, doc: ParsedDocument) {
        let mut cache = self.inner.write().await;
        cache.insert(hash.to_string(), doc);
    }

    /// Check if a hash exists in the cache.
    pub async fn contains(&self, hash: &str) -> bool {
        let cache = self.inner.read().await;
        cache.contains_key(hash)
    }

    /// Return the number of cached entries.
    pub async fn len(&self) -> usize {
        let cache = self.inner.read().await;
        cache.len()
    }

    /// Remove all entries.
    #[allow(dead_code)]
    pub async fn clear(&self) {
        let mut cache = self.inner.write().await;
        cache.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::models::{PageResult, PageStatus, ParseStatus, ParsedDocument};

    fn make_doc(hash: &str, doc_id: &str) -> ParsedDocument {
        ParsedDocument {
            document_id: doc_id.into(),
            file_hash: hash.into(),
            status: ParseStatus::Completed,
            total_pages: 1,
            successful_pages: 1,
            failed_pages: 0,
            pages: vec![PageResult {
                page_number: 1,
                status: PageStatus::Success,
                content: Some("hello".into()),
                error: None,
                engine: Some("sim-engine".into()),
                elapsed_ms: 10,
            }],
            strategy: "single".into(),
            engine: "sim-engine".into(),
            summary: "ok".into(),
            created_at: "2024-01-01T00:00:00Z".into(),
            total_elapsed_ms: 10,
        }
    }

    #[tokio::test]
    async fn cache_hit_returns_same_document() {
        let cache = DedupCache::new();
        let doc = make_doc("abc123", "doc-1");
        cache.set("abc123", doc.clone()).await;

        let hit = cache.get("abc123").await;
        assert!(hit.is_some());
        assert_eq!(hit.unwrap().document_id, "doc-1");
    }

    #[tokio::test]
    async fn cache_miss_returns_none() {
        let cache = DedupCache::new();
        assert!(cache.get("nonexistent").await.is_none());
    }

    #[tokio::test]
    async fn cache_contains_works() {
        let cache = DedupCache::new();
        assert!(!cache.contains("abc").await);
        cache.set("abc", make_doc("abc", "d1")).await;
        assert!(cache.contains("abc").await);
    }
}
