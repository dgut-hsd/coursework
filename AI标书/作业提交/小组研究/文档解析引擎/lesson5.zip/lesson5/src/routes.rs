//! HTTP route handlers for the parse worker simulator.
//!
//! ## Endpoints
//!
//! | Method | Path                    | Purpose                          |
//! |--------|-------------------------|----------------------------------|
//! | GET    | /health                 | Liveness + cache stats           |
//! | POST   | /api/v1/parse           | Submit file (multipart or JSON)  |
//! | GET    | /api/v1/parse/:task_id  | Poll task status / result        |

use crate::error::AppError;
use crate::models::{
    HealthResponse, ParseStatus, ParseTask, SubmitResponse, TaskStatus,
};
use crate::parser;
use crate::AppState;
use axum::{
    extract::{Multipart, Path, Query, State},
    http::StatusCode,
    response::IntoResponse,
    Json,
};
use chrono::Utc;
use serde::Deserialize;
use uuid::Uuid;

/// Query params for POST /api/v1/parse (when using non-multipart mode or
/// adding simulation flags).
#[derive(Deserialize, Default)]
pub struct ParseQuery {
    pub simulate_corrupt: Option<bool>,
    pub simulate_timeout: Option<bool>,
    pub pages: Option<u32>,
}

// ---------------------------------------------------------------------------
// GET /health
// ---------------------------------------------------------------------------

pub async fn health(State(state): State<AppState>) -> Json<HealthResponse> {
    Json(HealthResponse {
        status: "ok",
        cache_entries: state.cache.len().await,
    })
}

// ---------------------------------------------------------------------------
// POST /api/v1/parse  (multipart form)
// ---------------------------------------------------------------------------

/// The primary endpoint: accepts a file via multipart upload, computes its
/// SHA-256 hash, checks the dedup cache, and — if not cached — parses it.
pub async fn submit_parse(
    State(state): State<AppState>,
    Query(query): Query<ParseQuery>,
    mut multipart: Multipart,
) -> Result<impl IntoResponse, AppError> {
    let mut file_data: Vec<u8> = Vec::new();
    let mut file_name = String::from("unknown");

    // Read the first file field from the multipart form
    while let Ok(Some(field)) = multipart.next_field().await {
        let name = field.name().unwrap_or("").to_string();
        if name == "file" {
            file_name = field
                .file_name()
                .unwrap_or("unknown.bin")
                .to_string();
            file_data = field.bytes().await.unwrap_or_default().to_vec();
            break;
        }
    }

    // If no file field was found, check for raw body (smaller clients)
    if file_data.is_empty() {
        // Try reading the multipart body as the file itself (bare upload)
        return Err(AppError::FileError(
            "未检测到上传文件。请使用 multipart/form-data，字段名为 'file'。".into(),
        ));
    }

    let file_size = file_data.len() as u64;
    let file_hash = parser::compute_hash(&file_data);

    // ---- Mechanism 1: Dedup cache check ----
    if let Some(cached_doc) = state.cache.get(&file_hash).await {
        tracing::info!(
            "缓存命中: hash={file_hash} → doc_id={} (复用结果，跳过解析)",
            cached_doc.document_id
        );

        let task_id = Uuid::new_v4().to_string();
        let task = ParseTask {
            task_id: task_id.clone(),
            file_hash: file_hash.clone(),
            file_name,
            file_size_bytes: file_size,
            status: TaskStatus::Completed,
            document: Some(cached_doc.clone()),
            created_at: Utc::now(),
        };

        // Store task for polling
        {
            let mut tasks = state.tasks.write().await;
            tasks.insert(task_id.clone(), task);
        }

        return Ok((
            StatusCode::OK,
            Json(SubmitResponse {
                task_id,
                document_id: Some(cached_doc.document_id),
                cache_hit: true,
                status: TaskStatus::Completed,
                message: "缓存命中：文件已解析过，直接复用结果。".into(),
            }),
        ));
    }

    // ---- Not cached — queue and parse ----
    let task_id = Uuid::new_v4().to_string();

    let task = ParseTask {
        task_id: task_id.clone(),
        file_hash: file_hash.clone(),
        file_name: file_name.clone(),
        file_size_bytes: file_size,
        status: TaskStatus::Queued,
        document: None,
        created_at: Utc::now(),
    };

    {
        let mut tasks = state.tasks.write().await;
        tasks.insert(task_id.clone(), task);
    }

    // Clone what we need for the background job
    let cache = state.cache.clone();
    let tasks_map = state.tasks.clone();
    let tid = task_id.clone();
    let hash = file_hash.clone();

    let simulate_corrupt = query.simulate_corrupt.unwrap_or(false);
    let simulate_timeout = query.simulate_timeout.unwrap_or(false);
    let forced_pages = query.pages;

    // Spawn the parse as a background task (simulates the Worker thread)
    tokio::spawn(async move {
        // Mark as processing
        {
            let mut tasks = tasks_map.write().await;
            if let Some(t) = tasks.get_mut(&tid) {
                t.status = TaskStatus::Processing;
            }
        }

        tracing::info!("开始解析: task={tid} hash={hash} size={file_size}");

        let result = parser::parse_document(
            &file_data,
            simulate_corrupt,
            simulate_timeout,
            forced_pages,
        )
        .await;

        match result {
            Ok(doc) => {
                let doc_status = doc.status.clone();
                let doc_id = doc.document_id.clone();
                tracing::info!("解析完成: task={tid} doc={doc_id} status={doc_status:?}");

                // Store in dedup cache for future reuse
                cache.set(&hash, doc.clone()).await;

                // Update task record
                let mut tasks = tasks_map.write().await;
                if let Some(t) = tasks.get_mut(&tid) {
                    t.status = match doc_status {
                        ParseStatus::Completed => TaskStatus::Completed,
                        ParseStatus::PartialFailure => TaskStatus::Completed, // still completed with degraded output
                        ParseStatus::Timeout => TaskStatus::Timeout,
                        ParseStatus::Failed => TaskStatus::Failed,
                    };
                    t.document = Some(doc);
                }
            }
            Err(e) => {
                tracing::error!("解析失败: task={tid} error={e}");
                let mut tasks = tasks_map.write().await;
                if let Some(t) = tasks.get_mut(&tid) {
                    t.status = TaskStatus::Failed;
                }
            }
        }
    });

    Ok((
        StatusCode::ACCEPTED,
        Json(SubmitResponse {
            task_id: task_id.clone(),
            document_id: None,
            cache_hit: false,
            status: TaskStatus::Queued,
            message: format!(
                "任务已提交 (task_id={task_id})。文件哈希={file_hash}，大小={file_size} 字节。"
            ),
        }),
    ))
}

// ---------------------------------------------------------------------------
// GET /api/v1/parse/:task_id
// ---------------------------------------------------------------------------

pub async fn get_task_status(
    State(state): State<AppState>,
    Path(task_id): Path<String>,
) -> Result<impl IntoResponse, AppError> {
    let tasks = state.tasks.read().await;

    match tasks.get(&task_id) {
        Some(task) => Ok((
            StatusCode::OK,
            Json(serde_json::json!({
                "task_id": task.task_id,
                "file_hash": task.file_hash,
                "file_name": task.file_name,
                "file_size_bytes": task.file_size_bytes,
                "status": task.status,
                "document": task.document,
                "created_at": task.created_at.to_rfc3339(),
            })),
        )),
        None => Err(AppError::NotFound(task_id)),
    }
}

// ---------------------------------------------------------------------------
// GET /api/v1/parse/:task_id/result
// ---------------------------------------------------------------------------

pub async fn get_task_result(
    State(state): State<AppState>,
    Path(task_id): Path<String>,
) -> Result<impl IntoResponse, AppError> {
    let tasks = state.tasks.read().await;

    match tasks.get(&task_id) {
        Some(task) => match &task.document {
            Some(doc) => Ok((StatusCode::OK, Json(doc.clone()))),
            None => Err(AppError::NotFound(format!(
                "任务 {task_id} 尚未完成解析，当前状态: {:?}",
                task.status
            ))),
        },
        None => Err(AppError::NotFound(task_id)),
    }
}
