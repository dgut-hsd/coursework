//! Simulated parse engine with strategy selection, timeout guards, and degraded
//! fallback paths.
//!
//! ## Required mechanisms demonstrated
//!
//! **Mechanism 1 — Dedup**: Handled by `cache.rs`; this module receives a
//! file hash and the caller (route handler) short-circuits before calling
//! `parse_document` if a cached result exists.
//!
//! **Mechanism 2 — Timeout / invalid output**: Each simulated engine call is
//! wrapped in `tokio::time::timeout`. If the guard fires, the page is marked
//! `PageStatus::Timeout` and the document degrades to `PARTIAL_FAILURE`.
//! Likewise, if the engine returns malformed output, we catch it and degrade
//! rather than crashing the entire parse.
//!
//! ## Strategy selection
//!
//! | Pages     | Strategy           |
//! |-----------|--------------------|
//! | ≤ 50      | single-process     |
//! | > 50      | sharded-4          |

use crate::error::AppError;
use crate::models::{PageResult, PageStatus, ParseStatus, ParsedDocument};
use rand::Rng;
use sha2::{Digest, Sha256};
use std::time::Instant;
use tokio::time::{timeout, Duration};
use uuid::Uuid;

/// Per-page timeout: if a single page takes longer than this we mark it
/// TIMEOUT and fall through to the next page.
const PAGE_TIMEOUT_MS: u64 = 2_000;

/// Simulated base latency per page in milliseconds (to mimic ML inference).
const BASE_MS_PER_PAGE: u64 = 30;

/// Threshold for switching from single to sharded strategy.
const SHARD_THRESHOLD: u32 = 50;

/// Number of parallel shards for large documents.
const SHARD_COUNT: u32 = 4;

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Compute the SHA-256 hex digest of arbitrary bytes.
pub fn compute_hash(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    hex::encode(hasher.finalize())
}

/// Estimate a page count from a byte slice.
///
/// For real PDFs we look for the `\Type\Page` marker. For arbitrary binaries
/// we fall back to a size-based heuristic (~3 KB / page).
/// In simulation mode this can be overridden.
pub fn estimate_page_count(data: &[u8]) -> u32 {
    // Quick heuristic for PDF files: count "\Type /Page" (or similar) markers.
    // More robust: count "<</Type" near "/Page"
    let page_markers = data
        .windows(10)
        .filter(|w| {
            std::str::from_utf8(w)
                .map(|s| s.contains("/Page") || s.contains("Type/Page"))
                .unwrap_or(false)
        })
        .count() as u32;

    if page_markers > 0 {
        return page_markers.min(500); // cap at 500
    }

    // Fallback: ~3 KB per page heuristic
    (data.len() as u32 / 3072).max(1).min(500)
}

/// Parse document bytes, choosing strategy based on page count.
///
/// Returns `Ok(ParsedDocument)` even when some pages fail — the caller can
/// inspect `.status` to distinguish `COMPLETED` from `PARTIAL_FAILURE`.
pub async fn parse_document(
    data: &[u8],
    simulate_corrupt: bool,
    simulate_timeout: bool,
    forced_page_count: Option<u32>,
) -> Result<ParsedDocument, AppError> {
    let file_hash = compute_hash(data);
    let total_start = Instant::now();
    let document_id = Uuid::new_v4().to_string();

    let page_count = forced_page_count.unwrap_or_else(|| estimate_page_count(data));

    let (strategy, pages) = if page_count <= SHARD_THRESHOLD {
        // ---- Single-process path ----
        let pages =
            parse_single(data, page_count, simulate_corrupt, simulate_timeout).await;
        ("single".to_string(), pages)
    } else {
        // ---- Sharded path ----
        let pages =
            parse_sharded(data, page_count, SHARD_COUNT, simulate_corrupt, simulate_timeout)
                .await;
        (format!("sharded-{SHARD_COUNT}"), pages)
    };

    // Compute aggregate statistics
    let successful = pages.iter().filter(|p| p.status == PageStatus::Success).count() as u32;
    let failed = pages.iter().filter(|p| p.status == PageStatus::Failed).count() as u32;
    let timed_out = pages.iter().filter(|p| p.status == PageStatus::Timeout).count() as u32;

    let status = if failed == 0 && timed_out == 0 {
        ParseStatus::Completed
    } else if timed_out == page_count {
        ParseStatus::Timeout
    } else if failed + timed_out < page_count {
        ParseStatus::PartialFailure
    } else {
        ParseStatus::Failed
    };

    let total_elapsed = total_start.elapsed().as_millis() as u64;

    let summary = format!(
        "文档 {document_id}: {page_count} 页 | 策略={strategy} | \
         成功={successful} 失败={failed} 超时={timed_out} | \
         总耗时={total_elapsed}ms | 状态={status:?}"
    );

    Ok(ParsedDocument {
        document_id,
        file_hash,
        status,
        total_pages: page_count,
        successful_pages: successful,
        failed_pages: failed + timed_out,
        pages,
        strategy,
        engine: "sim-engine-v1".to_string(),
        summary,
        created_at: chrono::Utc::now().to_rfc3339(),
        total_elapsed_ms: total_elapsed,
    })
}

// ---------------------------------------------------------------------------
// Single-process path
// ---------------------------------------------------------------------------

async fn parse_single(
    data: &[u8],
    page_count: u32,
    corrupt: bool,
    force_timeout: bool,
) -> Vec<PageResult> {
    let mut results = Vec::with_capacity(page_count as usize);
    for p in 1..=page_count {
        results.push(simulate_page(data, p, corrupt, force_timeout).await);
    }
    results
}

// ---------------------------------------------------------------------------
// Sharded parallel path
// ---------------------------------------------------------------------------

async fn parse_sharded(
    data: &[u8],
    page_count: u32,
    shards: u32,
    corrupt: bool,
    force_timeout: bool,
) -> Vec<PageResult> {
    let shard_size = page_count.div_ceil(shards);
    let mut handles = Vec::new();

    for s in 0..shards {
        let start = s * shard_size + 1;
        let end = ((s + 1) * shard_size).min(page_count);
        if start > page_count {
            break;
        }
        let data = data.to_vec();
        handles.push(tokio::task::spawn(async move {
            let mut shard_results = Vec::new();
            for p in start..=end {
                shard_results.push(simulate_page(&data, p, corrupt, force_timeout).await);
            }
            shard_results
        }));
    }

    let shard_results = futures_util::future::join_all(handles).await;

    // Merge shard results in page order
    let mut all: Vec<PageResult> = Vec::with_capacity(page_count as usize);
    for handle_result in shard_results {
        if let Ok(mut pages) = handle_result {
            all.append(&mut pages);
        }
    }
    all.sort_by_key(|r| r.page_number);
    all
}

// ---------------------------------------------------------------------------
// Simulated single-page parse
// ---------------------------------------------------------------------------

/// Simulate one page of ML parsing with realistic failure modes.
///
/// Failure injection (controlled by flags):
/// - `corrupt`: every 3rd page produces malformed / invalid JSON output.
/// - `force_timeout`: the page sleep exceeds the timeout guard.
async fn simulate_page(
    _data: &[u8],
    page_number: u32,
    corrupt: bool,
    force_timeout: bool,
) -> PageResult {
    let page_start = Instant::now();

    // Base latency with jitter (±20%) to mimic real-world variance.
    // Scope the RNG so it's dropped before the .await — ThreadRng is !Send.
    let sleep_ms = {
        let mut rng = rand::thread_rng();
        let jitter: f64 = rng.gen_range(0.8..1.2);
        if force_timeout {
            // Exceed the timeout guard so the tokio::time::timeout fires
            PAGE_TIMEOUT_MS + 500
        } else {
            ((BASE_MS_PER_PAGE as f64) * jitter) as u64
        }
    };

    // Wrap in a timeout guard — this is **Mechanism 2**.
    let result = timeout(Duration::from_millis(PAGE_TIMEOUT_MS), async {
        tokio::time::sleep(Duration::from_millis(sleep_ms)).await;

        // Simulate corrupt output on every 3rd page when corrupt flag is set
        if corrupt && page_number % 3 == 0 {
            // Return a sentinel that we'll catch as "invalid output"
            Err::<String, &str>("MALFORMED_JSON")
        } else {
            Ok(generate_fake_content(page_number, _data))
        }
    })
    .await;

    let elapsed = page_start.elapsed().as_millis() as u64;

    match result {
        // Timeout guard fired
        Err(_elapsed) => PageResult {
            page_number,
            status: PageStatus::Timeout,
            content: None,
            error: Some(format!(
                "引擎超时: 超过 {PAGE_TIMEOUT_MS}ms — 降级路径激活"
            )),
            engine: Some("sim-engine-v1".into()),
            elapsed_ms: PAGE_TIMEOUT_MS,
        },
        // Completed within the guard
        Ok(inner_result) => match inner_result {
            Ok(content) => PageResult {
                page_number,
                status: PageStatus::Success,
                content: Some(content),
                error: None,
                engine: Some("sim-engine-v1".into()),
                elapsed_ms: elapsed,
            },
            Err(reason) => PageResult {
                page_number,
                status: PageStatus::Failed,
                content: None,
                error: Some(format!(
                    "引擎输出非法 JSON / 格式错误: {reason} — 降级路径激活"
                )),
                engine: Some("sim-engine-v1".into()),
                elapsed_ms: elapsed,
            },
        },
    }
}

/// Generate plausible fake parse output for a page.
fn generate_fake_content(page_number: u32, data: &[u8]) -> String {
    // Pick a deterministic "sentence" based on page number and file content
    let seed = data.iter().fold(page_number as u64, |acc, &b| {
        acc.wrapping_mul(31).wrapping_add(b as u64)
    });

    let snippets = [
        "## 第{page_number}页\n\n本页包含文本内容，解析引擎成功提取了所有结构化数据。",
        "## 第{page_number}页\n\n该页主要为表格数据，已转换为结构化 JSON 格式。",
        "## 第{page_number}页\n\n图像区域检测完成，OCR 识别准确率 98.7%。",
        "## 第{page_number}页\n\n段落连续性检查通过，无断行或缺失字符。",
    ];

    let idx = (seed as usize) % snippets.len();
    snippets[idx].replace("{page_number}", &page_number.to_string())
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn normal_small_document_completes() {
        let data = b"%PDF-1.4 fake pdf content for testing";
        let doc = parse_document(data, false, false, Some(3)).await.unwrap();
        assert_eq!(doc.status, ParseStatus::Completed);
        assert_eq!(doc.total_pages, 3);
        assert_eq!(doc.successful_pages, 3);
        assert_eq!(doc.strategy, "single");
    }

    #[tokio::test]
    async fn corrupt_pages_produce_partial_failure() {
        let data = b"%PDF-1.4 corrupt document simulation";
        let doc = parse_document(data, true, false, Some(9))
            .await
            .unwrap();
        // Every 3rd page among 9 → pages 3, 6, 9 fail → 3 failed
        assert_eq!(doc.status, ParseStatus::PartialFailure);
        assert!(doc.failed_pages > 0);
        assert!(doc.successful_pages > 0);
    }

    #[tokio::test]
    async fn timeout_produces_timeout_status() {
        let data = b"%PDF-1.4 timeout document";
        let doc = parse_document(data, false, true, Some(2))
            .await
            .unwrap();
        assert_eq!(doc.status, ParseStatus::Timeout);
        // All pages should be timeout
        for page in &doc.pages {
            assert_eq!(page.status, PageStatus::Timeout);
        }
    }

    #[tokio::test]
    async fn large_document_uses_sharded_strategy() {
        let data = b"%PDF-1.4 large document with many pages";
        let doc = parse_document(data, false, false, Some(100))
            .await
            .unwrap();
        assert_eq!(doc.strategy, "sharded-4");
        assert_eq!(doc.total_pages, 100);
    }

    #[tokio::test]
    async fn hash_computation_is_deterministic() {
        let h1 = compute_hash(b"hello world");
        let h2 = compute_hash(b"hello world");
        assert_eq!(h1, h2);

        let h3 = compute_hash(b"different content");
        assert_ne!(h1, h3);
    }

    #[tokio::test]
    async fn single_page_document_is_always_single_strategy() {
        let data = b"small file";
        let doc = parse_document(data, false, false, Some(1)).await.unwrap();
        assert_eq!(doc.strategy, "single");
        assert_eq!(doc.pages.len(), 1);
    }
}
