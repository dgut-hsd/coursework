//! Parse Worker Simulator — Day 5 Capstone
//!
//! ## 目标
//!
//! 一个最小解析 Worker 模拟器，验证两个核心机制：
//!
//! 1. **文件哈希去重** — 相同文件重复提交时识别并复用结果。
//! 2. **超时 / 非法输出降级** — 引擎超时或返回非法 JSON 时记录失败并选择降级路径。
//!
//! ## 启动
//!
//! ```sh
//! cargo run
//! # 监听 http://0.0.0.0:3000
//! ```
//!
//! ## API
//!
//! - `GET  /health`                      — 健康检查 + 缓存统计
//! - `POST /api/v1/parse`                — 提交文件 (multipart, field="file")
//! - `GET  /api/v1/parse/:task_id`        — 查询任务状态
//! - `GET  /api/v1/parse/:task_id/result` — 获取 ParsedDocument JSON
//!
//! ## 测试
//!
//! ```sh
//! cargo test
//! ```
//!
//! ## cURL 示例
//!
//! ```sh
//! # 正常解析
//! curl -F "file=@sample.pdf" "http://localhost:3000/api/v1/parse"
//!
//! # 模拟损坏文档（每 3 页失败 1 页）
//! curl -F "file=@sample.pdf" \
//!   "http://localhost:3000/api/v1/parse?simulate_corrupt=true&pages=9"
//!
//! # 模拟超时
//! curl -F "file=@sample.pdf" \
//!   "http://localhost:3000/api/v1/parse?simulate_timeout=true&pages=1"
//!
//! # 大文档分片（>50 页 → sharded-4）
//! curl -F "file=@sample.pdf" \
//!   "http://localhost:3000/api/v1/parse?pages=100"
//!
//! # 验证去重：同一文件提交两次，第二次秒返回
//! curl -F "file=@sample.pdf" "http://localhost:3000/api/v1/parse"
//! curl -F "file=@sample.pdf" "http://localhost:3000/api/v1/parse"
//! # 第二次应返回 cache_hit: true
//! ```

use parse_worker_simulator::AppState;

#[tokio::main]
async fn main() {
    // Initialize tracing (structured logging)
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "parse_worker_simulator=info,tower_http=info".into()),
        )
        .init();

    tracing::info!("Parse Worker Simulator 启动中...");

    let state = AppState::new();

    // Build router
    let app = axum::Router::new()
        .route("/health", axum::routing::get(parse_worker_simulator::routes::health))
        .route("/api/v1/parse", axum::routing::post(parse_worker_simulator::routes::submit_parse))
        .route(
            "/api/v1/parse/:task_id",
            axum::routing::get(parse_worker_simulator::routes::get_task_status),
        )
        .route(
            "/api/v1/parse/:task_id/result",
            axum::routing::get(parse_worker_simulator::routes::get_task_result),
        )
        .layer(
            tower_http::cors::CorsLayer::permissive(),
        )
        .with_state(state);

    let addr = "0.0.0.0:3000";
    tracing::info!("监听地址: http://{addr}");
    tracing::info!("健康检查: http://{addr}/health");
    tracing::info!("提交解析: POST http://{addr}/api/v1/parse");
    tracing::info!("查询任务: GET  http://{addr}/api/v1/parse/{{task_id}}");
    tracing::info!("获取结果: GET  http://{addr}/api/v1/parse/{{task_id}}/result");

    let listener = tokio::net::TcpListener::bind(addr)
        .await
        .expect("无法绑定端口 3000");

    axum::serve(listener, app).await.expect("服务器异常退出");
}
