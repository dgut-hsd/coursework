//! Parse Worker Simulator library — Day 5 Capstone.
//!
//! Re-exports all public modules so both the binary and integration tests
//! can access them.

pub mod cache;
pub mod error;
pub mod models;
pub mod parser;
pub mod routes;

use cache::DedupCache;
use models::ParseTask;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;

/// Shared application state available to all route handlers.
#[derive(Clone)]
pub struct AppState {
    pub cache: DedupCache,
    pub tasks: Arc<RwLock<HashMap<String, ParseTask>>>,
}

impl AppState {
    pub fn new() -> Self {
        Self {
            cache: DedupCache::new(),
            tasks: Arc::new(RwLock::new(HashMap::new())),
        }
    }
}
