# 设计决策文档 — Parse Worker Simulator

> Day 5 Capstone: 解析 Pipeline 独立机制实验

---

## 1. 为什么使用异步后台任务而非同步 HTTP 响应

**决策**：`POST /api/v1/parse` 立即返回 `202 Accepted` + `task_id`，实际解析在 `tokio::spawn` 后台任务中执行。

**理由**：
- 100 页 PDF 的模拟解析耗时约 3s（单进程）— 若采用同步 HTTP，客户端连接将持续等待，超时风险高
- 异步模式允许客户端通过 `GET /api/v1/parse/:task_id` 轮询结果，符合 RESTful 异步任务模式
- 与课程文档中 Redis Streams + Consumer Group 的设计理念一致（Demo 简化为 `tokio::spawn`）

---

## 2. 文件哈希去重策略

**决策**：使用 SHA-256 对文件内容计算哈希，以 `HashMap<String, ParsedDocument>` 作为去重缓存。

**流程**：
1. 上传文件 → 计算 `SHA-256(file_bytes)`
2. 查询内存缓存 `DedupCache.get(hash)`
3. 命中 → 直接返回已缓存的 `document_id`（`cache_hit: true`）
4. 未命中 → 后台解析 → 完成后写入缓存

**理由**：
- SHA-256 碰撞概率极低（2^-128），适合文件级别去重
- 基于内容哈希而非文件名，同一文件改名后仍能识别
- 课程文档指出"相同文件重复提交时能够识别并复用结果"——这是小组必做验收项
- 生产环境中可替换为 Redis `SETEX file_hash:{hash} document_id TTL 86400`

**验证**：`dedup_same_file_returns_cached_result` 测试 — 同一内容上传两次，第二次返回 `cache_hit: true`

---

## 3. 分片策略：50 页阈值

**决策**：页数 ≤ 50 使用单进程解析，> 50 拆分为 4 片并行解析。

**理由**（与课程文档一致）：
- **经验值**：单进程 50 页约 1500ms（模拟），100 页约 3000ms
- 4 片并行各处理 ~25 页约 750ms，合并约 50ms，总计约 800ms
- 加速比 ≈ 3.75x，远优于 50 页串行
- 与文档中"分片并行（> 50 页文档）验收标准"直接对应

**实现**：
```rust
let shard_size = page_count.div_ceil(SHARD_COUNT);  // SHARD_COUNT = 4
// 4 个 tokio::task::spawn，每片独立 simulate_page()
// futures_util::future::join_all 等待全部完成
// 按页码排序合并结果
```

---

## 4. 坏页容错与降级路径（PCB 协议）

**决策**：采用 **Partial Continuation with Blacklisting (PCB)** 策略。

**流程**：
1. 每个页面独立解析，带有 `tokio::time::timeout` 守卫（2s/页）
2. 超时页 → 标记 `PageStatus::Timeout`，`error` 字段记录 "降级路径激活"
3. 非法输出页 → 标记 `PageStatus::Failed`，`error` 字段记录原因
4. 所有页处理完毕后聚合：
   - 全部成功 → `ParseStatus::Completed`
   - 部分失败 → `ParseStatus::PartialFailure`（降级输出可用）
   - 全部超时 → `ParseStatus::Timeout`
   - 全部失败 → `ParseStatus::Failed`

**理由**：
- 单页失败不应阻塞整个文档解析 —— 课程验收标准明确要求"坏页容错（partial_errors）"
- 超时守卫防止单个页面挂起无限等待 —— 模拟真实 ML 引擎可能卡死
- 降级路径产出的 `ParsedDocument` 包含成功页和失败页，上游可选择性使用

---

## 5. 进程池复用的简化为 tokio::spawn

**决策**：Demo 使用 `tokio::spawn` 替代真实进程池管理。

**理由**：
- 课程明确"不要求接入真实 Redis、MinIO，也不修改项目代码"
- `tokio::spawn` 的异步任务模型可以模拟进程池的并发行为
- 生产环境中 Docling 模型加载需 3-5s → 使用进程池预加载可省 70% 时间
- 此 Demo 关注状态协议和失败边界，非性能测量

---

## 6. 数据模型设计

**ParsedDocument 结构**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `document_id` | UUID v4 | 唯一文档标识 |
| `file_hash` | SHA-256 hex | 源文件哈希 |
| `status` | enum | COMPLETED / PARTIAL_FAILURE / TIMEOUT / FAILED |
| `total_pages` | u32 | 总页数 |
| `successful_pages` | u32 | 成功解析的页数 |
| `failed_pages` | u32 | 失败 + 超时页数 |
| `pages` | Vec\<PageResult\> | 逐页详情 |
| `strategy` | String | "single" 或 "sharded-N" |
| `engine` | String | 引擎名称 |
| `summary` | String | 人类可读的摘要 |
| `total_elapsed_ms` | u64 | 总耗时 |

**PageResult 结构**：

| 字段 | 类型 | 说明 |
|------|------|------|
| `page_number` | u32 | 页码 |
| `status` | enum | SUCCESS / FAILED / TIMEOUT |
| `content` | Option\<String\> | 解析出的文本（成功时） |
| `error` | Option\<String\> | 错误描述（失败时），包含"降级路径激活"标记 |
| `engine` | Option\<String\> | 使用的引擎名称 |
| `elapsed_ms` | u64 | 该页耗时 |

---

## 7. 与标书审核项目的关系

此 Demo 模拟了解析 Worker 的核心状态机，但不直接作为项目 scaffold。若后续迁移到真实项目需：
1. 将 `DedupCache<HashMap>` 替换为 Redis
2. 将 `tokio::spawn` 替换为进程池 + Python 子进程
3. 接入 MinIO 用于文件存储
4. 实现 Redis Streams Consumer Group
5. 添加 G8 回调 HTTP 客户端

---

## 验收标准对照

| 验收项 | 权重 | 实现 |
|--------|------|------|
| 完整链路：上传→解析→存储→回调 | 25% | `full_pipeline_normal_document` 测试 |
| 文件哈希去重 | 15% | `dedup_same_file_returns_cached_result` 测试 |
| 坏页容错（partial_errors） | 15% | `corrupt_document_returns_partial_failure` 测试 |
| 进程池复用 | 15% | Demo 用 `tokio::spawn` 模拟（见 §5） |
| 分片并行（> 50 页） | 15% | `large_document_uses_sharded_strategy` 测试 |
| 设计决策文档 | 15% | 本文档 |
