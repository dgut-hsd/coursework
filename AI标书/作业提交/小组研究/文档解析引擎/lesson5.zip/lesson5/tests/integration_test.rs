//! End-to-end integration tests for the Parse Worker Simulator.
//!
//! These tests start a real HTTP server and exercise the full pipeline:
//! upload -> parse -> result retrieval.
//!
//! ## Covered acceptance criteria
//!
//! | Criterion                          | Test(s)                                        |
//! |------------------------------------|------------------------------------------------|
//! | 完整链路：上传→解析→结果            | `full_pipeline_normal_document`                |
//! | 文件哈希去重（第二次秒返回）        | `dedup_same_file_returns_cached_result`        |
//! | 坏页容错（partial_errors）          | `corrupt_document_returns_partial_failure`     |
//! | 超时降级                           | `timeout_document_degrades_gracefully`         |
//! | 分片并行（> 50 页文档）            | `large_document_uses_sharded_strategy`         |

use axum::body::Body;
use axum::http::{Request, StatusCode};
use parse_worker_simulator::AppState;
use tower::ServiceExt;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn build_multipart(boundary: &str, file_name: &str, data: &[u8]) -> Vec<u8> {
    let mut body = Vec::new();
    let header = format!(
        "--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; \
         filename=\"{file_name}\"\r\nContent-Type: application/octet-stream\r\n\r\n"
    );
    body.extend_from_slice(header.as_bytes());
    body.extend_from_slice(data);
    body.extend_from_slice(format!("\r\n--{boundary}--\r\n").as_bytes());
    body
}

type JsonValue = serde_json::Value;

/// Wrap state in an Arc so the caller can hold a reference after the router
/// is consumed by `oneshot`.
struct TestClient {
    state: AppState,
}

impl TestClient {
    fn new() -> Self {
        Self { state: AppState::new() }
    }

    fn state(&self) -> AppState {
        self.state.clone()
    }

    /// POST /api/v1/parse
    async fn submit(&self, file_name: &str, data: &[u8], query: &str) -> (StatusCode, JsonValue) {
        let app = make_router(self.state());
        let uri = if query.is_empty() {
            "/api/v1/parse".to_string()
        } else {
            format!("/api/v1/parse?{query}")
        };
        let boundary = format!("b{}", uuid::Uuid::new_v4());
        let body = build_multipart(&boundary, file_name, data);
        let ct = format!("multipart/form-data; boundary={boundary}");

        let req = Request::builder()
            .method("POST")
            .uri(&uri)
            .header("content-type", &ct)
            .body(Body::from(body))
            .unwrap();

        let resp = app.oneshot(req).await.unwrap();
        let status = resp.status();
        let body = axum::body::to_bytes(resp.into_body(), 1024 * 1024).await.unwrap();
        let json: JsonValue = serde_json::from_slice(&body).unwrap_or_default();
        (status, json)
    }

    /// GET /api/v1/parse/{task_id}
    async fn get_status(&self, task_id: &str) -> (StatusCode, JsonValue) {
        let app = make_router(self.state());
        let req = Request::builder()
            .method("GET")
            .uri(format!("/api/v1/parse/{task_id}"))
            .body(Body::empty())
            .unwrap();

        let resp = app.oneshot(req).await.unwrap();
        let status = resp.status();
        let body = axum::body::to_bytes(resp.into_body(), 1024 * 1024).await.unwrap();
        let json: JsonValue = serde_json::from_slice(&body).unwrap_or_default();
        (status, json)
    }

    /// GET /health
    async fn health(&self) -> (StatusCode, JsonValue) {
        let app = make_router(self.state());
        let req = Request::builder()
            .method("GET")
            .uri("/health")
            .body(Body::empty())
            .unwrap();
        let resp = app.oneshot(req).await.unwrap();
        let status = resp.status();
        let body = axum::body::to_bytes(resp.into_body(), 1024).await.unwrap();
        let json: JsonValue = serde_json::from_slice(&body).unwrap_or_default();
        (status, json)
    }
}

fn make_router(state: AppState) -> axum::Router {
    use axum::routing::{get, post};
    axum::Router::new()
        .route("/health", get(parse_worker_simulator::routes::health))
        .route("/api/v1/parse", post(parse_worker_simulator::routes::submit_parse))
        .route(
            "/api/v1/parse/:task_id",
            get(parse_worker_simulator::routes::get_task_status),
        )
        .route(
            "/api/v1/parse/:task_id/result",
            get(parse_worker_simulator::routes::get_task_result),
        )
        .with_state(state)
}

/// Poll until the task has a document or max_attempts is reached.
async fn wait_for_completion(client: &TestClient, task_id: &str, max_ms: u64) -> JsonValue {
    let interval = 100;
    let mut waited = 0;
    loop {
        let (_s, j) = client.get_status(task_id).await;
        if j["document"].is_object() || waited >= max_ms {
            return j;
        }
        tokio::time::sleep(tokio::time::Duration::from_millis(interval)).await;
        waited += interval;
    }
}

// ---------------------------------------------------------------------------
// Test 1: Full pipeline — normal document completes successfully
// ---------------------------------------------------------------------------

#[tokio::test]
async fn full_pipeline_normal_document() {
    let client = TestClient::new();

    let file_data = b"%PDF-1.4 test document";
    let (status, json) = client.submit("sample.pdf", file_data, "pages=3").await;

    assert_eq!(status, StatusCode::ACCEPTED);
    let task_id = json["task_id"].as_str().unwrap();
    assert!(!task_id.is_empty());
    assert_eq!(json["cache_hit"], false);

    let result = wait_for_completion(&client, task_id, 2000).await;
    assert_eq!(result["status"], "COMPLETED", "任务应标记为完成");

    let doc = &result["document"];
    assert!(doc.is_object(), "应有 document 字段");
    assert_eq!(doc["status"], "COMPLETED");
    assert_eq!(doc["total_pages"], 3);
    assert_eq!(doc["successful_pages"], 3);
    assert_eq!(doc["failed_pages"], 0);
}

// ---------------------------------------------------------------------------
// Test 2: Dedup
// ---------------------------------------------------------------------------

#[tokio::test]
async fn dedup_same_file_returns_cached_result() {
    let client = TestClient::new();
    let file_data = b"%PDF-1.4 dedup test";

    // First submission
    let (status1, json1) = client.submit("doc.pdf", file_data, "pages=2").await;
    assert_eq!(status1, StatusCode::ACCEPTED);
    assert_eq!(json1["cache_hit"], false);

    // Wait for background parse
    tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;

    // Second submission — same content
    let (status2, json2) = client.submit("doc2.pdf", file_data, "pages=2").await;
    assert_eq!(status2, StatusCode::OK);
    assert_eq!(json2["cache_hit"], true);
    assert!(json2["document_id"].as_str().is_some());
    assert_eq!(json2["status"], "COMPLETED");
}

// ---------------------------------------------------------------------------
// Test 3: Corrupt document → partial failure
// ---------------------------------------------------------------------------

#[tokio::test]
async fn corrupt_document_returns_partial_failure() {
    let client = TestClient::new();
    let file_data = b"%PDF-1.4 corrupt test";

    let (status, json) = client
        .submit("corrupt.pdf", file_data, "pages=9&simulate_corrupt=true")
        .await;

    assert_eq!(status, StatusCode::ACCEPTED);
    let task_id = json["task_id"].as_str().unwrap();

    let result = wait_for_completion(&client, task_id, 2000).await;
    assert!(result["document"].is_object(), "应有 document");

    let doc = &result["document"];
    assert_eq!(doc["status"], "PARTIAL_FAILURE", "文档状态应为 PARTIAL_FAILURE");
    assert!(doc["failed_pages"].as_u64().unwrap() > 0, "应有失败页");
    assert!(doc["successful_pages"].as_u64().unwrap() > 0, "应有成功页");

    let pages = doc["pages"].as_array().unwrap();
    let failed: Vec<_> = pages.iter().filter(|p| p["status"] == "FAILED").collect();
    assert!(!failed.is_empty());
    for p in &failed {
        let err = p["error"].as_str().unwrap();
        assert!(err.contains("降级路径激活"), "失败页应标记降级: {err}");
        assert!(err.contains("非法"), "应说明输出非法: {err}");
    }
}

// ---------------------------------------------------------------------------
// Test 4: Timeout → degraded gracefully
// ---------------------------------------------------------------------------

#[tokio::test]
async fn timeout_document_degrades_gracefully() {
    let client = TestClient::new();
    let file_data = b"%PDF-1.4 timeout test";

    let (status, json) = client
        .submit("timeout.pdf", file_data, "pages=2&simulate_timeout=true")
        .await;

    assert_eq!(status, StatusCode::ACCEPTED);
    let task_id = json["task_id"].as_str().unwrap();

    // Each page times out at 2s, 2 pages = up to 4s total
    let result = wait_for_completion(&client, task_id, 6000).await;
    assert!(result["document"].is_object(), "应有 document");

    let doc = &result["document"];
    assert_eq!(doc["status"], "TIMEOUT", "全页超时应为 TIMEOUT");

    let pages = doc["pages"].as_array().unwrap();
    for p in pages {
        assert_eq!(p["status"], "TIMEOUT");
        assert!(p["error"].as_str().unwrap().contains("降级路径激活"));
    }
}

// ---------------------------------------------------------------------------
// Test 5: Large document → sharded-4
// ---------------------------------------------------------------------------

#[tokio::test]
async fn large_document_uses_sharded_strategy() {
    let client = TestClient::new();
    let file_data = b"%PDF-1.4 large doc";

    let (status, json) = client
        .submit("large.pdf", file_data, "pages=100")
        .await;

    assert_eq!(status, StatusCode::ACCEPTED);
    let task_id = json["task_id"].as_str().unwrap();

    let result = wait_for_completion(&client, task_id, 3000).await;
    assert!(result["document"].is_object(), "应有 document");

    let doc = &result["document"];
    assert_eq!(doc["total_pages"], 100);
    assert_eq!(doc["strategy"], "sharded-4", ">50 页应使用 sharded-4");
    assert_eq!(doc["status"], "COMPLETED");
}

// ---------------------------------------------------------------------------
// Test 6: Health check
// ---------------------------------------------------------------------------

#[tokio::test]
async fn health_check_returns_ok() {
    let client = TestClient::new();
    let (_status, json) = client.health().await;
    assert_eq!(json["status"], "ok");
}

// ---------------------------------------------------------------------------
// Test 7: 404 for nonexistent task
// ---------------------------------------------------------------------------

#[tokio::test]
async fn nonexistent_task_returns_404() {
    let client = TestClient::new();
    let (status, json) = client.get_status("nonexistent-id").await;
    assert_eq!(status, StatusCode::NOT_FOUND);
    assert_eq!(json["error"], true);
}
