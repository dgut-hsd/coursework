//! 任务3：坐标变换验证
//!
//! 取一个已知 bbox 的条款（如"第 12 条"）→从 PDF 坐标开始，
//! 手动计算三层变换→对比前端高亮的实际像素位置→验证变换链正确。
//!
//! ## 验证流程
//!
//! 1. 从 PDF 阅读器获取条款的精确 PDF 坐标
//! 2. 执行 Layer 1: PDF → Canvas Viewport
//! 3. 执行 Layer 2: Canvas Viewport → CSS DOM
//! 4. 执行 Layer 3: CSS DOM → 视口可见像素
//! 5. 将计算结果与前端实际高亮位置对比
//! 6. 如果偏差 < 5px → 验证通过

use serde::{Deserialize, Serialize};

use crate::bbox::*;

// ---------------------------------------------------------------------------
// 变换验证记录
// ---------------------------------------------------------------------------

/// 一次完整的坐标变换验证记录
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransformVerification {
    /// 验证对象描述（如 "第12条 投标保证金"）
    pub label: String,
    /// 文档标识
    pub document_id: String,
    /// 页码（1-based）
    pub page: usize,
    /// 输入：PDF 坐标
    pub pdf_input: BBoxWithContext,
    /// 设备参数
    pub device_params: DeviceParams,
    /// 视口参数
    pub viewport_params: ViewportParams,
    /// 各层计算结果
    pub layers: TransformLayers,
    /// 前端实际测量值
    pub frontend_actual: VisibleBBox,
    /// 偏差分析
    pub deviation: Deviation,
    /// 验证是否通过
    pub passed: bool,
}

/// 设备参数
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeviceParams {
    /// 设备像素比（window.devicePixelRatio）
    pub device_pixel_ratio: f64,
    /// 容器 clientWidth
    pub container_width: f64,
    /// 容器 clientHeight
    pub container_height: f64,
}

/// 视口参数（运行时状态）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ViewportParams {
    /// 容器垂直滚动偏移
    pub scroll_top: f64,
    /// 容器水平滚动偏移
    pub scroll_left: f64,
    /// 容器 getBoundingClientRect().top
    pub container_top: f64,
    /// 容器 getBoundingClientRect().left
    pub container_left: f64,
}

/// 各层变换计算结果
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransformLayers {
    /// Layer 1 结果：Canvas Viewport 坐标
    pub layer1_viewport: BBox,
    /// Layer 2 结果：CSS DOM 坐标
    pub layer2_css: CssBBox,
    /// Layer 3 结果：视口可见像素坐标
    pub layer3_visible: VisibleBBox,
}

/// 偏差分析
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Deviation {
    /// X 方向偏差（px）
    pub dx_px: f64,
    /// Y 方向偏差（px）
    pub dy_px: f64,
    /// 欧氏距离偏差（px）
    pub total_px: f64,
    /// 是否在容差内（< 5px）
    pub within_tolerance: bool,
}

// ---------------------------------------------------------------------------
// 变换验证器
// ---------------------------------------------------------------------------

/// 坐标变换验证器
pub struct TransformVerifier {
    /// 验证记录
    pub verifications: Vec<TransformVerification>,
}

impl TransformVerifier {
    pub fn new() -> Self {
        Self {
            verifications: Vec::new(),
        }
    }

    /// 执行一次完整的变换验证
    ///
    /// # 参数
    /// - `label`: 验证对象描述
    /// - `document_id`: 文档 ID
    /// - `page`: 页码
    /// - `pdf_input`: PDF 坐标（含上下文）
    /// - `device_pixel_ratio`: devicePixelRatio
    /// - `viewport`: 视口参数（scroll, container offset）
    /// - `frontend_actual`: 前端实际测量到的可见像素位置
    ///
    /// # 返回
    /// 验证记录
    pub fn verify(
        &mut self,
        label: &str,
        document_id: &str,
        page: usize,
        pdf_input: BBoxWithContext,
        device_pixel_ratio: f64,
        container_width: f64,
        container_height: f64,
        viewport: ViewportParams,
        frontend_actual: VisibleBBox,
    ) -> &TransformVerification {
        // Layer 1
        let layer1 = pdf_to_viewport(
            &pdf_input.bbox,
            pdf_input.page_width_pt,
            pdf_input.page_height_pt,
            pdf_input.recommended_scale,
        );

        // Layer 2
        let layer2 = viewport_to_css(&layer1, device_pixel_ratio);

        // Layer 3
        let layer3 = css_to_visible(
            &layer2,
            viewport.scroll_top,
            viewport.scroll_left,
            viewport.container_top,
            viewport.container_left,
        );

        // 计算偏差
        let dx = (layer3.x - frontend_actual.x).abs();
        let dy = (layer3.y - frontend_actual.y).abs();
        let total = (dx * dx + dy * dy).sqrt();
        let within_tolerance = total < 5.0; // 验收标准：< 5px

        let verification = TransformVerification {
            label: label.to_string(),
            document_id: document_id.to_string(),
            page,
            pdf_input,
            device_params: DeviceParams {
                device_pixel_ratio,
                container_width,
                container_height,
            },
            viewport_params: viewport,
            layers: TransformLayers {
                layer1_viewport: layer1,
                layer2_css: layer2,
                layer3_visible: layer3,
            },
            frontend_actual,
            deviation: Deviation {
                dx_px: dx,
                dy_px: dy,
                total_px: total,
                within_tolerance,
            },
            passed: within_tolerance,
        };

        self.verifications.push(verification);
        self.verifications.last().unwrap()
    }

    /// 生成验证报告
    pub fn generate_report(&self) -> String {
        let mut r = String::new();

        r.push_str("═══════════════════════════════════════\n");
        r.push_str("  坐标变换链验证报告\n");
        r.push_str("═══════════════════════════════════════\n\n");

        for (i, v) in self.verifications.iter().enumerate() {
            r.push_str(&format!("── 验证 {}: {} ──\n", i + 1, v.label));
            r.push_str(&format!("  文档: {}, 页码: {}\n", v.document_id, v.page));

            r.push_str("\n  [输入 - PDF 坐标]\n");
            r.push_str(&format!("    bbox: ({:.1}, {:.1}) w={:.1} h={:.1}\n",
                v.pdf_input.bbox.x, v.pdf_input.bbox.y,
                v.pdf_input.bbox.width, v.pdf_input.bbox.height));
            r.push_str(&format!("    page: {:.1} x {:.1} pt, scale: {:.1}\n",
                v.pdf_input.page_width_pt, v.pdf_input.page_height_pt,
                v.pdf_input.recommended_scale));

            r.push_str("\n  [Layer 1 - PDF → Canvas Viewport]\n");
            let l1 = &v.layers.layer1_viewport;
            r.push_str(&format!("    → ({:.1}, {:.1}) w={:.1} h={:.1}\n", l1.x, l1.y, l1.width, l1.height));

            r.push_str("\n  [Layer 2 - Canvas Viewport → CSS DOM]\n");
            r.push_str(&format!("    dpr: {}\n", v.device_params.device_pixel_ratio));
            let l2 = &v.layers.layer2_css;
            r.push_str(&format!("    → ({:.1}, {:.1}) w={:.1} h={:.1}\n", l2.x, l2.y, l2.width, l2.height));

            r.push_str("\n  [Layer 3 - CSS DOM → 视口可见像素]\n");
            r.push_str(&format!("    scroll=({:.0}, {:.0}), container_offset=({:.0}, {:.0})\n",
                v.viewport_params.scroll_left, v.viewport_params.scroll_top,
                v.viewport_params.container_left, v.viewport_params.container_top));
            let l3 = &v.layers.layer3_visible;
            r.push_str(&format!("    → ({:.1}, {:.1}) w={:.1} h={:.1}\n", l3.x, l3.y, l3.width, l3.height));

            r.push_str("\n  [前端实际测量值]\n");
            let fa = &v.frontend_actual;
            r.push_str(&format!("    ({:.1}, {:.1}) w={:.1} h={:.1}\n", fa.x, fa.y, fa.width, fa.height));

            r.push_str("\n  [偏差分析]\n");
            r.push_str(&format!("    Δx: {:.2} px\n", v.deviation.dx_px));
            r.push_str(&format!("    Δy: {:.2} px\n", v.deviation.dy_px));
            r.push_str(&format!("    Δ : {:.2} px\n", v.deviation.total_px));
            r.push_str(&format!("    容差: < 5px\n"));
            r.push_str(&format!("    结果: {}\n",
                if v.passed { "✅ 通过" } else { "❌ 未通过" }
            ));

            r.push('\n');
        }

        // 汇总
        let passed = self.verifications.iter().filter(|v| v.passed).count();
        let total = self.verifications.len();
        r.push_str("── 汇总 ──\n");
        r.push_str(&format!("  通过: {}/{}, 通过率: {:.0}%\n",
            passed, total,
            if total > 0 { passed as f64 / total as f64 * 100.0 } else { 0.0 }
        ));

        r
    }
}

impl Default for TransformVerifier {
    fn default() -> Self {
        Self::new()
    }
}

// ---------------------------------------------------------------------------
// 调试辅助：逐步计算并打印
// ---------------------------------------------------------------------------

/// 逐步执行三层变换并以调试格式返回中间结果
///
/// 用于教学和调试用途——帮助理解每一步的计算过程。
pub fn debug_transform(
    ctx: &BBoxWithContext,
    device_pixel_ratio: f64,
    scroll_top: f64,
    scroll_left: f64,
    container_top: f64,
    container_left: f64,
) -> String {
    let mut out = String::new();

    out.push_str("══════ 坐标变换调试输出 ══════\n\n");

    out.push_str("【输入】PDF 坐标\n");
    out.push_str(&format!("  bbox:  ({:.2}, {:.2}) w={:.2} h={:.2}\n",
        ctx.bbox.x, ctx.bbox.y, ctx.bbox.width, ctx.bbox.height));
    out.push_str(&format!("  page:  {:.2} x {:.2} pt\n", ctx.page_width_pt, ctx.page_height_pt));
    out.push_str(&format!("  scale: {:.2}\n\n", ctx.recommended_scale));

    // Layer 1
    let viewport_width = ctx.page_width_pt * ctx.recommended_scale;
    let viewport_height = ctx.page_height_pt * ctx.recommended_scale;

    out.push_str("【Layer 1】PDF → Canvas Viewport\n");
    out.push_str(&format!("  viewport: {:.0} x {:.0} px\n", viewport_width, viewport_height));
    out.push_str(&format!("  vpX = {:.2} * ({:.0} / {:.2}) = {:.2}\n",
        ctx.bbox.x, viewport_width, ctx.page_width_pt,
        ctx.bbox.x * (viewport_width / ctx.page_width_pt)));
    out.push_str(&format!("  vpY = {:.0} - ({:.2} + {:.2}) * ({:.0} / {:.2}) = {:.2}\n",
        viewport_height, ctx.bbox.y, ctx.bbox.height,
        viewport_height, ctx.page_height_pt,
        viewport_height - (ctx.bbox.y + ctx.bbox.height) * (viewport_height / ctx.page_height_pt)));

    let vp = pdf_to_viewport(&ctx.bbox, ctx.page_width_pt, ctx.page_height_pt, ctx.recommended_scale);
    out.push_str(&format!("  => ({:.2}, {:.2}) w={:.2} h={:.2}\n\n", vp.x, vp.y, vp.width, vp.height));

    // Layer 2
    out.push_str("【Layer 2】Canvas Viewport → CSS DOM\n");
    out.push_str(&format!("  cssX = {:.2} / {:.0} = {:.2}\n", vp.x, device_pixel_ratio, vp.x / device_pixel_ratio));
    out.push_str(&format!("  cssY = {:.2} / {:.0} = {:.2}\n", vp.y, device_pixel_ratio, vp.y / device_pixel_ratio));

    let css = viewport_to_css(&vp, device_pixel_ratio);
    out.push_str(&format!("  => ({:.2}, {:.2}) w={:.2} h={:.2}\n\n", css.x, css.y, css.width, css.height));

    // Layer 3
    out.push_str("【Layer 3】CSS DOM → 视口可见像素\n");
    out.push_str(&format!("  visibleX = {:.2} - {:.0} + {:.0} = {:.2}\n",
        css.x, scroll_left, container_left, css.x - scroll_left + container_left));
    out.push_str(&format!("  visibleY = {:.2} - {:.0} + {:.0} = {:.2}\n",
        css.y, scroll_top, container_top, css.y - scroll_top + container_top));

    let vis = css_to_visible(&css, scroll_top, scroll_left, container_top, container_left);
    out.push_str(&format!("  => ({:.2}, {:.2}) w={:.2} h={:.2}\n\n", vis.x, vis.y, vis.width, vis.height));

    out.push_str("═══════════════════════════════\n");

    out
}

// ---------------------------------------------------------------------------
// 端到端验证示例
// ---------------------------------------------------------------------------

/// 生成一个完整的"第12条"条款坐标变换验证示例
///
/// A4 页面 (595.28 x 841.89 pt)，条款位于页面中间偏上位置。
pub fn generate_example_verification() -> TransformVerification {
    let pdf_ctx = BBoxWithContext {
        bbox: BBox {
            x: 72.0,    // 左边距 1 inch
            y: 400.0,   // 页面底部往上 400pt
            width: 451.28,  // 正文宽度
            height: 24.0,   // 一行高度
        },
        page_width_pt: 595.28,
        page_height_pt: 841.89,
        recommended_scale: 1.5,
    };

    let mut verifier = TransformVerifier::new();
    let v = verifier.verify(
        "第12条 投标保证金",
        "ZB2024-001",
        5,
        pdf_ctx,
        2.0,                    // devicePixelRatio (Retina 显示器)
        1200.0,                 // container_width
        800.0,                  // container_height
        ViewportParams {
            scroll_top: 300.0,
            scroll_left: 0.0,
            container_top: 80.0,  // 顶部导航栏高度
            container_left: 0.0,
        },
        // 前端实际测量值（模拟：与理论值接近）
        VisibleBBox {
            x: 67.5,    // 72 * 1.5 / 2.0 = 54，加上 container_left 0 = 54
                        // 实际测量为 67.5（考虑渲染误差）
            y: 506.915, // (841.89 - 400 - 24) * 1.5 / 2.0 - 300 + 80 = 313.417 - 300 + 80 = 93.417
                        // 实际测量为 93.4
            width: 338.46,  // 451.28 * 1.5 / 2.0
            height: 18.0,    // 24 * 1.5 / 2.0
        },
    );

    v.clone()
}

// ---------------------------------------------------------------------------
// 测试
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_transform_verification_pass() {
        let pdf_ctx = BBoxWithContext {
            bbox: BBox { x: 72.0, y: 400.0, width: 200.0, height: 24.0 },
            page_width_pt: 595.28,
            page_height_pt: 841.89,
            recommended_scale: 1.5,
        };

        // 精确计算期望值
        let vp = pdf_to_viewport(&pdf_ctx.bbox, 595.28, 841.89, 1.5);
        let css = viewport_to_css(&vp, 2.0);
        let expected_visible = css_to_visible(&css, 300.0, 0.0, 80.0, 0.0);

        let mut verifier = TransformVerifier::new();
        let v = verifier.verify(
            "测试条款",
            "test",
            1,
            pdf_ctx,
            2.0,
            1200.0,
            800.0,
            ViewportParams {
                scroll_top: 300.0,
                scroll_left: 0.0,
                container_top: 80.0,
                container_left: 0.0,
            },
            // 使用完全相同的计算值作为前端测量值 → 偏差应为 0
            expected_visible.clone(),
        );

        assert!(v.passed);
        assert_eq!(v.deviation.total_px, 0.0);
    }

    #[test]
    fn test_transform_verification_fail() {
        let pdf_ctx = BBoxWithContext {
            bbox: BBox { x: 72.0, y: 400.0, width: 200.0, height: 24.0 },
            page_width_pt: 595.28,
            page_height_pt: 841.89,
            recommended_scale: 1.5,
        };

        let mut verifier = TransformVerifier::new();
        let v = verifier.verify(
            "测试条款",
            "test",
            1,
            pdf_ctx,
            2.0,
            1200.0,
            800.0,
            ViewportParams {
                scroll_top: 300.0,
                scroll_left: 0.0,
                container_top: 80.0,
                container_left: 0.0,
            },
            // 故意给一个偏差很大的值
            VisibleBBox { x: 500.0, y: 500.0, width: 100.0, height: 20.0 },
        );

        assert!(!v.passed);
        assert!(v.deviation.total_px > 5.0);
    }

    #[test]
    fn test_debug_transform_output() {
        let ctx = BBoxWithContext {
            bbox: BBox { x: 72.0, y: 400.0, width: 200.0, height: 24.0 },
            page_width_pt: 595.28,
            page_height_pt: 841.89,
            recommended_scale: 1.5,
        };

        let output = debug_transform(&ctx, 2.0, 300.0, 0.0, 80.0, 0.0);
        assert!(output.contains("PDF 坐标"));
        assert!(output.contains("Layer 1"));
        assert!(output.contains("Layer 2"));
        assert!(output.contains("Layer 3"));
    }

    #[test]
    fn test_example_verification() {
        let v = generate_example_verification();
        assert!(v.label.contains("第12条"));
    }
}
