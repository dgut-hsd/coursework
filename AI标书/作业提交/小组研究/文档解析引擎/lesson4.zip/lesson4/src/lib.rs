//! # lesson4-quality-bbox
//!
//! Day 4: 质量评估 + bbox 坐标链路
//!
//! ## 模块功能
//!
//! - `block_id`  : 确定性 Block ID 生成（同一份 PDF 总是产生相同的 ID）
//! - `bbox`      : bbox 三层坐标变换（PDF → Canvas → DOM → 视口）
//! - `types`     : 核心数据类型（ParsedDocument, Table, BBox 等）
//! - `golden`    : 任务1 - Golden Standard 标注数据格式
//! - `benchmark` : 任务2 - 自动化 Benchmark 引擎
//! - `transform` : 任务3 - 坐标变换验证

pub mod block_id;
pub mod bbox;
pub mod types;
pub mod golden;
pub mod benchmark;
pub mod transform;
