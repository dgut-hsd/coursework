//! 任务1：Golden Standard 标注
//!
//! 手动标注 20 页招标文件 PDF——在每页上标记：
//! - 每个表格的行数、列数、表头文字
//! - 每个章节的起始页码和标题
//! - 10 个随机 bbox 点的精确坐标（用 PDF 阅读器的坐标尺）
//!
//! 本模块提供 Golden Standard 的数据格式定义、序列化/反序列化、
//! 以及一个辅助构建器，方便在代码中创建标注数据。

use serde::{Deserialize, Serialize};

use crate::bbox::BBox;

// ---------------------------------------------------------------------------
// Golden Standard 顶层结构
// ---------------------------------------------------------------------------

/// 一份完整的 Golden Standard 标注文件
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoldenStandard {
    /// 标注元信息
    pub meta: GoldenMeta,
    /// 按文档组织的标注数据
    pub documents: Vec<GoldenDocument>,
}

/// 标注元信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoldenMeta {
    /// 标注版本
    pub version: String,
    /// 标注日期
    pub annotated_at: String,
    /// 标注人
    pub annotator: String,
    /// 备注
    pub notes: Option<String>,
}

/// 单个文档的 Golden Standard
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoldenDocument {
    /// 文档唯一标识
    pub document_id: String,
    /// 源 PDF 文件名
    pub source_file: String,
    /// 总页数
    pub page_count: usize,
    /// 标注的页码范围
    pub annotated_pages: Vec<usize>,
    /// 表格标注
    pub tables: Vec<GoldenTable>,
    /// 章节标注
    pub sections: Vec<GoldenSection>,
    /// bbox 点标注（用于坐标偏移 RMSE 计算）
    pub bbox_points: Vec<GoldenBBoxPoint>,
}

// ---------------------------------------------------------------------------
// 表格标注
// ---------------------------------------------------------------------------

/// 人工标注的表格 Ground Truth
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoldenTable {
    /// 所在页码（1-based）
    pub page: usize,
    /// 表格在该页的序号（从 0 开始）
    pub table_index: usize,
    /// 行数
    pub row_count: usize,
    /// 列数
    pub col_count: usize,
    /// 表头文字
    pub header: Vec<String>,
    /// 表格标题（如有）
    pub caption: Option<String>,
    /// 表格的 bbox（用于定位验证）
    pub bbox: Option<BBox>,
    /// 标注备注
    pub notes: Option<String>,
}

// ---------------------------------------------------------------------------
// 章节标注
// ---------------------------------------------------------------------------

/// 人工标注的章节 Ground Truth
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoldenSection {
    /// 章节编号（如 "3.2"）
    pub number: String,
    /// 章节标题（完整文字）
    pub title: String,
    /// 起始页码（1-based）
    pub start_page: usize,
    /// 结束页码（如有）
    pub end_page: Option<usize>,
    /// 层级深度
    pub level: u8,
    /// 父章节编号（如 "3"，根章节为 None）
    pub parent: Option<String>,
}

// ---------------------------------------------------------------------------
// bbox 点标注
// ---------------------------------------------------------------------------

/// 人工标注的 bbox 精确坐标点
///
/// 用途：作为 RMSE 计算的 Ground Truth。
/// 建议每页标注 10 个随机点，覆盖页面的四个角和中心区域。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoldenBBoxPoint {
    /// 所在页码（1-based）
    pub page: usize,
    /// 点的标签（如 "左上角", "第22条标题", "表格1左上角"）
    pub label: String,
    /// 关联的 Block/Clause/Table ID（如有）
    pub reference_id: Option<String>,
    /// 精确的 PDF 坐标
    pub bbox: BBox,
}

// ---------------------------------------------------------------------------
// GoldenStandard 构建器
// ---------------------------------------------------------------------------

/// GoldenStandard 构建器，方便逐文档添加标注数据
#[derive(Debug, Default)]
pub struct GoldenStandardBuilder {
    meta: Option<GoldenMeta>,
    documents: Vec<GoldenDocument>,
}

impl GoldenStandardBuilder {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn meta(mut self, meta: GoldenMeta) -> Self {
        self.meta = Some(meta);
        self
    }

    pub fn add_document(mut self, doc: GoldenDocument) -> Self {
        self.documents.push(doc);
        self
    }

    pub fn build(self) -> GoldenStandard {
        GoldenStandard {
            meta: self.meta.unwrap_or_else(|| GoldenMeta {
                version: "1.0.0".into(),
                annotated_at: chrono_like_now(),
                annotator: "unknown".into(),
                notes: None,
            }),
            documents: self.documents,
        }
    }
}

/// 生成当前时间字符串（避免依赖 chrono crate）
fn chrono_like_now() -> String {
    "2026-07-24T00:00:00Z".into()
}

// ---------------------------------------------------------------------------
// 校验
// ---------------------------------------------------------------------------

impl GoldenStandard {
    /// 验证 Golden Standard 数据完整性
    pub fn validate(&self) -> Result<(), Vec<String>> {
        let mut errors = Vec::new();

        if self.documents.is_empty() {
            errors.push("没有标注任何文档".into());
        }

        for (i, doc) in self.documents.iter().enumerate() {
            // 检查表格标注
            for (j, table) in doc.tables.iter().enumerate() {
                if table.row_count == 0 {
                    errors.push(format!(
                        "doc[{}].tables[{}]: row_count 不能为 0", i, j
                    ));
                }
                if table.col_count == 0 {
                    errors.push(format!(
                        "doc[{}].tables[{}]: col_count 不能为 0", i, j
                    ));
                }
                if table.header.is_empty() {
                    errors.push(format!(
                        "doc[{}].tables[{}]: header 为空，建议填写表头", i, j
                    ));
                }
            }

            // 检查章节标注
            for (j, section) in doc.sections.iter().enumerate() {
                if section.title.is_empty() {
                    errors.push(format!(
                        "doc[{}].sections[{}]: title 不能为空", i, j
                    ));
                }
                if section.start_page == 0 {
                    errors.push(format!(
                        "doc[{}].sections[{}]: start_page 不能为 0（应为 1-based）", i, j
                    ));
                }
            }

            // 检查 bbox 点标注
            for (j, point) in doc.bbox_points.iter().enumerate() {
                if point.bbox.width < 0.0 || point.bbox.height < 0.0 {
                    errors.push(format!(
                        "doc[{}].bbox_points[{}]: bbox 尺寸不能为负", i, j
                    ));
                }
            }
        }

        if errors.is_empty() {
            Ok(())
        } else {
            Err(errors)
        }
    }
}

// ---------------------------------------------------------------------------
// 测试
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_golden_standard_builder() {
        let gs = GoldenStandardBuilder::new()
            .meta(GoldenMeta {
                version: "1.0.0".into(),
                annotated_at: "2026-07-24".into(),
                annotator: "G1-team".into(),
                notes: Some("20页招标文件标注".into()),
            })
            .add_document(GoldenDocument {
                document_id: "ZB2024-001".into(),
                source_file: "zb_001.pdf".into(),
                page_count: 20,
                annotated_pages: (1..=20).collect(),
                tables: vec![GoldenTable {
                    page: 3,
                    table_index: 0,
                    row_count: 5,
                    col_count: 4,
                    header: vec!["序号".into(), "名称".into(), "数量".into(), "备注".into()],
                    caption: Some("表1-1 采购清单".into()),
                    bbox: None,
                    notes: None,
                }],
                sections: vec![GoldenSection {
                    number: "1".into(),
                    title: "招标公告".into(),
                    start_page: 1,
                    end_page: Some(2),
                    level: 1,
                    parent: None,
                }],
                bbox_points: vec![GoldenBBoxPoint {
                    page: 1,
                    label: "左上角".into(),
                    reference_id: None,
                    bbox: BBox { x: 72.0, y: 769.89, width: 100.0, height: 20.0 },
                }],
            })
            .build();

        assert!(gs.validate().is_ok());
        assert_eq!(gs.documents.len(), 1);
        assert_eq!(gs.documents[0].tables.len(), 1);
    }

    #[test]
    fn test_validate_invalid_table() {
        let gs = GoldenStandardBuilder::new()
            .add_document(GoldenDocument {
                document_id: "test".into(),
                source_file: "test.pdf".into(),
                page_count: 1,
                annotated_pages: vec![1],
                tables: vec![GoldenTable {
                    page: 1,
                    table_index: 0,
                    row_count: 0,   // 无效！
                    col_count: 0,
                    header: vec![],
                    caption: None,
                    bbox: None,
                    notes: None,
                }],
                sections: vec![],
                bbox_points: vec![],
            })
            .build();

        let result = gs.validate();
        assert!(result.is_err());
    }
}
