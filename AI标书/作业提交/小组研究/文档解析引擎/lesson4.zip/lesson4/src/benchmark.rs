//! 任务2：自动化 Benchmark
//!
//! 用 Day 3 的解析 Pipeline 跑这 20 页→输出 `ParsedDocument`→
//! 和 Golden Standard 对比→生成质量报告：
//! 表格识别率(行/列/表头)、章节分割准确率、bbox RMSE。

use crate::bbox::{bbox_offset, BBox};
use crate::golden::GoldenStandard;
use crate::types::*;

// ---------------------------------------------------------------------------
// Benchmark 引擎
// ---------------------------------------------------------------------------

/// Benchmark 引擎：比较 ParsedDocument 与 Golden Standard
pub struct BenchmarkEngine {
    golden: GoldenStandard,
    /// 表格行数容差（允许 ±n 行的误差算正确）
    row_tolerance: usize,
    /// 标题编辑距离容差
    title_edit_distance: usize,
}

impl BenchmarkEngine {
    /// 创建新的 Benchmark 引擎
    pub fn new(golden: GoldenStandard) -> Self {
        Self {
            golden,
            row_tolerance: 0,   // 默认严格匹配
            title_edit_distance: 3,
        }
    }

    /// 设置行数容差
    pub fn with_row_tolerance(mut self, tolerance: usize) -> Self {
        self.row_tolerance = tolerance;
        self
    }

    /// 设置标题编辑距离
    pub fn with_title_edit_distance(mut self, distance: usize) -> Self {
        self.title_edit_distance = distance;
        self
    }

    // -----------------------------------------------------------------------
    // 执行 Benchmark
    // -----------------------------------------------------------------------

    /// 执行完整的 Benchmark
    ///
    /// # 参数
    /// - `parsed_docs`: Day 3 解析 Pipeline 输出的 ParsedDocument 列表
    ///
    /// # 返回
    /// 质量报告
    pub fn run(&self, parsed_docs: &[ParsedDocument]) -> QualityReport {
        let mut mismatches = Vec::new();
        let total_pages: usize = parsed_docs.iter().map(|d| d.page_count).sum();

        // --- 1. 表格识别率 ---
        let table_acc = self.evaluate_tables(parsed_docs, &mut mismatches);

        // --- 2. 章节分割准确率 ---
        let section_acc = self.evaluate_sections(parsed_docs, &mut mismatches);

        // --- 3. bbox RMSE ---
        let bbox_rmse = self.evaluate_bbox(parsed_docs, &mut mismatches);

        // --- 4. 综合评分 ---
        let overall = (table_acc.row_accuracy
            + table_acc.col_accuracy
            + table_acc.header_accuracy
            + section_acc.start_page_accuracy
            + section_acc.title_fuzzy_match
            + if bbox_rmse.needs_attention { 0.5 } else { 1.0 })
            / 6.0;

        QualityReport {
            generated_at: "2026-07-24T00:00:00Z".into(),
            document_count: parsed_docs.len(),
            page_count: total_pages,
            table_accuracy: table_acc,
            section_accuracy: section_acc,
            bbox_rmse,
            overall_score: (overall * 100.0).round() / 100.0,
            mismatches,
        }
    }

    // -----------------------------------------------------------------------
    // 表格评估
    // -----------------------------------------------------------------------

    fn evaluate_tables(
        &self,
        parsed_docs: &[ParsedDocument],
        mismatches: &mut Vec<Mismatch>,
    ) -> TableAccuracy {
        let mut total_gt_tables = 0usize;
        let mut total_parsed_tables = 0usize;
        let mut row_correct = 0usize;
        let mut col_correct = 0usize;
        let mut header_correct = 0usize;
        let mut matched_tables = 0usize;

        for golden_doc in &self.golden.documents {
            // 找到对应的解析文档
            let parsed = match parsed_docs.iter().find(|p| p.document_id == golden_doc.document_id) {
                Some(p) => p,
                None => continue,
            };

            total_gt_tables += golden_doc.tables.len();
            total_parsed_tables += parsed.pages.iter().map(|p| p.tables.len()).sum::<usize>();

            for golden_table in &golden_doc.tables {
                // 在对应页找到解析出的表格
                let parsed_page = match parsed.pages.iter().find(|p| p.page_number == golden_table.page) {
                    Some(p) => p,
                    None => continue,
                };

                let parsed_table = parsed_page.tables.get(golden_table.table_index);

                match parsed_table {
                    Some(pt) => {
                        matched_tables += 1;

                        // 行数比较
                        let row_diff = if pt.row_count() > golden_table.row_count {
                            pt.row_count() - golden_table.row_count
                        } else {
                            golden_table.row_count - pt.row_count()
                        };
                        if row_diff <= self.row_tolerance {
                            row_correct += 1;
                        } else {
                            mismatches.push(Mismatch {
                                mismatch_type: MismatchType::TableRowCount,
                                page: golden_table.page,
                                expected: golden_table.row_count.to_string(),
                                actual: pt.row_count().to_string(),
                                severity: Severity::Warning,
                            });
                        }

                        // 列数比较
                        if pt.col_count() == golden_table.col_count {
                            col_correct += 1;
                        } else {
                            mismatches.push(Mismatch {
                                mismatch_type: MismatchType::TableColCount,
                                page: golden_table.page,
                                expected: golden_table.col_count.to_string(),
                                actual: pt.col_count().to_string(),
                                severity: Severity::Warning,
                            });
                        }

                        // 表头比较
                        if pt.header == golden_table.header {
                            header_correct += 1;
                        } else {
                            mismatches.push(Mismatch {
                                mismatch_type: MismatchType::TableHeader,
                                page: golden_table.page,
                                expected: golden_table.header.join(", "),
                                actual: pt.header.join(", "),
                                severity: Severity::Warning,
                            });
                        }
                    }
                    None => {
                        mismatches.push(Mismatch {
                            mismatch_type: MismatchType::TableRowCount,
                            page: golden_table.page,
                            expected: format!("{}行x{}列表格", golden_table.row_count, golden_table.col_count),
                            actual: "未找到表格".into(),
                            severity: Severity::Critical,
                        });
                    }
                }
            }
        }

        let n = if total_gt_tables > 0 { total_gt_tables as f64 } else { 1.0 };

        TableAccuracy {
            row_accuracy: (row_correct as f64 / n * 100.0).round() / 100.0,
            col_accuracy: (col_correct as f64 / n * 100.0).round() / 100.0,
            header_accuracy: (header_correct as f64 / n * 100.0).round() / 100.0,
            table_recall: if total_gt_tables > 0 {
                (matched_tables as f64 / total_gt_tables as f64 * 100.0).round() / 100.0
            } else { 1.0 },
            table_precision: if total_parsed_tables > 0 && matched_tables > 0 {
                (matched_tables as f64 / total_parsed_tables as f64 * 100.0).round() / 100.0
            } else { 0.0 },
            total_tables: total_gt_tables,
        }
    }

    // -----------------------------------------------------------------------
    // 章节评估
    // -----------------------------------------------------------------------

    fn evaluate_sections(
        &self,
        parsed_docs: &[ParsedDocument],
        mismatches: &mut Vec<Mismatch>,
    ) -> SectionAccuracy {
        let mut total_gt = 0usize;
        let mut total_parsed = 0usize;
        let mut start_page_correct = 0usize;
        let mut title_exact = 0usize;
        let mut title_fuzzy = 0usize;
        let mut matched_sections = 0usize;

        for golden_doc in &self.golden.documents {
            let parsed = match parsed_docs.iter().find(|p| p.document_id == golden_doc.document_id) {
                Some(p) => p,
                None => continue,
            };

            total_gt += golden_doc.sections.len();
            total_parsed += parsed.sections.len();

            for golden_section in &golden_doc.sections {
                // 按编号匹配
                let parsed_section = parsed.sections.iter().find(|s| s.number == golden_section.number);

                match parsed_section {
                    Some(ps) => {
                        matched_sections += 1;

                        // 起始页比较
                        if ps.start_page == golden_section.start_page {
                            start_page_correct += 1;
                        } else {
                            mismatches.push(Mismatch {
                                mismatch_type: MismatchType::SectionStartPage,
                                page: golden_section.start_page,
                                expected: golden_section.start_page.to_string(),
                                actual: ps.start_page.to_string(),
                                severity: Severity::Warning,
                            });
                        }

                        // 标题比较
                        if ps.title == golden_section.title {
                            title_exact += 1;
                            title_fuzzy += 1;
                        } else if edit_distance(&ps.title, &golden_section.title) <= self.title_edit_distance
                        {
                            title_fuzzy += 1;
                            mismatches.push(Mismatch {
                                mismatch_type: MismatchType::SectionTitle,
                                page: golden_section.start_page,
                                expected: golden_section.title.clone(),
                                actual: ps.title.clone(),
                                severity: Severity::Info,
                            });
                        } else {
                            mismatches.push(Mismatch {
                                mismatch_type: MismatchType::SectionTitle,
                                page: golden_section.start_page,
                                expected: golden_section.title.clone(),
                                actual: ps.title.clone(),
                                severity: Severity::Warning,
                            });
                        }
                    }
                    None => {
                        mismatches.push(Mismatch {
                            mismatch_type: MismatchType::SectionStartPage,
                            page: golden_section.start_page,
                            expected: format!("{} {}", golden_section.number, golden_section.title),
                            actual: "未找到章节".into(),
                            severity: Severity::Critical,
                        });
                    }
                }
            }
        }

        let n = if total_gt > 0 { total_gt as f64 } else { 1.0 };

        SectionAccuracy {
            start_page_accuracy: (start_page_correct as f64 / n * 100.0).round() / 100.0,
            title_exact_match: (title_exact as f64 / n * 100.0).round() / 100.0,
            title_fuzzy_match: (title_fuzzy as f64 / n * 100.0).round() / 100.0,
            section_recall: if total_gt > 0 {
                (matched_sections as f64 / total_gt as f64 * 100.0).round() / 100.0
            } else { 1.0 },
            section_precision: if total_parsed > 0 && matched_sections > 0 {
                (matched_sections as f64 / total_parsed as f64 * 100.0).round() / 100.0
            } else { 0.0 },
            total_sections: total_gt,
        }
    }

    // -----------------------------------------------------------------------
    // bbox 评估
    // -----------------------------------------------------------------------

    fn evaluate_bbox(
        &self,
        parsed_docs: &[ParsedDocument],
        mismatches: &mut Vec<Mismatch>,
    ) -> BBoxRmse {
        let mut offsets = Vec::new();
        let mut max_off = 0.0f64;

        for golden_doc in &self.golden.documents {
            let parsed = match parsed_docs.iter().find(|p| p.document_id == golden_doc.document_id) {
                Some(p) => p,
                None => continue,
            };

            for golden_point in &golden_doc.bbox_points {
                // 通过 reference_id 匹配解析结果中的对应 bbox
                let actual_bbox: Option<BBox> = if let Some(ref ref_id) = golden_point.reference_id {
                    self.find_bbox_in_parsed(parsed, golden_point.page, ref_id)
                } else {
                    // 无 reference_id：按页查找最近的 bbox
                    self.find_nearest_bbox(parsed, golden_point.page, &golden_point.bbox)
                };

                if let Some(actual) = actual_bbox {
                    let offset = bbox_offset(&golden_point.bbox, &actual);
                    offsets.push(offset);
                    if offset > max_off {
                        max_off = offset;
                    }
                    if offset > 10.0 {
                        mismatches.push(Mismatch {
                            mismatch_type: MismatchType::BBoxOffset,
                            page: golden_point.page,
                            expected: format!("({:.1}, {:.1})", golden_point.bbox.x, golden_point.bbox.y),
                            actual: format!("({:.1}, {:.1}) offset={:.1}pt", actual.x, actual.y, offset),
                            severity: if offset > 20.0 { Severity::Warning } else { Severity::Info },
                        });
                    }
                }
            }
        }

        let n = offsets.len() as f64;
        if n == 0.0 {
            return BBoxRmse {
                rmse_x: 0.0,
                rmse_y: 0.0,
                rmse_total: 0.0,
                max_offset: 0.0,
                total_points: 0,
                needs_attention: false,
            };
        }

        let sum_sq = offsets.iter().map(|o| o * o).sum::<f64>();
        let rmse = (sum_sq / n).sqrt();

        // 分别计算 X 和 Y 的 RMSE
        // （简化处理：如果没有按分量记录，则用总 RMSE 的 sqrt(2) 均分）
        let rmse_x = rmse / 2.0_f64.sqrt();
        let rmse_y = rmse / 2.0_f64.sqrt();

        BBoxRmse {
            rmse_x: (rmse_x * 100.0).round() / 100.0,
            rmse_y: (rmse_y * 100.0).round() / 100.0,
            rmse_total: (rmse * 100.0).round() / 100.0,
            max_offset: (max_off * 100.0).round() / 100.0,
            total_points: offsets.len(),
            needs_attention: rmse > 10.0,
        }
    }

    /// 在解析结果中按 ID 查找 bbox
    fn find_bbox_in_parsed(&self, doc: &ParsedDocument, page: usize, ref_id: &str) -> Option<BBox> {
        let page_content = doc.pages.iter().find(|p| p.page_number == page)?;

        // 搜索 blocks
        for block in &page_content.blocks {
            if block.id == ref_id {
                return Some(block.bbox.bbox);
            }
        }
        // 搜索 tables
        for table in &page_content.tables {
            if table.id == ref_id {
                return Some(table.bbox.bbox);
            }
        }
        // 搜索 clauses
        for clause in &page_content.clauses {
            if clause.id == ref_id {
                return Some(clause.bbox.bbox);
            }
        }
        None
    }

    /// 在解析结果中按位置找最近的 bbox
    fn find_nearest_bbox(&self, doc: &ParsedDocument, page: usize, target: &BBox) -> Option<BBox> {
        let page_content = doc.pages.iter().find(|p| p.page_number == page)?;

        let mut best: Option<(BBox, f64)> = None;

        for block in &page_content.blocks {
            let d = bbox_offset(&block.bbox.bbox, target);
            if best.as_ref().map_or(true, |b| d < b.1) {
                best = Some((block.bbox.bbox, d));
            }
        }

        best.map(|(b, _)| b)
    }
}

// ---------------------------------------------------------------------------
// 工具函数
// ---------------------------------------------------------------------------

/// 计算两个字符串的编辑距离（Levenshtein）
fn edit_distance(a: &str, b: &str) -> usize {
    let a_chars: Vec<char> = a.chars().collect();
    let b_chars: Vec<char> = b.chars().collect();
    let m = a_chars.len();
    let n = b_chars.len();

    // 使用两行优化空间
    let mut prev: Vec<usize> = (0..=n).collect();
    let mut curr = vec![0usize; n + 1];

    for i in 1..=m {
        curr[0] = i;
        for j in 1..=n {
            let cost = if a_chars[i - 1] == b_chars[j - 1] { 0 } else { 1 };
            curr[j] = (prev[j] + 1)         // delete
                .min(curr[j - 1] + 1)        // insert
                .min(prev[j - 1] + cost);    // substitute
        }
        std::mem::swap(&mut prev, &mut curr);
    }

    prev[n]
}

// ---------------------------------------------------------------------------
// 报告格式化
// ---------------------------------------------------------------------------

impl QualityReport {
    /// 将质量报告格式化为可读文本
    pub fn to_text_report(&self) -> String {
        let mut r = String::new();

        r.push_str("═══════════════════════════════════════\n");
        r.push_str("  文档解析质量 Benchmark 报告\n");
        r.push_str("═══════════════════════════════════════\n\n");

        r.push_str(&format!("生成时间: {}\n", self.generated_at));
        r.push_str(&format!("测试文档: {} 份, {} 页\n\n", self.document_count, self.page_count));

        // 表格识别率
        r.push_str("── 表格识别率 ──\n");
        r.push_str(&format!("  行数正确率:   {:.1}%\n", self.table_accuracy.row_accuracy * 100.0));
        r.push_str(&format!("  列数正确率:   {:.1}%\n", self.table_accuracy.col_accuracy * 100.0));
        r.push_str(&format!("  表头正确率:   {:.1}%\n", self.table_accuracy.header_accuracy * 100.0));
        r.push_str(&format!("  表格召回率:   {:.1}%\n", self.table_accuracy.table_recall * 100.0));
        r.push_str(&format!("  表格精确率:   {:.1}%\n", self.table_accuracy.table_precision * 100.0));
        r.push_str(&format!("  (共 {} 个表格)\n\n", self.table_accuracy.total_tables));

        // 章节分割
        r.push_str("── 章节分割准确率 ──\n");
        r.push_str(&format!("  起始页正确率: {:.1}%\n", self.section_accuracy.start_page_accuracy * 100.0));
        r.push_str(&format!("  标题完全匹配: {:.1}%\n", self.section_accuracy.title_exact_match * 100.0));
        r.push_str(&format!("  标题模糊匹配: {:.1}%\n", self.section_accuracy.title_fuzzy_match * 100.0));
        r.push_str(&format!("  章节召回率:   {:.1}%\n", self.section_accuracy.section_recall * 100.0));
        r.push_str(&format!("  章节精确率:   {:.1}%\n", self.section_accuracy.section_precision * 100.0));
        r.push_str(&format!("  (共 {} 个章节)\n\n", self.section_accuracy.total_sections));

        // bbox RMSE
        r.push_str("── bbox 偏移 RMSE ──\n");
        r.push_str(&format!("  RMSE X:       {:.2} pt\n", self.bbox_rmse.rmse_x));
        r.push_str(&format!("  RMSE Y:       {:.2} pt\n", self.bbox_rmse.rmse_y));
        r.push_str(&format!("  RMSE 总体:    {:.2} pt\n", self.bbox_rmse.rmse_total));
        r.push_str(&format!("  最大偏移:     {:.2} pt\n", self.bbox_rmse.max_offset));
        r.push_str(&format!("  测试点数:     {}\n", self.bbox_rmse.total_points));
        r.push_str(&format!("  是否需关注:   {} (>10pt 需关注)\n\n",
            if self.bbox_rmse.needs_attention { "⚠ 是" } else { "✓ 否" }
        ));

        // 综合
        r.push_str("── 综合评分 ──\n");
        r.push_str(&format!("  {:.1} / 1.0\n\n", self.overall_score));

        // 不匹配项
        if !self.mismatches.is_empty() {
            r.push_str("── 不匹配详情 ──\n");
            for (i, m) in self.mismatches.iter().enumerate() {
                let sev = match m.severity {
                    Severity::Critical => "🔴",
                    Severity::Warning => "🟡",
                    Severity::Info => "🔵",
                };
                r.push_str(&format!("  {}. {} [{}] p{}: expected={}, actual={}\n",
                    i + 1, sev, mismatch_type_name(&m.mismatch_type), m.page,
                    m.expected, m.actual));
            }
        }

        // 验收结论
        r.push_str("\n── 验收结论 ──\n");
        let table_ok = self.table_accuracy.row_accuracy > 0.8
            && self.table_accuracy.col_accuracy > 0.8;
        let bbox_ok = !self.bbox_rmse.needs_attention;
        if table_ok && bbox_ok {
            r.push_str("  ✅ 通过验收\n");
        } else {
            if !table_ok {
                r.push_str("  ❌ 表格识别率不达标（需 > 80%）\n");
            }
            if !bbox_ok {
                r.push_str("  ❌ bbox RMSE 不达标（需 < 10pt）\n");
            }
        }

        r
    }
}

fn mismatch_type_name(t: &MismatchType) -> &str {
    match t {
        MismatchType::TableRowCount => "表格行数",
        MismatchType::TableColCount => "表格列数",
        MismatchType::TableHeader => "表头",
        MismatchType::SectionStartPage => "章节起始页",
        MismatchType::SectionTitle => "章节标题",
        MismatchType::BBoxOffset => "bbox偏移",
        MismatchType::Other(_) => "其他",
    }
}

// ---------------------------------------------------------------------------
// 测试
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::bbox::BBoxWithContext;
    use crate::golden::*;
    use std::collections::HashMap;

    fn make_sample_parsed() -> Vec<ParsedDocument> {
        vec![ParsedDocument {
            document_id: "ZB2024-001".into(),
            source_file: "zb_001.pdf".into(),
            page_count: 1,
            pages: vec![PageContent {
                page_number: 1,
                width_pt: 595.28,
                height_pt: 841.89,
                blocks: vec![TextBlock {
                    id: "b_abc12345".into(),
                    text: "第一章 总则".into(),
                    bbox: BBoxWithContext {
                        bbox: BBox { x: 72.0, y: 700.0, width: 200.0, height: 24.0 },
                        page_width_pt: 595.28,
                        page_height_pt: 841.89,
                        recommended_scale: 1.5,
                    },
                    block_type: BlockType::Heading { level: 1 },
                }],
                tables: vec![Table {
                    id: "t_def67890".into(),
                    page: 1,
                    rows: vec![
                        vec!["序号".into(), "名称".into(), "数量".into()],
                        vec!["1".into(), "电脑".into(), "10".into()],
                    ],
                    header: vec!["序号".into(), "名称".into(), "数量".into()],
                    bbox: BBoxWithContext {
                        bbox: BBox { x: 100.0, y: 500.0, width: 300.0, height: 60.0 },
                        page_width_pt: 595.28,
                        page_height_pt: 841.89,
                        recommended_scale: 1.5,
                    },
                    caption: Some("表1 采购清单".into()),
                }],
                clauses: vec![],
            }],
            sections: vec![Section {
                id: "s_11111111".into(),
                number: "1".into(),
                title: "总则".into(),
                start_page: 1,
                end_page: None,
                level: 1,
            }],
            metadata: DocumentMetadata {
                parser_version: "docling-0.1.0".into(),
                parsed_at: "2026-07-24T00:00:00Z".into(),
                extra: HashMap::new(),
            },
        }]
    }

    fn make_sample_golden() -> GoldenStandard {
        GoldenStandardBuilder::new()
            .add_document(GoldenDocument {
                document_id: "ZB2024-001".into(),
                source_file: "zb_001.pdf".into(),
                page_count: 1,
                annotated_pages: vec![1],
                tables: vec![GoldenTable {
                    page: 1,
                    table_index: 0,
                    row_count: 2,
                    col_count: 3,
                    header: vec!["序号".into(), "名称".into(), "数量".into()],
                    caption: Some("表1 采购清单".into()),
                    bbox: None,
                    notes: None,
                }],
                sections: vec![GoldenSection {
                    number: "1".into(),
                    title: "总则".into(),
                    start_page: 1,
                    end_page: None,
                    level: 1,
                    parent: None,
                }],
                bbox_points: vec![GoldenBBoxPoint {
                    page: 1,
                    label: "标题".into(),
                    reference_id: Some("b_abc12345".into()),
                    bbox: BBox { x: 72.0, y: 700.0, width: 200.0, height: 24.0 },
                }],
            })
            .build()
    }

    #[test]
    fn test_benchmark_perfect_match() {
        let golden = make_sample_golden();
        let parsed = make_sample_parsed();

        let engine = BenchmarkEngine::new(golden);
        let report = engine.run(&parsed);

        // 表格应完全匹配
        assert_eq!(report.table_accuracy.row_accuracy, 1.0);
        assert_eq!(report.table_accuracy.col_accuracy, 1.0);
        assert_eq!(report.table_accuracy.header_accuracy, 1.0);

        // 章节应完全匹配
        assert_eq!(report.section_accuracy.start_page_accuracy, 1.0);

        // bbox RMSE 应为 0（精确匹配）
        assert_eq!(report.bbox_rmse.rmse_total, 0.0);

        // 无不匹配项
        assert!(report.mismatches.is_empty());
    }

    #[test]
    fn test_edit_distance() {
        assert_eq!(edit_distance("hello", "hello"), 0);
        assert_eq!(edit_distance("hello", "hallo"), 1);
        assert_eq!(edit_distance("abc", ""), 3);
        assert_eq!(edit_distance("kitten", "sitting"), 3);
    }
}
