//! bbox 坐标变换链
//!
//! G1 输出的 bbox 是 PDF 坐标（左下角原点，point 单位）。
//! G9 前端需要的是 CSS pixel（左上角原点，含滚动偏移）。
//!
//! ## 三层变换
//!
//! ```text
//! Layer 1: PDF → Canvas Viewport
//!   page.getViewport({ scale: 1.5 })
//!   vpX = pdfX * (viewport.width / page.width)
//!   vpY = viewport.height - pdfY * (viewport.height / page.height)
//!
//! Layer 2: Canvas Viewport → CSS DOM
//!   canvas.style.width = viewport.width / devicePixelRatio
//!   cssX = vpX / devicePixelRatio
//!   cssY = vpY / devicePixelRatio
//!
//! Layer 3: CSS DOM → 视口内可见像素
//!   scrollTop = container.scrollTop
//!   visibleY = cssY - scrollTop + container.getBoundingClientRect().top
//! ```

use serde::{Deserialize, Serialize};

// ---------------------------------------------------------------------------
// 基础类型
// ---------------------------------------------------------------------------

/// PDF 坐标下的边界框（左下角为原点，单位：point）
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub struct BBox {
    /// 左下角 x 坐标（point）
    pub x: f64,
    /// 左下角 y 坐标（point）
    pub y: f64,
    /// 宽度（point）
    pub width: f64,
    /// 高度（point）
    pub height: f64,
}

/// CSS 像素坐标下的边界框（左上角为原点）
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub struct CssBBox {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

/// 视口可见像素坐标下的边界框
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub struct VisibleBBox {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

// ---------------------------------------------------------------------------
// G1 输出的 bbox 附带信息
// ---------------------------------------------------------------------------

/// G1 输出的 bbox 附带完整上下文，供 G9 前端自行计算后两层变换
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BBoxWithContext {
    /// PDF 坐标下的 bbox
    pub bbox: BBox,
    /// PDF 页面宽度（point）
    pub page_width_pt: f64,
    /// PDF 页面高度（point）
    pub page_height_pt: f64,
    /// 建议的 viewport scale（如 1.5）
    pub recommended_scale: f64,
}

// ---------------------------------------------------------------------------
// Layer 1: PDF → Canvas Viewport
// ---------------------------------------------------------------------------

/// Layer 1: 将 PDF 坐标转换为 Canvas Viewport 像素坐标
///
/// - PDF 坐标系：左下角为原点，单位 point
/// - Canvas Viewport：左上角为原点，单位 pixel
///
/// # 参数
/// - `pdf_bbox`: PDF 坐标下的 bbox
/// - `page_width_pt`: PDF 页面宽度（point）
/// - `page_height_pt`: PDF 页面高度（point）
/// - `scale`: viewport scale factor（如 1.5）
///
/// # 返回
/// Canvas Viewport 像素坐标下的 bbox
pub fn pdf_to_viewport(
    pdf_bbox: &BBox,
    page_width_pt: f64,
    page_height_pt: f64,
    scale: f64,
) -> BBox {
    let viewport_width = page_width_pt * scale;
    let viewport_height = page_height_pt * scale;

    let vp_x = pdf_bbox.x * (viewport_width / page_width_pt);
    // Y 轴翻转：PDF 左下角 → Canvas 左上角
    let vp_y = viewport_height - (pdf_bbox.y + pdf_bbox.height) * (viewport_height / page_height_pt);
    let vp_w = pdf_bbox.width * (viewport_width / page_width_pt);
    let vp_h = pdf_bbox.height * (viewport_height / page_height_pt);

    BBox {
        x: vp_x,
        y: vp_y,
        width: vp_w,
        height: vp_h,
    }
}

// ---------------------------------------------------------------------------
// Layer 2: Canvas Viewport → CSS DOM
// ---------------------------------------------------------------------------

/// Layer 2: 将 Canvas Viewport 像素坐标转换为 CSS DOM 像素坐标
///
/// canvas.style.width = viewport.width / devicePixelRatio
pub fn viewport_to_css(viewport_bbox: &BBox, device_pixel_ratio: f64) -> CssBBox {
    CssBBox {
        x: viewport_bbox.x / device_pixel_ratio,
        y: viewport_bbox.y / device_pixel_ratio,
        width: viewport_bbox.width / device_pixel_ratio,
        height: viewport_bbox.height / device_pixel_ratio,
    }
}

// ---------------------------------------------------------------------------
// Layer 3: CSS DOM → 视口内可见像素
// ---------------------------------------------------------------------------

/// Layer 3: 将 CSS DOM 坐标转换为视口内可见像素坐标
///
/// 包含滚动偏移和容器位置修正。
///
/// # 参数
/// - `css_bbox`: CSS DOM 坐标下的 bbox
/// - `scroll_top`: 容器垂直滚动偏移
/// - `scroll_left`: 容器水平滚动偏移
/// - `container_top`: 容器相对于视口顶部的偏移（getBoundingClientRect().top）
/// - `container_left`: 容器相对于视口左侧的偏移（getBoundingClientRect().left）
pub fn css_to_visible(
    css_bbox: &CssBBox,
    scroll_top: f64,
    scroll_left: f64,
    container_top: f64,
    container_left: f64,
) -> VisibleBBox {
    VisibleBBox {
        x: css_bbox.x - scroll_left + container_left,
        y: css_bbox.y - scroll_top + container_top,
        width: css_bbox.width,
        height: css_bbox.height,
    }
}

// ---------------------------------------------------------------------------
// 便利方法：一次完成三层变换
// ---------------------------------------------------------------------------

/// 一次性完成 PDF → 视口可见像素的三层变换
pub fn pdf_to_visible(
    ctx: &BBoxWithContext,
    device_pixel_ratio: f64,
    scroll_top: f64,
    scroll_left: f64,
    container_top: f64,
    container_left: f64,
) -> VisibleBBox {
    let viewport = pdf_to_viewport(
        &ctx.bbox,
        ctx.page_width_pt,
        ctx.page_height_pt,
        ctx.recommended_scale,
    );
    let css = viewport_to_css(&viewport, device_pixel_ratio);
    css_to_visible(&css, scroll_top, scroll_left, container_top, container_left)
}

/// 检查 bbox 是否在视口内可见
pub fn is_in_viewport(visible: &VisibleBBox, container_width: f64, container_height: f64) -> bool {
    // 允许部分可见：只要有交集就算可见
    let h_overlap = visible.x < container_width && visible.x + visible.width > 0.0;
    let v_overlap = visible.y < container_height && visible.y + visible.height > 0.0;
    h_overlap && v_overlap
}

/// 计算两个 bbox 在 PDF 坐标下的欧氏距离偏移（用于 RMSE 计算）
pub fn bbox_offset(expected: &BBox, actual: &BBox) -> f64 {
    let dx = expected.x - actual.x;
    let dy = expected.y - actual.y;
    (dx * dx + dy * dy).sqrt()
}

// ---------------------------------------------------------------------------
// 测试
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;

    /// 标准 A4 页面：595.28 x 841.89 pt
    const A4_WIDTH: f64 = 595.28;
    const A4_HEIGHT: f64 = 841.89;

    #[test]
    fn test_pdf_to_viewport_y_flip() {
        // PDF 坐标：左下角 y=100 → Canvas 中应该在顶部附近
        let pdf = BBox { x: 50.0, y: 100.0, width: 200.0, height: 30.0 };
        let vp = pdf_to_viewport(&pdf, A4_WIDTH, A4_HEIGHT, 1.5);

        // viewport height = 841.89 * 1.5 = 1262.835
        // vp_y = 1262.835 - (100 + 30) * 1.5 = 1262.835 - 195 = 1067.835
        let expected_vp_y = A4_HEIGHT * 1.5 - (100.0 + 30.0) * 1.5;
        assert!((vp.y - expected_vp_y).abs() < 0.001);
        // PDF 中 y 小的点（靠近页面底部）在 Canvas 中 y 应该大（靠近底部）
        assert!(vp.y > 500.0);
    }

    #[test]
    fn test_roundtrip_same_scale() {
        // 验证：从 PDF 转到 viewport，再按比例转回来
        let pdf = BBox { x: 72.0, y: 72.0, width: 144.0, height: 36.0 };
        let vp = pdf_to_viewport(&pdf, A4_WIDTH, A4_HEIGHT, 1.0);
        let css = viewport_to_css(&vp, 1.0);

        assert!((css.x - pdf.x).abs() < 0.001);
        // css.y = viewport.y (since dpr=1), pdf.y needs flip back
        // vp.y = viewport.h - (pdf.y + pdf.h), css.y = vp.y
        // So css.y = A4_HEIGHT - (pdf.y + pdf.height)
        let expected_css_y = A4_HEIGHT - (pdf.y + pdf.height);
        assert!((css.y - expected_css_y).abs() < 0.001);
    }

    #[test]
    fn test_device_pixel_ratio() {
        let pdf = BBox { x: 100.0, y: 100.0, width: 200.0, height: 50.0 };
        let vp = pdf_to_viewport(&pdf, A4_WIDTH, A4_HEIGHT, 2.0);

        // dpr=2 时 CSS 坐标应为 viewport 的一半
        let css = viewport_to_css(&vp, 2.0);
        assert!((css.x - vp.x / 2.0).abs() < 0.001);
        assert!((css.width - vp.width / 2.0).abs() < 0.001);
    }

    #[test]
    fn test_is_in_viewport() {
        let bbox = VisibleBBox { x: 100.0, y: 200.0, width: 50.0, height: 30.0 };

        // 完全在视口内
        assert!(is_in_viewport(&bbox, 800.0, 600.0));

        // 完全在视口上方
        let above = VisibleBBox { x: 100.0, y: -100.0, width: 50.0, height: 30.0 };
        assert!(!is_in_viewport(&above, 800.0, 600.0));

        // 完全在视口下方
        let below = VisibleBBox { x: 100.0, y: 700.0, width: 50.0, height: 30.0 };
        assert!(!is_in_viewport(&below, 800.0, 600.0));

        // 部分在视口内（跨越上边界）
        let partial = VisibleBBox { x: 100.0, y: -10.0, width: 50.0, height: 30.0 };
        assert!(is_in_viewport(&partial, 800.0, 600.0));
    }

    #[test]
    fn test_bbox_offset() {
        let a = BBox { x: 100.0, y: 200.0, width: 50.0, height: 30.0 };
        let b = BBox { x: 103.0, y: 204.0, width: 50.0, height: 30.0 };
        let offset = bbox_offset(&a, &b);
        // sqrt((100-103)^2 + (200-204)^2) = sqrt(9+16) = 5
        assert!((offset - 5.0).abs() < 0.001);
    }
}
