//! 核心数据类型
//!
//! 定义 `ParsedDocument` 及其子结构——G1 组的交付物。

use serde::{Deserialize, Serialize};

use crate::bbox::BBoxWithContext;

// ---------------------------------------------------------------------------
// ParsedDocument — G1 组的核心输出
// ---------------------------------------------------------------------------

/// 解析后的文档（G1 组交付物①）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParsedDocument {
    /// 文档唯一标识
    pub document_id: String,
    /// 源 PDF 文件名
    pub source_file: String,
    /// 总页数
    pub page_count: usize,
    /// 按页组织的解析内容
    pub pages: Vec<PageContent>,
    /// 全局章节结构
    pub sections: Vec<Section>,
    /// 元数据（解析器版本、时间戳等）
    pub metadata: DocumentMetadata,
}

/// 单页的解析内容
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PageContent {
    /// 页码（1-based）
    pub page_number: usize,
    /// PDF 页面宽度（point）
    pub width_pt: f64,
    /// PDF 页面高度（point）
    pub height_pt: f64,
    /// 该页上的文本 Block
    pub blocks: Vec<TextBlock>,
    /// 该页上的表格
    pub tables: Vec<Table>,
    /// 该页上的条款
    pub clauses: Vec<Clause>,
}

/// 文本段落 Block
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TextBlock {
    /// 确定性 Block ID
    pub id: String,
    /// 段落文本
    pub text: String,
    /// PDF 坐标 bbox（含上下文）
    pub bbox: BBoxWithContext,
    /// 段落类型
    pub block_type: BlockType,
}

/// 段落类型
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum BlockType {
    Paragraph,
    Heading { level: u8 },
    ListItem,
    Header,
    Footer,
    Clause,
    Other(String),
}

/// 表格
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Table {
    /// 确定性 Table ID
    pub id: String,
    /// 页码（1-based）
    pub page: usize,
    /// 表格行数据
    pub rows: Vec<Vec<String>>,
    /// 表头
    pub header: Vec<String>,
    /// PDF 坐标 bbox
    pub bbox: BBoxWithContext,
    /// 表格标题（如 "表1-1 采购清单"）
    pub caption: Option<String>,
}

impl Table {
    /// 获取行数
    pub fn row_count(&self) -> usize {
        self.rows.len()
    }

    /// 获取列数（以第一行为准）
    pub fn col_count(&self) -> usize {
        self.rows.first().map_or(0, |r| r.len())
    }
}

/// 条款
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Clause {
    /// 确定性 Clause ID
    pub id: String,
    /// 条款编号（归一化，如 "22"）
    pub number: String,
    /// 条款标题
    pub title: String,
    /// 条款内容
    pub content: String,
    /// 所在页码（1-based）
    pub page: usize,
    /// PDF 坐标 bbox
    pub bbox: BBoxWithContext,
}

/// 章节
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Section {
    /// 确定性 Section ID
    pub id: String,
    /// 章节编号（如 "3.2"）
    pub number: String,
    /// 章节标题
    pub title: String,
    /// 起始页码（1-based）
    pub start_page: usize,
    /// 结束页码（1-based）
    pub end_page: Option<usize>,
    /// 层级深度
    pub level: u8,
}

/// 文档元数据
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DocumentMetadata {
    /// 解析器名称 + 版本
    pub parser_version: String,
    /// 解析时间（ISO 8601）
    pub parsed_at: String,
    /// 额外信息
    pub extra: std::collections::HashMap<String, String>,
}

// ---------------------------------------------------------------------------
// 质量报告
// ---------------------------------------------------------------------------

/// Benchmark 质量报告（G1 组交付物②）
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QualityReport {
    /// 报告生成时间
    pub generated_at: String,
    /// 测试的文档数
    pub document_count: usize,
    /// 测试的总页数
    pub page_count: usize,
    /// 表格识别率
    pub table_accuracy: TableAccuracy,
    /// 章节分割准确率
    pub section_accuracy: SectionAccuracy,
    /// bbox 偏移 RMSE
    pub bbox_rmse: BBoxRmse,
    /// 综合评分
    pub overall_score: f64,
    /// 详细的不匹配项
    pub mismatches: Vec<Mismatch>,
}

/// 表格识别率
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TableAccuracy {
    /// 行数正确率
    pub row_accuracy: f64,
    /// 列数正确率
    pub col_accuracy: f64,
    /// 表头正确率
    pub header_accuracy: f64,
    /// 表格检测召回率（找到了多少个表格）
    pub table_recall: f64,
    /// 表格检测精确率（找到的表格中有多少是正确的）
    pub table_precision: f64,
    /// 测试的表格总数
    pub total_tables: usize,
}

/// 章节分割准确率
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SectionAccuracy {
    /// 章节起始页正确率
    pub start_page_accuracy: f64,
    /// 章节标题完全匹配率
    pub title_exact_match: f64,
    /// 章节标题模糊匹配率（编辑距离 < 3）
    pub title_fuzzy_match: f64,
    /// 章节检测召回率
    pub section_recall: f64,
    /// 章节检测精确率
    pub section_precision: f64,
    /// 测试的章节总数
    pub total_sections: usize,
}

/// bbox 偏移 RMSE
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BBoxRmse {
    /// RMSE X 方向（point）
    pub rmse_x: f64,
    /// RMSE Y 方向（point）
    pub rmse_y: f64,
    /// RMSE 总体（point）
    pub rmse_total: f64,
    /// 最大偏移（point）
    pub max_offset: f64,
    /// 测试的 bbox 点数量
    pub total_points: usize,
    /// 是否需要关注（RMSE > 10pt 则需关注）
    pub needs_attention: bool,
}

/// 单个不匹配项
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Mismatch {
    /// 不匹配类型
    pub mismatch_type: MismatchType,
    /// 所在页码
    pub page: usize,
    /// 期望值（人工标注）
    pub expected: String,
    /// 实际值（解析结果）
    pub actual: String,
    /// 严重程度
    pub severity: Severity,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum MismatchType {
    TableRowCount,
    TableColCount,
    TableHeader,
    SectionStartPage,
    SectionTitle,
    BBoxOffset,
    Other(String),
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum Severity {
    Critical,
    Warning,
    Info,
}
