//! 确定性 Block ID 生成
//!
//! 同一份 PDF 总是产生相同的 ID，保证可复现性。
//!
//! ## 设计原理
//!
//! - `generate_block_id`: 使用 (document_id, page, paragraph_index, text_prefix) 四元组生成 hash
//! - `generate_clause_id`: 使用 (document_id, page, clause_number) 三元组生成 hash
//!
//! **为什么 text_prefix 参与 hash**：
//! 同一页面同一位置的段落，如果内容变了（如 PDF 版本不同），应该产生不同的 Block ID。
//! text_prefix 取前 100 字符：轻微排版变化（空格/换行）不改变 ID，但实质内容变化会改变 ID。


use sha2::Digest;

/// 为段落 Block 生成确定性 ID
///
/// # 参数
/// - `document_id`: 文档唯一标识（如文件名或 hash）
/// - `page`: 页码（0-based）
/// - `paragraph_index`: 该页内的段落序号（0-based）
/// - `text_prefix`: 段落文本前 100 字符（归一化后）
///
/// # 返回
/// 格式为 `b_<8位hex>` 的 Block ID
///
/// # 示例
/// ```
/// use lesson4_quality_bbox::block_id::generate_block_id;
/// let id = generate_block_id("doc001", 3, 5, "第22条 投标人资格要求...");
/// assert!(id.starts_with("b_"));
/// assert_eq!(id.len(), 10); // "b_" + 8 hex chars
/// ```
pub fn generate_block_id(
    document_id: &str,
    page: usize,
    paragraph_index: usize,
    text_prefix: &str,
) -> String {
    let input = format!("{}:{}:{}:{}", document_id, page, paragraph_index, text_prefix);
    let hash = sha2::Sha256::digest(input.as_bytes());
    format!("b_{}", hex::encode(&hash[..4])) // 前 4 字节 = 8 hex chars
}

/// 为条款（Clause）生成确定性 ID
///
/// # 参数
/// - `document_id`: 文档唯一标识
/// - `page`: 条款所在页码（0-based）
/// - `clause_number`: 归一化后的条款编号（如 "22" 表示第22条）
///
/// # 返回
/// 格式为 `cl_<8位hex>` 的 Clause ID
pub fn generate_clause_id(
    document_id: &str,
    page: usize,
    clause_number: &str,
) -> String {
    let input = format!("{}:{}:clause:{}", document_id, page, clause_number);
    let hash = sha2::Sha256::digest(input.as_bytes());
    format!("cl_{}", hex::encode(&hash[..4]))
}

/// 为表格生成确定性 ID
pub fn generate_table_id(
    document_id: &str,
    page: usize,
    table_index: usize,
) -> String {
    let input = format!("{}:{}:table:{}", document_id, page, table_index);
    let hash = sha2::Sha256::digest(input.as_bytes());
    format!("t_{}", hex::encode(&hash[..4]))
}

/// 为章节生成确定性 ID
pub fn generate_section_id(
    document_id: &str,
    page: usize,
    section_title: &str,
) -> String {
    let input = format!("{}:{}:section:{}", document_id, page, section_title);
    let hash = sha2::Sha256::digest(input.as_bytes());
    format!("s_{}", hex::encode(&hash[..4]))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_block_id_deterministic() {
        let id1 = generate_block_id("doc001", 3, 5, "第22条 投标人资格要求");
        let id2 = generate_block_id("doc001", 3, 5, "第22条 投标人资格要求");
        assert_eq!(id1, id2, "相同输入必须产生相同 ID");
    }

    #[test]
    fn test_block_id_different_content() {
        let id1 = generate_block_id("doc001", 3, 5, "第22条 投标人资格要求");
        let id2 = generate_block_id("doc001", 3, 5, "第23条 合同价款支付");
        assert_ne!(id1, id2, "不同内容必须产生不同 ID");
    }

    #[test]
    fn test_block_id_different_page() {
        let id1 = generate_block_id("doc001", 3, 5, "第22条 投标人资格要求");
        let id2 = generate_block_id("doc001", 4, 5, "第22条 投标人资格要求");
        assert_ne!(id1, id2, "不同页码必须产生不同 ID");
    }

    #[test]
    fn test_clause_id_format() {
        let id = generate_clause_id("doc001", 3, "22");
        assert!(id.starts_with("cl_"));
        assert_eq!(id.len(), 11); // "cl_" + 8 hex chars
    }

    #[test]
    fn test_text_prefix_trimming() {
        // text_prefix 的变化应改变 ID
        let id1 = generate_block_id("doc001", 1, 0, "hello world");
        let id2 = generate_block_id("doc001", 1, 0, "hello  world"); // 双空格
        // 注意：内容变了（空格数不同），所以 ID 应该不同
        // 这是预期行为——text_prefix 参与 hash
        assert_ne!(id1, id2);
    }
}
