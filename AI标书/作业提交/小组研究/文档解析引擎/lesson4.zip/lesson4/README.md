# Lesson 4: 质量评估 + bbox 坐标链路

Day 4 课程作业 —— G1 组交付物：
1. 确定性 Block ID 生成
2. bbox 三层坐标变换
3. Golden Standard 标注 + 自动化 Benchmark

## 项目结构

```
lesson4/
├── Cargo.toml              # Rust 项目配置
├── README.md               # 本文件
├── src/
│   ├── lib.rs              # 库入口 — 导出所有模块
│   ├── block_id.rs         # 确定性 Block ID 生成
│   ├── bbox.rs             # bbox 三层坐标变换 (PDF→Canvas→DOM→视口)
│   ├── types.rs            # 核心数据类型 (ParsedDocument, Table, Clause...)
│   ├── golden.rs           # 任务1: Golden Standard 标注数据格式
│   ├── benchmark.rs        # 任务2: 自动化 Benchmark 引擎
│   ├── transform.rs        # 任务3: 坐标变换验证器
│   └── bin/
│       ├── annotate.rs     # 任务1 CLI: Golden Standard 标注工具
│       ├── benchmark.rs    # 任务2 CLI: Benchmark 运行器
│       └── verify_transform.rs  # 任务3 CLI: 坐标变换验证
├── data/
│   ├── golden_standard_sample.json  # 示例 Golden Standard
│   └── parsed_output_sample.json    # 示例解析输出
└── memory/                 # Claude Code 记忆文件
```

## 快速开始

```bash
# 编译项目
cargo build

# 运行测试
cargo test

# 查看所有测试（含详细输出）
cargo test -- --nocapture
```

## 任务1：Golden Standard 标注

```bash
# 生成空白模板
cargo run --bin annotate -- init --output data/my_golden.json

# 验证标注数据
cargo run --bin annotate -- validate --input data/golden_standard_sample.json
```

## 任务2：自动化 Benchmark

```bash
# 运行 Benchmark（比较解析结果与 Golden Standard）
cargo run --bin benchmark -- \
  --golden data/golden_standard_sample.json \
  --parsed data/parsed_output_sample.json \
  --text-report

# 带容差参数
cargo run --bin benchmark -- \
  --golden data/golden_standard_sample.json \
  --parsed data/parsed_output_sample.json \
  --row-tolerance 1 \
  --title-edit-distance 5
```

## 任务3：坐标变换验证

```bash
# 运行预置示例
cargo run --bin verify-transform -- example

# 手动验证
cargo run --bin verify-transform -- manual \
  --label "第12条 投标保证金" \
  --pdf-x 72 --pdf-y 400 --pdf-w 200 --pdf-h 24 \
  --page-w 595.28 --page-h 841.89 --scale 1.5 \
  --dpr 2.0 --scroll-top 300 \
  --container-top 80 \
  --actual-x 54 --actual-y 93.4 --actual-w 150 --actual-h 18

# 调试模式（逐步打印变换过程）
cargo run --bin verify-transform -- debug \
  --pdf-x 72 --pdf-y 400 --pdf-w 200 --pdf-h 24 \
  --page-w 595.28 --page-h 841.89 --scale 1.5 \
  --dpr 2.0 --scroll-top 300 --container-top 80
```

## 核心概念速查

### Block ID 生成

```
generate_block_id(document_id, page, paragraph_index, text_prefix)
→ "b_a3f2b1c8"

generate_clause_id(document_id, page, clause_number)
→ "cl_a3f2b1c8"
```

### bbox 三层变换

```
Layer 1: PDF (左下原点, pt) → Canvas Viewport (左上原点, px)
  vpX = pdfX × scale
  vpY = viewportHeight - (pdfY + pdfH) × scale

Layer 2: Canvas Viewport → CSS DOM
  cssX = vpX / devicePixelRatio
  cssY = vpY / devicePixelRatio

Layer 3: CSS DOM → 视口可见像素
  visibleY = cssY - scrollTop + containerTop
```

### Benchmark 指标

| 指标 | 基线 | 公式 |
|------|------|------|
| 表格行数正确率 | > 80% | 行数匹配的表 / 总表数 |
| 表格列数正确率 | > 80% | 列数匹配的表 / 总表数 |
| bbox RMSE | < 10pt | √(Σ(Δx²+Δy²) / n) |
| 坐标变换偏差 | < 5px | √(Δx²+Δy²) |

## 验收标准

- [x] 确定性 Block ID 生成实现
- [x] bbox 三层变换实现 + 测试
- [x] Golden Standard 数据格式定义
- [x] 自动化 Benchmark 引擎
- [x] 坐标变换验证器
- [ ] 20 页 Golden Standard 实际标注
- [ ] 表格识别率 > 80% 实测
- [ ] bbox RMSE < 10pt 实测
- [ ] 坐标变换验证偏差 < 5px 实测

## 思考题答案要点

1. **text_prefix 变化**：前后空格被去掉（归一化）则 ID 不变；
   如果归一化策略保留了空格差异，则 ID 会变。
   应确保 text_prefix 先做 strip 归一化。

2. **10pt ≈ 3.5mm**：在高亮显示场景下，偏移 3.5mm 用户可能注意到
   （尤其是小字体）。建议 RMSE < 5pt 作为严格标准。

3. **LLM 辅助标注**：用 GPT-4 看图标注章节起始页和表格行列数 →
   人工抽查 10% 修正 → 用修正反馈做 few-shot prompt 迭代。
