import os
import subprocess
import sys
import shutil

PDF_FILES = [
    "test_1_simple.pdf",
    "test_2_cid.pdf", 
    "test_3_compressed.pdf",
    "test_4_complex.pdf",
    "test_5_special.pdf",
    "test.pdf"
]

def run_rust_parser(pdf_path):
    result = subprocess.run(["./target/debug/pdf-parser.exe", pdf_path], 
                          capture_output=True, text=True, encoding='utf-8')
    if result.returncode != 0:
        print(f"Rust parser failed for {pdf_path}: {result.stderr}")
        return ""
    
    output = result.stdout
    if "Extracted text:\n" in output:
        return output.split("Extracted text:\n")[1]
    return ""

def run_pdfplumber(pdf_path):
    import pdfplumber
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    return text

def run_pdfextract(pdf_path):
    try:
        from pdf_extract import extract_text
        return extract_text(pdf_path)
    except Exception as e:
        print(f"pdf-extract failed for {pdf_path}: {e}")
        return ""

def save_result(output_dir, pdf_name, tool_name, content):
    os.makedirs(output_dir, exist_ok=True)
    filename = f"{pdf_name.replace('.pdf', '')}_{tool_name}.txt"
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    return filepath

def main():
    print("=" * 80)
    print("PDF文本提取对比实验")
    print("=" * 80)
    
    output_dir = "comparison_results"
    os.makedirs(output_dir, exist_ok=True)
    
    print("\n1. 使用Rust解析器提取文本...")
    for pdf in PDF_FILES:
        if os.path.exists(pdf):
            print(f"  Processing {pdf}...")
            text = run_rust_parser(pdf)
            save_result(output_dir, pdf, "rust", text)
            print(f"    提取了 {len(text)} 字符")
        else:
            print(f"  跳过 {pdf} - 文件不存在")
    
    print("\n2. 使用pdfplumber提取文本...")
    for pdf in PDF_FILES:
        if os.path.exists(pdf):
            print(f"  Processing {pdf}...")
            text = run_pdfplumber(pdf)
            save_result(output_dir, pdf, "pdfplumber", text)
            print(f"    提取了 {len(text)} 字符")
    
    print("\n3. 使用pdf-extract提取文本...")
    for pdf in PDF_FILES:
        if os.path.exists(pdf):
            print(f"  Processing {pdf}...")
            text = run_pdfextract(pdf)
            if text:
                save_result(output_dir, pdf, "pdfextract", text)
                print(f"    提取了 {len(text)} 字符")
            else:
                print("    跳过 - 提取失败")
    
    print("\n" + "=" * 80)
    print("对比实验完成！结果保存在 comparison_results/ 目录")
    print("=" * 80)

if __name__ == "__main__":
    main()