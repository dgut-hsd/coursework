import sys
import os

try:
    import pdfplumber
except ImportError:
    print("pdfplumber not installed. Installing...")
    os.system("pip install pdfplumber")
    import pdfplumber

def extract_with_pdfplumber(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text
                text += "\n"
    return text

def extract_with_pdfextract(pdf_path):
    try:
        from pdf_extract import extract_text
        return extract_text(pdf_path)
    except ImportError:
        print("pdf-extract not installed, skipping...")
        return ""
    except Exception as e:
        print(f"pdf-extract error: {e}")
        return ""

def save_result(filename, content):
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(content)

def compare_files(file1, file2):
    with open(file1, 'r', encoding='utf-8') as f1, open(file2, 'r', encoding='utf-8') as f2:
        content1 = f1.read()
        content2 = f2.read()
    
    lines1 = content1.split('\n')
    lines2 = content2.split('\n')
    
    diffs = []
    max_len = max(len(lines1), len(lines2))
    
    for i in range(max_len):
        line1 = lines1[i] if i < len(lines1) else ""
        line2 = lines2[i] if i < len(lines2) else ""
        
        if line1 != line2:
            diffs.append((i + 1, line1, line2))
    
    return diffs

def main():
    if len(sys.argv) < 2:
        print("Usage: python compare_pdfplumber.py <pdf-file>")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    print(f"Processing: {pdf_path}")
    
    print("Extracting with pdfplumber...")
    pdfplumber_text = extract_with_pdfplumber(pdf_path)
    save_result("output_pdfplumber.txt", pdfplumber_text)
    print(f"pdfplumber extracted {len(pdfplumber_text)} characters")
    
    print("Extracting with pdf-extract...")
    pdfextract_text = extract_with_pdfextract(pdf_path)
    if pdfextract_text:
        save_result("output_pdfextract.txt", pdfextract_text)
        print(f"pdf-extract extracted {len(pdfextract_text)} characters")
    
    print("Done!")

if __name__ == "__main__":
    main()
