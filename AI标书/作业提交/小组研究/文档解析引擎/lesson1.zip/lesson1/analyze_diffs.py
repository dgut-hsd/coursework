import sys
import difflib

def analyze_differences(file1, file2, label1="Rust Parser", label2="pdfplumber"):
    with open(file1, 'r', encoding='utf-8') as f1, open(file2, 'r', encoding='utf-8') as f2:
        content1 = f1.read()
        content2 = f2.read()
    
    print(f"=== {label1} vs {label2} 差异分析 ===")
    print(f"{label1} 字符数: {len(content1)}")
    print(f"{label2} 字符数: {len(content2)}")
    print()
    
    lines1 = content1.split('\n')
    lines2 = content2.split('\n')
    
    diff = difflib.unified_diff(
        lines1, lines2,
        fromfile=label1,
        tofile=label2,
        lineterm='',
        n=3
    )
    
    diff_lines = list(diff)
    if not diff_lines:
        print("两个提取器结果完全一致！")
        return
    
    print("差异位置摘要:")
    print("-" * 80)
    
    cid_missing_count = content1.count("无法映射")
    print(f"\n{label1} 中 CID 映射失败次数: {cid_missing_count}")
    
    print("\n详细差异（前50处）:")
    print("-" * 80)
    
    for i, line in enumerate(diff_lines[:100]):
        if line.startswith('@@'):
            print(f"\n{line}")
        elif line.startswith('-'):
            print(f"  {line}")
        elif line.startswith('+'):
            print(f"  {line}")
        else:
            print(f"    {line}")
    
    if len(diff_lines) > 100:
        print(f"\n... 还有 {len(diff_lines) - 100} 行差异未显示")
    
    analyze_root_causes(content1, content2)

def analyze_root_causes(content1, content2):
    print("\n=== 根因分析 ===")
    
    issues = []
    
    if content1.count("无法映射") > 0:
        issues.append("• CMap 映射缺失: Rust 解析器遇到了没有 ToUnicode CMap 的字体")
    
    if len(content1) < len(content2):
        issues.append("• 内容丢失: Rust 解析器可能未正确处理某些编码或压缩格式")
    
    if "\x00" in content1:
        issues.append("• 二进制数据: Rust 解析器可能将二进制数据误认为文本")
    
    if content2.count("\n") != content1.count("\n"):
        issues.append("• 换行差异: 两个解析器处理换行符的方式不同")
    
    if not issues:
        print("未发现明显问题")
    else:
        for issue in issues:
            print(issue)

def main():
    if len(sys.argv) < 3:
        print("Usage: python analyze_diffs.py <rust-output.txt> <pdfplumber-output.txt>")
        sys.exit(1)
    
    analyze_differences(sys.argv[1], sys.argv[2])
    
    if len(sys.argv) >= 4:
        print("\n" + "="*80)
        analyze_differences(sys.argv[1], sys.argv[3], "Rust Parser", "pdf-extract")

if __name__ == "__main__":
    main()
