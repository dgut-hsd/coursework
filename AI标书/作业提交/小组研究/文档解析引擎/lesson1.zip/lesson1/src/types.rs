use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq)]
pub struct PdfReference {
    pub object_number: u32,
    pub generation: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub enum PdfValue {
    Null,
    Bool(bool),
    Int(i64),
    Real(f64),
    String(Vec<u8>),
    Name(String),
    Array(Vec<PdfValue>),
    Dictionary(HashMap<String, PdfValue>),
    Reference(PdfReference),
    Stream(PdfStream),
}

#[derive(Debug, Clone, PartialEq)]
pub struct PdfStream {
    pub dictionary: HashMap<String, PdfValue>,
    pub data: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct PdfObject {
    pub object_number: u32,
    pub generation: u32,
    pub value: PdfValue,
}

#[derive(Debug, Clone, PartialEq)]
pub struct XrefEntry {
    pub offset: u64,
    pub generation: u32,
    pub in_use: bool,
}

pub type XrefTable = Vec<Option<XrefEntry>>;

#[derive(Debug, Clone)]
pub struct PdfDocument {
    pub data: Vec<u8>,
    pub xref: XrefTable,
}

#[derive(Debug, thiserror::Error)]
pub enum PdfError {
    #[error("Invalid PDF header")]
    InvalidHeader,
    #[error("EOF marker not found")]
    EofMarkerNotFound,
    #[error("Xref table not found")]
    XrefTableNotFound,
    #[error("Trailer dictionary not found")]
    TrailerNotFound,
    #[error("Invalid xref entry")]
    InvalidXrefEntry,
    #[error("Object not found: {0}")]
    ObjectNotFound(u32),
    #[error("Reference not found: {0} {1}")]
    ReferenceNotFound(u32, u32),
    #[error("Invalid stream")]
    InvalidStream,
    #[error("Unsupported compression: {0}")]
    UnsupportedCompression(String),
    #[error("Decompression failed")]
    DecompressionFailed,
    #[error("Cannot map CID=0x{0:04X}: {1}")]
    CidMappingFailed(u16, String),
    #[error("Parse error: {0}")]
    ParseError(String),
}

impl From<nom::Err<nom::error::Error<&[u8]>>> for PdfError {
    fn from(e: nom::Err<nom::error::Error<&[u8]>>) -> Self {
        PdfError::ParseError(format!("{:?}", e))
    }
}
