use std::collections::HashMap;

use crate::cmap::*;
use crate::parser::*;
use crate::types::*;

pub fn extract_text(doc: &mut PdfDocument) -> Result<String, PdfError> {
    let mut text = String::new();
    
    let pages = get_pages(doc)?;
    
    for page_ref in pages {
        let page_obj = resolve_reference(doc, &page_ref)?;
        let page_content = extract_page_content(doc, &page_obj)?;
        text.push_str(&page_content);
        text.push('\n');
    }
    
    Ok(text)
}

fn get_pages(doc: &mut PdfDocument) -> Result<Vec<PdfReference>, PdfError> {
    let mut refs = Vec::new();
    
    let catalog_ref = find_root_catalog(doc)?;
    let catalog_obj = resolve_reference(doc, &catalog_ref)?;
    
    if let PdfValue::Dictionary(catalog) = &catalog_obj.value {
        if let Some(pages_ref) = catalog.get("Pages") {
            let pages_val = get_value(doc, pages_ref)?;
            if let PdfValue::Dictionary(pages_dict) = &pages_val {
                extract_page_refs(doc, pages_dict, &mut refs)?;
            }
        }
    }
    
    Ok(refs)
}

fn find_root_catalog(doc: &PdfDocument) -> Result<PdfReference, PdfError> {
    let trailer_start = doc
        .data
        .windows(7)
        .rposition(|w| w == b"trailer")
        .ok_or(PdfError::TrailerNotFound)?;
    
    let mut input = &doc.data[trailer_start + 7..];
    while !input.is_empty() && (input[0] == b' ' || input[0] == b'\n' || input[0] == b'\r') {
        input = &input[1..];
    }
    
    while !input.is_empty() && input[0] == b'%' {
        if let Some(pos) = input.iter().position(|&c| c == b'\n') {
            input = &input[pos + 1..];
            while !input.is_empty() && (input[0] == b' ' || input[0] == b'\n' || input[0] == b'\r') {
                input = &input[1..];
            }
        } else {
            break;
        }
    }
    
    let (_, trailer) = crate::parser::parse_dictionary(input)?;
    
    if let PdfValue::Dictionary(trailer_dict) = trailer {
        if let Some(root) = trailer_dict.get("Root") {
            if let PdfValue::Reference(r) = root {
                return Ok(r.clone());
            }
        }
    }
    
    Err(PdfError::ParseError("Root not found in trailer".to_string()))
}

fn extract_page_refs(doc: &mut PdfDocument, dict: &HashMap<String, PdfValue>, refs: &mut Vec<PdfReference>) -> Result<(), PdfError> {
    if let Some(kids) = dict.get("Kids") {
        let kids_val = get_value(doc, kids)?;
        if let PdfValue::Array(kids_array) = &kids_val {
            for kid in kids_array {
                match kid {
                    PdfValue::Reference(r) => {
                        let obj = resolve_reference(doc, &r)?;
                        if let PdfValue::Dictionary(page_dict) = &obj.value {
                            if page_dict.contains_key("Type") {
                                let type_val = get_value(doc, page_dict.get("Type").unwrap())?;
                                if let PdfValue::Name(name) = type_val {
                                    if name == "Page" {
                                        refs.push(r.clone());
                                    } else if name == "Pages" {
                                        extract_page_refs(doc, page_dict, refs)?;
                                    }
                                }
                            }
                        }
                    }
                    _ => {}
                }
            }
        }
    }
    Ok(())
}

fn extract_page_content(doc: &mut PdfDocument, page_obj: &PdfObject) -> Result<String, PdfError> {
    let mut text = String::new();
    
    if let PdfValue::Dictionary(page_dict) = &page_obj.value {
        if let Some(content) = page_dict.get("Contents") {
            let content_val = get_value(doc, content)?;
            
            match content_val {
                PdfValue::Stream(stream) => {
                    let decoded = decode_stream(&stream.dictionary, &stream.data)?;
                    text.push_str(&process_content_stream(doc, page_dict, &decoded)?);
                }
                PdfValue::Array(contents) => {
                    for content_ref in contents {
                        if let PdfValue::Reference(r) = content_ref {
                            let obj = resolve_reference(doc, &r)?;
                            if let PdfValue::Stream(stream) = &obj.value {
                                let decoded = decode_stream(&stream.dictionary, &stream.data)?;
                                text.push_str(&process_content_stream(doc, page_dict, &decoded)?);
                            }
                        }
                    }
                }
                _ => {}
            }
        }
    }
    
    Ok(text)
}

pub fn decode_stream(dict: &HashMap<String, PdfValue>, data: &[u8]) -> Result<Vec<u8>, PdfError> {
    let filter = dict.get("Filter");
    
    if let Some(PdfValue::Array(filters)) = filter {
        println!("DEBUG: decode_stream - multiple filters: {:?}", filters);
        println!("DEBUG: decode_stream - data length: {}", data.len());
    }
    
    match filter {
        Some(PdfValue::Name(name)) => match name.as_str() {
            "FlateDecode" | "Fl" => {
                println!("DEBUG: FlateDecode - input length: {}", data.len());
                println!("DEBUG: FlateDecode - first 4 bytes: {:?}", &data[..std::cmp::min(4, data.len())]);
                
                let mut decoded = Vec::new();
                
                if data.starts_with(&[0x78, 0x01]) || data.starts_with(&[0x78, 0x5E]) || 
                   data.starts_with(&[0x78, 0x9C]) || data.starts_with(&[0x78, 0xDA]) {
                    println!("DEBUG: FlateDecode - using ZlibDecoder");
                    let mut decoder = flate2::read::ZlibDecoder::new(data);
                    match std::io::Read::read_to_end(&mut decoder, &mut decoded) {
                        Ok(_) => {
                            println!("DEBUG: FlateDecode - output length: {}", decoded.len());
                            Ok(decoded)
                        }
                        Err(e) => {
                            println!("DEBUG: FlateDecode - ZlibDecoder error: {}", e);
                            Err(PdfError::DecompressionFailed)
                        }
                    }
                } else {
                    println!("DEBUG: FlateDecode - using DeflateDecoder");
                    let mut decoder = flate2::read::DeflateDecoder::new(data);
                    match std::io::Read::read_to_end(&mut decoder, &mut decoded) {
                        Ok(_) => {
                            println!("DEBUG: FlateDecode - output length: {}", decoded.len());
                            Ok(decoded)
                        }
                        Err(e) => {
                            println!("DEBUG: FlateDecode - DeflateDecoder error: {}", e);
                            Err(PdfError::DecompressionFailed)
                        }
                    }
                }
            }
            "ZStdDecode" => {
                let decoded = zstd::decode_all(data).map_err(|_| PdfError::DecompressionFailed)?;
                Ok(decoded)
            }
            "ASCIIHexDecode" | "AHx" => {
                let hex_str = String::from_utf8_lossy(data);
                let decoded = hex::decode(hex_str.replace("\n", "").replace("\r", "")).unwrap_or_default();
                Ok(decoded)
            }
            "ASCII85Decode" | "A85" => {
                let decoded = ascii85_decode(data);
                println!("DEBUG: ASCII85Decode - input length: {}, output length: {}", data.len(), decoded.len());
                Ok(decoded)
            }
            _ => Err(PdfError::UnsupportedCompression(name.clone())),
        },
        Some(PdfValue::Array(filters)) => {
            let mut decoded = data.to_vec();
            for filter in filters {
                if let PdfValue::Name(name) = filter {
                    decoded = decode_stream(&HashMap::from([("Filter".to_string(), PdfValue::Name(name.clone()))]), &decoded)?;
                }
            }
            Ok(decoded)
        }
        None => Ok(data.to_vec()),
        _ => Ok(data.to_vec()),
    }
}

fn ascii85_decode(data: &[u8]) -> Vec<u8> {
    let mut result = Vec::new();
    let mut buffer = [0u8; 5];
    let mut count = 0;
    
    for &c in data {
        if c == b'~' {
            break;
        }
        if c.is_ascii_whitespace() {
            continue;
        }
        if c == b'z' && count == 0 {
            result.extend_from_slice(&[0, 0, 0, 0]);
            continue;
        }
        
        buffer[count] = c;
        count += 1;
        
        if count == 5 {
            let mut value = 0u32;
            for &b in &buffer {
                value = value * 85 + (b - b'!') as u32;
            }
            result.push((value >> 24) as u8);
            result.push(((value >> 16) & 0xFF) as u8);
            result.push(((value >> 8) & 0xFF) as u8);
            result.push((value & 0xFF) as u8);
            count = 0;
        }
    }
    
    if count > 0 {
        let mut value = 0u32;
        for i in 0..count {
            value = value * 85 + (buffer[i] - b'!') as u32;
        }
        for i in count..5 {
            value = value * 85 + 84;
        }
        if count >= 2 { result.push((value >> 24) as u8); }
        if count >= 3 { result.push(((value >> 16) & 0xFF) as u8); }
        if count >= 4 { result.push(((value >> 8) & 0xFF) as u8); }
    }
    
    result
}

fn process_content_stream(doc: &mut PdfDocument, page_dict: &HashMap<String, PdfValue>, content: &[u8]) -> Result<String, PdfError> {
    let font_dict = get_font_dict(doc, page_dict)?;
    
    let content_str = String::from_utf8_lossy(content);
    let tokens = tokenize_content_stream(&content_str);
    
    let mut text = String::new();
    let mut current_font = None;
    
    let mut i = 0;
    while i < tokens.len() {
        let token = &tokens[i];
        
        if token.starts_with('/') {
            current_font = Some(token[1..].to_string());
        }
        
        if token == "Tj" || token == "'" || token == "\"" {
            if i > 0 {
                let operand = &tokens[i-1];
                let extracted = extract_text_from_operand(doc, &font_dict, &current_font, operand)?;
                text.push_str(&extracted);
            }
        }
        
        if token == "TJ" {
            if i > 0 {
                let operand = &tokens[i-1];
                if operand.starts_with('[') && operand.ends_with(']') {
                    let array_content = &operand[1..operand.len()-1];
                    let elements = parse_tj_array(array_content);
                    for element in elements {
                        if let Ok(extracted) = extract_text_from_operand(doc, &font_dict, &current_font, &element) {
                            text.push_str(&extracted);
                        }
                    }
                }
            }
        }
        
        i += 1;
    }
    
    Ok(text)
}

fn get_font_dict(doc: &mut PdfDocument, page_dict: &HashMap<String, PdfValue>) -> Result<HashMap<String, HashMap<String, PdfValue>>, PdfError> {
    let mut fonts = HashMap::new();
    
    if let Some(resources) = page_dict.get("Resources") {
        let resources_val = get_value(doc, resources)?;
        if let PdfValue::Dictionary(res_dict) = &resources_val {
            if let Some(font_res) = res_dict.get("Font") {
                let font_res_val = get_value(doc, font_res)?;
                if let PdfValue::Dictionary(font_dict) = &font_res_val {
                    for (key, font_ref) in font_dict {
                        let font_val = get_value(doc, font_ref)?;
                        if let PdfValue::Dictionary(font) = font_val {
                            fonts.insert(key.clone(), font);
                        }
                    }
                }
            }
        }
    }
    
    Ok(fonts)
}

fn tokenize_content_stream(content: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();
    let mut in_string = false;
    let mut in_array = 0;
    let mut in_dict = 0;
    
    for c in content.chars() {
        if in_string {
            current.push(c);
            if c == ')' {
                in_string = false;
                tokens.push(current.clone());
                current.clear();
            }
            continue;
        }
        
        if c == '(' {
            in_string = true;
            current.push(c);
            continue;
        }
        
        if c == '[' {
            in_array += 1;
            current.push(c);
            continue;
        }
        
        if c == ']' {
            in_array -= 1;
            current.push(c);
            if in_array == 0 {
                tokens.push(current.clone());
                current.clear();
            }
            continue;
        }
        
        if c == '<' {
            in_dict += 1;
            current.push(c);
            continue;
        }
        
        if c == '>' {
            in_dict -= 1;
            current.push(c);
            if in_dict == 0 && current.starts_with("<<") {
                tokens.push(current.clone());
                current.clear();
            }
            continue;
        }
        
        if in_array > 0 || in_dict > 0 {
            current.push(c);
            continue;
        }
        
        if c.is_ascii_whitespace() {
            if !current.is_empty() {
                tokens.push(current.clone());
                current.clear();
            }
            continue;
        }
        
        current.push(c);
    }
    
    if !current.is_empty() {
        tokens.push(current);
    }
    
    tokens
}

fn parse_tj_array(content: &str) -> Vec<String> {
    let mut elements = Vec::new();
    let mut current = String::new();
    let mut in_string = false;
    
    for c in content.chars() {
        if in_string {
            current.push(c);
            if c == ')' {
                in_string = false;
                elements.push(current.clone());
                current.clear();
            }
            continue;
        }
        
        if c == '(' {
            in_string = true;
            current.push(c);
            continue;
        }
        
        if c == ' ' || c == ',' {
            if !current.is_empty() {
                elements.push(current.clone());
                current.clear();
            }
            continue;
        }
        
        current.push(c);
    }
    
    if !current.is_empty() {
        elements.push(current);
    }
    
    elements
}

fn extract_text_from_operand(doc: &mut PdfDocument, font_dict: &HashMap<String, HashMap<String, PdfValue>>, current_font: &Option<String>, operand: &str) -> Result<String, PdfError> {
    if operand.is_empty() {
        return Ok(String::new());
    }
    
    let font_name = current_font.clone().unwrap_or_default();
    let font = font_dict.get(&font_name);
    
    let mut cmap = match font {
        Some(f) => {
            match get_cmap(doc, f) {
                Ok(c) => c,
                Err(_) => build_basic_cmap(),
            }
        }
        None => build_basic_cmap(),
    };
    
    if operand.starts_with('(') && operand.ends_with(')') {
        let content = &operand[1..operand.len()-1];
        let mut result = String::new();
        
        for ch in content.chars() {
            let cid = ch as u16;
            match cmap.map(cid) {
                Some(mapped) => result.push(mapped),
                None => {
                    result.push_str(&format!("(CID=0x{:04X} 无法映射，原因：ToUnicode CMap 缺失)", cid));
                }
            }
        }
        
        Ok(result)
    } else if operand.starts_with('<') && operand.ends_with('>') {
        let hex_str = &operand[1..operand.len()-1];
        let bytes = hex::decode(hex_str).unwrap_or_default();
        let mut result = String::new();
        
        for &byte in &bytes {
            let cid = byte as u16;
            match cmap.map(cid) {
                Some(mapped) => result.push(mapped),
                None => {
                    result.push_str(&format!("(CID=0x{:04X} 无法映射，原因：ToUnicode CMap 缺失)", cid));
                }
            }
        }
        
        Ok(result)
    } else {
        Ok(String::new())
    }
}
