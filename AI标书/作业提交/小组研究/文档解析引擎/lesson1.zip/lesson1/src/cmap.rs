use std::collections::HashMap;

use crate::types::*;

#[derive(Debug, Clone)]
pub struct CMap {
    pub mappings: HashMap<u16, char>,
    pub name: String,
}

impl CMap {
    pub fn new(name: &str) -> Self {
        CMap {
            mappings: HashMap::new(),
            name: name.to_string(),
        }
    }
    
    pub fn map(&self, cid: u16) -> Option<char> {
        self.mappings.get(&cid).copied()
    }
    
    pub fn add_mapping(&mut self, cid: u16, ch: char) {
        self.mappings.insert(cid, ch);
    }
}

pub fn parse_cmap(data: &[u8]) -> CMap {
    let mut cmap = CMap::new("unknown");
    let text = String::from_utf8_lossy(data);
    
    for line in text.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with("/CMapName") {
            if let Some(name) = trimmed.split_whitespace().nth(1) {
                let name = name.trim_matches('/');
                cmap.name = name.to_string();
            }
        }
        
        if trimmed.starts_with("beginbfchar") {
            let mut chars = trimmed.split_whitespace();
            chars.next();
            while let Some(cid_str) = chars.next() {
                if let Some(char_str) = chars.next() {
                    let cid = parse_hex(cid_str).unwrap_or(0);
                    let ch = parse_unicode(char_str).unwrap_or('\u{FFFD}');
                    cmap.add_mapping(cid as u16, ch);
                }
            }
        }
        
        if trimmed.starts_with("beginbfrange") {
            let mut parts = trimmed.split_whitespace();
            parts.next();
            while let Some(start_str) = parts.next() {
                if let Some(end_str) = parts.next() {
                    if let Some(start_char_str) = parts.next() {
                        let start = parse_hex(start_str).unwrap_or(0);
                        let end = parse_hex(end_str).unwrap_or(0);
                        let start_char = parse_unicode(start_char_str).unwrap_or('\u{FFFD}');
                        
                        for i in 0..=(end - start) {
                            let cid = (start + i) as u16;
                            let ch = char::from_u32(start_char as u32 + i).unwrap_or('\u{FFFD}');
                            cmap.add_mapping(cid, ch);
                        }
                    }
                }
            }
        }
    }
    
    cmap
}

fn parse_hex(s: &str) -> Option<u32> {
    let s = s.trim_matches(|c| c == '<' || c == '>' || c == '/');
    u32::from_str_radix(s, 16).ok()
}

fn parse_unicode(s: &str) -> Option<char> {
    let s = s.trim_matches(|c| c == '<' || c == '>' || c == '/');
    u32::from_str_radix(s, 16).ok().and_then(char::from_u32)
}

pub fn build_basic_cmap() -> CMap {
    let mut cmap = CMap::new("basic");
    
    for i in 0x20..=0x7E {
        cmap.add_mapping(i, char::from_u32(i as u32).unwrap_or('\u{FFFD}'));
    }
    
    cmap
}

pub fn get_cmap(doc: &mut crate::types::PdfDocument, font_dict: &HashMap<String, PdfValue>) -> Result<CMap, PdfError> {
    if let Some(to_unicode) = font_dict.get("ToUnicode") {
        match to_unicode {
            PdfValue::Reference(r) => {
                let obj = crate::parser::resolve_reference(doc, r)?;
                if let PdfValue::Stream(stream) = &obj.value {
                    let decoded = crate::extractor::decode_stream(&stream.dictionary, &stream.data)?;
                    let cmap = parse_cmap(&decoded);
                    return Ok(cmap);
                }
            }
            PdfValue::Stream(stream) => {
                let decoded = crate::extractor::decode_stream(&stream.dictionary, &stream.data)?;
                let cmap = parse_cmap(&decoded);
                return Ok(cmap);
            }
            _ => {}
        }
    }
    
    Err(PdfError::CidMappingFailed(0, "ToUnicode CMap 缺失".to_string()))
}
