mod types;
mod parser;
mod extractor;
mod cmap;

use std::fs;
use std::path::Path;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("Usage: pdf-parser <pdf-file>");
        std::process::exit(1);
    }

    let pdf_path = Path::new(&args[1]);
    let content = fs::read(pdf_path)?;
    
    let xref = parser::parse_xref(&content)?;
    println!("Found {} objects in xref table", xref.len());
    
    let mut doc = types::PdfDocument {
        data: content,
        xref,
    };
    
    let text = extractor::extract_text(&mut doc)?;
    println!("Extracted text:\n{}", text);
    
    Ok(())
}
