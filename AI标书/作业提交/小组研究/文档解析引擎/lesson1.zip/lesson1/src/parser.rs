use nom::{
    branch::alt,
    bytes::complete::{tag, take, take_while},
    character::complete::{digit1, line_ending},
    combinator::{map, map_res, opt},
    multi::many0,
    sequence::{delimited, preceded, tuple},
    IResult,
};
use std::collections::HashMap;

use crate::types::*;

type ParseResult<'a, T> = IResult<&'a [u8], T>;

fn skip_ws(input: &[u8]) -> &[u8] {
    let mut i = 0;
    while i < input.len() && (input[i] == b' ' || input[i] == b'\n' || input[i] == b'\r' || input[i] == b'\t') {
        i += 1;
    }
    &input[i..]
}

pub fn parse_xref(data: &[u8]) -> Result<XrefTable, PdfError> {
    let eof_pos = data
        .windows(5)
        .rposition(|w| w == b"%%EOF")
        .ok_or(PdfError::EofMarkerNotFound)?;

    let search_end = std::cmp::min(eof_pos, data.len() - 4);
    
    for search_pos in (0..=search_end).rev() {
        if &data[search_pos..search_pos + 4] == b"xref" {
            let is_line_start = search_pos == 0 || 
                               data[search_pos - 1] == b'\n' || 
                               data[search_pos - 1] == b'\r';
            if is_line_start {
                let (_, table) = parse_xref_table(&data[search_pos..])?;
                return Ok(table);
            }
        }
    }
    
    Err(PdfError::XrefTableNotFound)
}

fn parse_xref_table(input: &[u8]) -> ParseResult<XrefTable> {
    let (input, _) = tag(b"xref")(input)?;
    let input = skip_ws(input);
    
    let mut sections = Vec::new();
    let mut remaining = input;
    
    loop {
        remaining = skip_ws(remaining);
        if remaining.len() >= 7 && &remaining[..7] == b"trailer" {
            break;
        }
        
        match parse_xref_section(remaining) {
            Ok((rest, section)) => {
                sections.push(section);
                remaining = rest;
            }
            Err(_) => break,
        }
    }
    
    let max_obj_num = sections.iter().map(|(first, entries)| first + entries.len() as u32 - 1).max().unwrap_or(0);
    let mut table: XrefTable = vec![None; max_obj_num as usize + 1];
    for (first_obj_num, entries) in sections {
        for (i, entry) in entries.iter().enumerate() {
            let obj_num = first_obj_num + i as u32;
            if obj_num < table.len() as u32 {
                table[obj_num as usize] = Some(entry.clone());
            }
        }
    }
    
    Ok((remaining, table))
}

fn parse_xref_section(input: &[u8]) -> ParseResult<(u32, Vec<XrefEntry>)> {
    let (input, first_obj_num) = map_res(digit1, |s: &[u8]| String::from_utf8_lossy(s).parse::<u32>())(input)?;
    let input = skip_ws(input);
    let (input, count) = map_res(digit1, |s: &[u8]| String::from_utf8_lossy(s).parse::<u32>())(input)?;
    let (mut input, _) = opt(line_ending)(input)?;
    
    let mut entries = Vec::new();
    for _ in 0..count {
        input = skip_ws(input);
        
        if input.len() >= 7 && &input[..7] == b"trailer" {
            break;
        }
        
        let (rest, entry) = parse_xref_entry(input)?;
        entries.push(entry);
        input = rest;
    }
    
    Ok((input, (first_obj_num, entries)))
}

fn parse_xref_entry(input: &[u8]) -> ParseResult<XrefEntry> {
    let mut i = 0;
    while i < input.len() && input[i] != b'\n' && input[i] != b'\r' {
        i += 1;
    }
    
    let line = &input[..i];
    let parts: Vec<&[u8]> = line.split(|c| *c == b' ').filter(|p| !p.is_empty()).collect();
    
    let mut rest = &input[i..];
    while !rest.is_empty() && (rest[0] == b'\n' || rest[0] == b'\r') {
        rest = &rest[1..];
    }
    
    if parts.len() >= 3 {
        let offset = String::from_utf8_lossy(parts[0]).trim().parse::<u64>().unwrap_or(0);
        let generation = String::from_utf8_lossy(parts[1]).trim().parse::<u32>().unwrap_or(0);
        let in_use = parts[2][0] == b'n';
        Ok((rest, XrefEntry { offset, generation, in_use }))
    } else {
        Err(nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Tag)))
    }
}

pub fn parse_object(data: &[u8], offset: u64) -> Result<PdfObject, PdfError> {
    let offset = offset as usize;
    if offset >= data.len() {
        return Err(PdfError::InvalidXrefEntry);
    }
    
    let mut input = &data[offset..];
    
    while !input.is_empty() && input[0] == b'%' {
        let pos = input.iter().position(|&c| c == b'\n');
        match pos {
            Some(p) => input = &input[p + 1..],
            None => break,
        }
    }
    input = skip_ws(input);
    
    let (rest, object_number) = map_res(digit1, |s: &[u8]| String::from_utf8_lossy(s).parse::<u32>())(input)?;
    input = skip_ws(rest);
    
    let (rest, generation) = map_res(digit1, |s: &[u8]| String::from_utf8_lossy(s).parse::<u32>())(input)?;
    input = skip_ws(rest);
    
    let (mut input, _) = tag(b"obj")(input)?;
    input = skip_ws(input);
    
    let (rest, value) = parse_value(input)?;
    input = skip_ws(rest);
    
    let (_, _) = tag(b"endobj")(input)?;
    
    Ok(PdfObject {
        object_number,
        generation,
        value,
    })
}

fn parse_value(input: &[u8]) -> ParseResult<PdfValue> {
    let input = skip_ws(input);
    
    if input.is_empty() {
        return Err(nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Tag)));
    }
    
    match input[0] {
        b'<' if input.len() > 1 && input[1] == b'<' => parse_dictionary(input),
        b'[' => parse_array(input),
        b'(' => parse_literal_string(input),
        b'<' if input.len() > 1 && input[1] != b'<' => parse_hex_string(input),
        b'/' => parse_name(input),
        b'n' if input.starts_with(b"null") => Ok((&input[4..], PdfValue::Null)),
        b't' if input.starts_with(b"true") => Ok((&input[4..], PdfValue::Bool(true))),
        b'f' if input.starts_with(b"false") => Ok((&input[5..], PdfValue::Bool(false))),
        b'-' | b'0'..=b'9' => parse_reference_or_number(input),
        _ => parse_reference_or_number(input),
    }
}

fn parse_number(input: &[u8]) -> ParseResult<PdfValue> {
    match parse_real(input) {
        Ok((rest, real_val)) => Ok((rest, PdfValue::Real(real_val))),
        Err(_) => {
            let (rest, int_val) = parse_int(input)?;
            Ok((rest, PdfValue::Int(int_val)))
        }
    }
}

fn parse_reference_or_number(input: &[u8]) -> ParseResult<PdfValue> {
    match parse_reference(input) {
        Ok(result) => Ok(result),
        Err(_) => parse_number(input),
    }
}

fn parse_int(input: &[u8]) -> ParseResult<i64> {
    let (input, sign) = opt(tag(b"-"))(input)?;
    let (input, digits) = digit1(input)?;
    let num_str = if sign.is_some() {
        format!("-{}", String::from_utf8_lossy(digits))
    } else {
        String::from_utf8_lossy(digits).to_string()
    };
    match num_str.parse::<i64>() {
        Ok(n) => Ok((input, n)),
        Err(_) => Err(nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Digit))),
    }
}

fn parse_real(input: &[u8]) -> ParseResult<f64> {
    let (input, sign) = opt(tag(b"-"))(input)?;
    let (input, int_part) = digit1(input)?;
    if input.is_empty() || input[0] != b'.' {
        return Err(nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Tag)));
    }
    let (input, _) = tag(b".")(input)?;
    let (input, frac_part) = digit1(input)?;
    
    let num_str = if sign.is_some() {
        format!("-{}.{}", String::from_utf8_lossy(int_part), String::from_utf8_lossy(frac_part))
    } else {
        format!("{}.{}", String::from_utf8_lossy(int_part), String::from_utf8_lossy(frac_part))
    };
    match num_str.parse::<f64>() {
        Ok(n) => Ok((input, n)),
        Err(_) => Err(nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Float))),
    }
}

fn parse_literal_string(input: &[u8]) -> ParseResult<PdfValue> {
    let (input, _) = tag(b"(")(input)?;
    let mut depth = 1;
    let mut i = 0;
    while i < input.len() && depth > 0 {
        if input[i] == b'\\' && i + 1 < input.len() {
            i += 2;
            continue;
        }
        if input[i] == b'(' {
            depth += 1;
        } else if input[i] == b')' {
            depth -= 1;
        }
        i += 1;
    }
    
    if depth != 0 {
        return Err(nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Tag)));
    }
    
    let content = &input[..i-1];
    let rest = &input[i..];
    
    Ok((rest, PdfValue::String(content.to_vec())))
}

fn parse_hex_string(input: &[u8]) -> ParseResult<PdfValue> {
    let (input, _) = tag(b"<")(input)?;
    let (input, hex_digits) = take_while(|c| matches!(c, b'0'..=b'9' | b'A'..=b'F' | b'a'..=b'f'))(input)?;
    let (input, _) = tag(b">")(input)?;
    
    let hex_str = String::from_utf8_lossy(hex_digits).to_string();
    let bytes = hex::decode(hex_str).unwrap_or_default();
    
    Ok((input, PdfValue::String(bytes)))
}

fn parse_name(input: &[u8]) -> ParseResult<PdfValue> {
    let (input, _) = tag(b"/")(input)?;
    let (input, name_bytes) = take_while(|c| {
        !matches!(c, b' ' | b'\n' | b'\r' | b'\t' | b'/' | b'<' | b'>' | b'(' | b')' | b'[' | b']' | b'{' | b'}' | b'%' | b'"')
    })(input)?;
    let name = String::from_utf8_lossy(name_bytes).to_string();
    
    Ok((input, PdfValue::Name(name)))
}

fn parse_array(input: &[u8]) -> ParseResult<PdfValue> {
    let (mut input, _) = tag(b"[")(input)?;
    let mut elements = Vec::new();
    
    loop {
        input = skip_ws(input);
        
        if input.starts_with(b"]") {
            let (input, _) = tag(b"]")(input)?;
            return Ok((input, PdfValue::Array(elements)));
        }
        
        let (rest, value) = parse_value(input)?;
        elements.push(value);
        input = rest;
    }
}

pub fn parse_dictionary(input: &[u8]) -> ParseResult<PdfValue> {
    let (mut input, _) = tag(b"<<")(input)?;
    let mut dict = HashMap::new();
    
    loop {
        input = skip_ws(input);
        
        while !input.is_empty() && input[0] == b'%' {
            if let Some(pos) = input.iter().position(|&c| c == b'\n') {
                input = &input[pos + 1..];
                input = skip_ws(input);
            } else {
                break;
            }
        }
        
        if input.starts_with(b">>") {
            let (input, _) = tag(b">>")(input)?;
            
            let (input, value) = match parse_stream_marker(input) {
                Ok((rest, _)) => {
                    let (rest, data) = parse_stream_data(rest, &dict)?;
                    (rest, PdfValue::Stream(PdfStream { dictionary: dict, data }))
                }
                Err(_) => (input, PdfValue::Dictionary(dict)),
            };
            
            return Ok((input, value));
        }
        
        let (rest, name) = parse_name(input)?;
        let name_str = match name {
            PdfValue::Name(n) => n,
            _ => String::new(),
        };
        
        let (rest, value) = parse_value(skip_ws(rest))?;
        dict.insert(name_str, value);
        input = rest;
    }
}

fn parse_stream_marker(input: &[u8]) -> ParseResult<()> {
    let input = skip_ws(input);
    let (input, _) = tag(b"stream")(input)?;
    Ok((input, ()))
}

fn parse_stream_data<'a>(input: &'a [u8], dict: &HashMap<String, PdfValue>) -> ParseResult<'a, Vec<u8>> {
    let (input, _) = line_ending(input)?;
    
    let length = dict
        .get("Length")
        .and_then(|v| match v {
            PdfValue::Int(i) => Some(*i as usize),
            _ => None,
        })
        .unwrap_or(0);
    
    if length == 0 {
        let end_pos = input.windows(10).position(|w| w == b"endstream");
        match end_pos {
            Some(pos) => Ok((&input[pos + 10..], input[..pos].to_vec())),
            None => Ok((input, Vec::new())),
        }
    } else {
        let (input, data) = take(length)(input)?;
        let input = skip_ws(input);
        let (input, _) = tag(b"endstream")(input)?;
        Ok((input, data.to_vec()))
    }
}

fn parse_reference(input: &[u8]) -> ParseResult<PdfValue> {
    let (rest, object_number) = map_res(digit1, |s: &[u8]| String::from_utf8_lossy(s).parse::<u32>())(input)?;
    let input = skip_ws(rest);
    let (rest, generation) = map_res(digit1, |s: &[u8]| String::from_utf8_lossy(s).parse::<u32>())(input)?;
    let input = skip_ws(rest);
    
    if !input.starts_with(b"R") {
        return Err(nom::Err::Error(nom::error::Error::new(input, nom::error::ErrorKind::Tag)));
    }
    
    Ok((&input[1..], PdfValue::Reference(PdfReference { object_number, generation })))
}

pub fn resolve_reference(doc: &PdfDocument, r: &PdfReference) -> Result<PdfObject, PdfError> {
    let entry = doc
        .xref
        .get(r.object_number as usize)
        .ok_or(PdfError::ReferenceNotFound(r.object_number, r.generation))?
        .as_ref()
        .ok_or(PdfError::ReferenceNotFound(r.object_number, r.generation))?;
    
    if !entry.in_use {
        return Err(PdfError::ReferenceNotFound(r.object_number, r.generation));
    }
    
    parse_object(&doc.data, entry.offset)
}

pub fn get_value(doc: &mut PdfDocument, value: &PdfValue) -> Result<PdfValue, PdfError> {
    match value {
        PdfValue::Reference(r) => {
            let obj = resolve_reference(doc, r)?;
            get_value(doc, &obj.value)
        }
        _ => Ok(value.clone()),
    }
}
