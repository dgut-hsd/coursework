import os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

def create_test_pdf_1_simple():
    c = canvas.Canvas("test_1_simple.pdf", pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(72, 750, "招标文件")
    c.drawString(72, 730, "项目名称：城市道路改造工程")
    c.drawString(72, 710, "招标编号：ZB-2024-001")
    c.drawString(72, 690, "招标人：市政工程管理局")
    c.drawString(72, 670, "开标时间：2024年12月15日 10:00")
    c.drawString(72, 650, "Hello World!")
    c.save()

def create_test_pdf_2_cid_font():
    c = canvas.Canvas("test_2_cid.pdf", pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(72, 750, "招标文件 - CID字体测试")
    c.drawString(72, 730, "中文内容测试")
    c.drawString(72, 710, "项目编号：CN-2024-002")
    c.drawString(72, 690, "金额：¥1,000,000")
    c.save()

def create_test_pdf_3_compressed():
    c = canvas.Canvas("test_3_compressed.pdf", pagesize=letter)
    c.setPageCompression(1)
    c.setFont("Helvetica", 12)
    c.drawString(72, 750, "招标文件 - 压缩内容流")
    c.drawString(72, 730, "项目概述")
    c.drawString(72, 710, "本项目为城市基础设施建设工程，包括道路、桥梁、排水等")
    c.drawString(72, 690, "工期：365天")
    c.drawString(72, 670, "质量要求：符合国家相关标准")
    c.save()

def create_test_pdf_4_complex():
    c = canvas.Canvas("test_4_complex.pdf", pagesize=letter)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(72, 750, "复杂招标文件")
    c.setFont("Helvetica", 12)
    c.drawString(72, 730, "第一章 招标公告")
    c.drawString(72, 710, "1.1 项目概况")
    c.drawString(72, 690, "项目名称：综合体育馆建设项目")
    c.drawString(72, 670, "建设地点：市中心区域")
    c.setFont("Helvetica-Oblique", 12)
    c.drawString(72, 650, "特别说明：投标人需具备相应资质")
    c.save()

def create_test_pdf_5_special_chars():
    c = canvas.Canvas("test_5_special.pdf", pagesize=letter)
    c.setFont("Helvetica", 12)
    c.drawString(72, 750, "特殊字符测试")
    c.drawString(72, 730, "包含特殊符号：@#$%^&*()")
    c.drawString(72, 710, "数字测试：1234567890")
    c.drawString(72, 690, "标点符号：，。！？：；")
    c.drawString(72, 670, "英文特殊字符：áéíóú ñ ü")
    c.save()

if __name__ == "__main__":
    print("Generating test PDF files...")
    create_test_pdf_1_simple()
    create_test_pdf_2_cid_font()
    create_test_pdf_3_compressed()
    create_test_pdf_4_complex()
    create_test_pdf_5_special_chars()
    print("Generated 5 test PDF files.")