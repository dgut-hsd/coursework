import zlib

with open('test_1_simple.pdf', 'rb') as f:
    content = f.read()

idx = content.find(b'8 0 obj')
print(f"Object 8 starts at: {idx}")

stream_idx = content.find(b'stream', idx)
endstream_idx = content.find(b'endstream', idx)
print(f"stream at: {stream_idx}, endstream at: {endstream_idx}")

stream_data = content[stream_idx + 6 : endstream_idx]
print(f"Stream data length: {len(stream_data)}")
print(f"First 20 bytes: {stream_data[:20]}")
print(f"Last 10 bytes: {stream_data[-10:]}")

dict_start = content.find(b'<<', idx)
dict_end = content.find(b'>>', idx)
dict_content = content[dict_start:dict_end+2]
print(f"\nDictionary: {dict_content}")

def ascii85_decode(data):
    result = []
    buffer = [0]*5
    count = 0
    for c in data:
        if c == 126:
            break
        if c in [0x20, 0x0a, 0x0d, 0x09]:
            continue
        if c == 122 and count == 0:
            result.extend([0,0,0,0])
            continue
        buffer[count] = c
        count += 1
        if count == 5:
            value = 0
            for b in buffer:
                value = value * 85 + (b - 33)
            result.append((value >> 24) & 0xff)
            result.append((value >> 16) & 0xff)
            result.append((value >> 8) & 0xff)
            result.append(value & 0xff)
            count = 0
    if count > 0:
        value = 0
        for i in range(count):
            value = value * 85 + (buffer[i] - 33)
        for i in range(count, 5):
            value = value * 85 + 84
        if count >= 2:
            result.append((value >> 24) & 0xff)
        if count >= 3:
            result.append((value >> 16) & 0xff)
        if count >= 4:
            result.append((value >> 8) & 0xff)
    return bytes(result)

stream_data_clean = stream_data[1:]
print(f"\nCleaned stream data length: {len(stream_data_clean)}")

decoded1 = ascii85_decode(stream_data_clean)
print(f"ASCII85 decoded length: {len(decoded1)}")
print(f"First 10 bytes: {decoded1[:10]}")

try:
    decoded2 = zlib.decompress(decoded1)
    print(f"Flate decoded length: {len(decoded2)}")
    print(f"Content: {decoded2[:100]}")
except Exception as e:
    print(f"FlateDecode error: {e}")

try:
    decompressor = zlib.decompressobj(-zlib.MAX_WBITS)
    decoded2 = decompressor.decompress(decoded1) + decompressor.flush()
    print(f"Raw DEFLATE decoded length: {len(decoded2)}")
    print(f"Content: {decoded2[:100]}")
except Exception as e:
    print(f"Raw DEFLATE error: {e}")